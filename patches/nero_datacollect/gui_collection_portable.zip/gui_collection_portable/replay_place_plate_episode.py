#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

import numpy as np
import pyarrow.parquet as pq


REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from lerobot.common.robot_devices.motors.configs import PiperMotorsBusConfig
from lerobot.common.robot_devices.motors.piper import PiperMotorsBus


DEFAULT_DATASET_ROOT = Path("/home/ps/Documents/huhuanzhang/data_place_plate_20260507")


def make_arm(can_name: str) -> PiperMotorsBus:
    cfg = PiperMotorsBusConfig(
        can_name=can_name,
        motors={
            "joint_1": [1, "agilex_piper"],
            "joint_2": [2, "agilex_piper"],
            "joint_3": [3, "agilex_piper"],
            "joint_4": [4, "agilex_piper"],
            "joint_5": [5, "agilex_piper"],
            "joint_6": [6, "agilex_piper"],
            "gripper": (7, "agilex_piper"),
        },
    )
    return PiperMotorsBus(cfg)


def parse_optional_delta(value: str) -> float | None:
    normalized = value.strip().lower()
    if normalized in {"none", "off", "disable", "disabled", "unlimited", "no-limit"}:
        return None
    parsed = float(value)
    if parsed < 0:
        raise argparse.ArgumentTypeError("--max-abs-delta must be >= 0 or none")
    return parsed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Replay a recorded place-plate LeRobot episode as absolute 14D Piper joint targets. "
            "The dataset action column is expected to be action[t] = observation.state[t+1]."
        ),
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--dataset-root", type=Path, default=DEFAULT_DATASET_ROOT)
    parser.add_argument("--episode", type=int, default=0)
    parser.add_argument("--source", choices=("action", "observation.state"), default="action")
    parser.add_argument("--start-frame", type=int, default=0)
    parser.add_argument("--end-frame", type=int, default=0, help="0 means replay until the episode end.")
    parser.add_argument("--fps", type=float, default=30.0)
    parser.add_argument("--left-can-name", default="can0")
    parser.add_argument("--right-can-name", default="can1")
    parser.add_argument(
        "--arm-order",
        choices=("left-right", "right-left"),
        default="left-right",
        help="How to map recorded 7D arm blocks to robot commands. right-left swaps the two blocks.",
    )
    parser.add_argument("--max-abs-delta", type=parse_optional_delta, default=None)
    parser.add_argument("--move-to-first", action="store_true")
    parser.add_argument("--move-steps", type=int, default=160)
    parser.add_argument("--move-step-seconds", type=float, default=0.03)
    parser.add_argument("--disable-arms-on-exit", action="store_true")
    parser.add_argument("--disable-settle-seconds", type=float, default=5.0)
    parser.add_argument("--live", action="store_true", help="Actually enable and command the arms.")
    parser.add_argument("--log-every", type=int, default=10)
    args = parser.parse_args()
    if args.start_frame < 0:
        parser.error("--start-frame must be >= 0")
    if args.end_frame < 0:
        parser.error("--end-frame must be >= 0")
    if args.fps <= 0:
        parser.error("--fps must be > 0")
    if args.move_steps < 1:
        parser.error("--move-steps must be >= 1")
    if args.disable_settle_seconds < 0:
        parser.error("--disable-settle-seconds must be >= 0")
    if args.log_every < 1:
        parser.error("--log-every must be >= 1")
    return args


def episode_path(dataset_root: Path, episode_index: int) -> Path:
    return dataset_root / "data" / "chunk-000" / f"episode_{episode_index:06d}.parquet"


def load_targets(path: Path, source: str) -> np.ndarray:
    if not path.exists():
        raise FileNotFoundError(f"Episode parquet does not exist: {path}")
    table = pq.read_table(path, columns=[source])
    targets = np.asarray(table[source].to_pylist(), dtype=np.float32)
    if targets.ndim != 2 or targets.shape[1] != 14:
        raise ValueError(f"Expected {source} to have shape (T, 14), got {targets.shape}")
    return targets


def map_arm_order(targets: np.ndarray, arm_order: str) -> np.ndarray:
    if arm_order == "left-right":
        return targets.astype(np.float32, copy=False)
    return np.concatenate([targets[:, 7:14], targets[:, :7]], axis=1).astype(np.float32, copy=False)


def read_pose(arm: PiperMotorsBus) -> np.ndarray:
    state = arm.wait_for_feedback(timeout_s=3.0)
    return np.asarray([state[f"joint_{idx}"] for idx in range(1, 7)] + [state["gripper"]], dtype=np.float32)


def format_pose(label: str, pose: np.ndarray) -> str:
    preview = ", ".join(f"{value:+.4f}" for value in pose[:6])
    return f"{label}[:6]=[{preview}] grip={pose[6]:+.4f}"


def clamp_target(target: np.ndarray, current: np.ndarray, max_abs_delta: float | None) -> np.ndarray:
    if max_abs_delta is None:
        return target
    return np.clip(target, current - max_abs_delta, current + max_abs_delta).astype(np.float32, copy=False)


def write_dual(left: PiperMotorsBus, right: PiperMotorsBus, target14: np.ndarray) -> None:
    left.write(target14[:7].tolist())
    right.write(target14[7:14].tolist())


def maybe_disable_arms(left: PiperMotorsBus, right: PiperMotorsBus, settle_seconds: float) -> None:
    print("Moving arms to safe pose before disable.")
    left.safe_disconnect()
    right.safe_disconnect()
    if settle_seconds > 0:
        time.sleep(settle_seconds)
    print("Disabling arms.")
    left.connect(enable=False)
    right.connect(enable=False)


def main() -> None:
    args = parse_args()
    parquet_path = episode_path(args.dataset_root, args.episode)
    raw_targets = load_targets(parquet_path, args.source)
    targets = map_arm_order(raw_targets, args.arm_order)

    start = min(args.start_frame, len(targets) - 1)
    end = len(targets) if args.end_frame == 0 else min(args.end_frame, len(targets))
    if end <= start:
        raise ValueError(f"No frames selected: start={start}, end={end}, episode_len={len(targets)}")
    selected = targets[start:end]

    print(f"Replay source: {parquet_path}")
    print(f"  source={args.source} frames=[{start}, {end}) count={len(selected)} fps={args.fps}")
    print(f"  can: left={args.left_can_name}, right={args.right_can_name}")
    print(f"  arm_order={args.arm_order}")
    print(
        f"  live={args.live} max_abs_delta={args.max_abs_delta} "
        f"disable_arms_on_exit={args.disable_arms_on_exit}"
    )
    print(f"  first {format_pose('left', selected[0, :7])} {format_pose('right', selected[0, 7:14])}")
    print(f"  last  {format_pose('left', selected[-1, :7])} {format_pose('right', selected[-1, 7:14])}")

    left = make_arm(args.left_can_name)
    right = make_arm(args.right_can_name)

    if not args.live:
        print("Dry-run only. Add --live to enable arms and replay absolute targets.")
        return

    if not left.connect(enable=True):
        raise RuntimeError(f"Failed to enable left arm on {args.left_can_name}")
    if not right.connect(enable=True):
        raise RuntimeError(f"Failed to enable right arm on {args.right_can_name}")

    try:
        if args.move_to_first:
            left_start = read_pose(left)
            right_start = read_pose(right)
            start14 = np.concatenate([left_start, right_start])
            target14 = selected[0]
            print(f"Moving to first frame: {format_pose('left.start', left_start)} {format_pose('right.start', right_start)}")
            print(f"                      {format_pose('left.target', target14[:7])} {format_pose('right.target', target14[7:14])}")
            for alpha in np.linspace(0.0, 1.0, args.move_steps, dtype=np.float32):
                command = (1.0 - float(alpha)) * start14 + float(alpha) * target14
                write_dual(left, right, command.astype(np.float32, copy=False))
                time.sleep(args.move_step_seconds)

        period = 1.0 / args.fps
        current = selected[0].copy()
        for idx, raw_target in enumerate(selected):
            loop_start = time.perf_counter()
            command = clamp_target(raw_target, current, args.max_abs_delta)
            write_dual(left, right, command)
            current = command.copy()
            if idx % args.log_every == 0:
                frame = start + idx
                print(
                    f"[replay frame={frame}] "
                    f"{format_pose('left', command[:7])} {format_pose('right', command[7:14])}"
                )
            elapsed = time.perf_counter() - loop_start
            if elapsed < period:
                time.sleep(period - elapsed)
    except KeyboardInterrupt:
        print("Interrupted by user.")
    finally:
        if args.disable_arms_on_exit:
            maybe_disable_arms(left, right, args.disable_settle_seconds)
        else:
            print("Replay finished. Leaving arms enabled; pass --disable-arms-on-exit to disable after replay.")


if __name__ == "__main__":
    main()
