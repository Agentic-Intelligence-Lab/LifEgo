#!/bin/bash

set -euo pipefail

# Recovered GUI-based passive data collection for a 4-camera Piper setup.
#
# This launcher mirrors collect_data_gui.sh but injects a 4-camera layout so the
# Tk GUI can show live previews with placeholders while each camera warms up.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

DATASET_NAME="${DATASET_NAME:-place_fruits_20260522}"
DATASET_ROOT="${DATASET_ROOT:-/home/ps/Documents/lerobot-piper-2/data/${DATASET_NAME}}"
REFERENCE_DATASET_ROOT="${REFERENCE_DATASET_ROOT:-}"
SINGLE_TASK="${SINGLE_TASK:-pick up the three fruits and place them into the basket one by one.}"
FPS="${FPS:-30}"
NUM_EPISODES="${NUM_EPISODES:-500}"
EPISODE_TIME_S="${EPISODE_TIME_S:-90}"
CAN_SETTLE_TIME_S="${CAN_SETTLE_TIME_S:-5}"
RESUME="${RESUME:-true}"
EXPECTED_CAN_INTERFACES="${EXPECTED_CAN_INTERFACES:-can0 can1}"
CAN_BITRATE="${CAN_BITRATE:-1000000}"
LEFT_CAN_NAME="${LEFT_CAN_NAME:-can0}"
RIGHT_CAN_NAME="${RIGHT_CAN_NAME:-can1}"
LEFT_CAN_USB_ADDRESS="${LEFT_CAN_USB_ADDRESS:-7-2.2:1.0}"
RIGHT_CAN_USB_ADDRESS="${RIGHT_CAN_USB_ADDRESS:-7-2.4:1.0}"
VALIDATE_AFTER_RECORD="${VALIDATE_AFTER_RECORD:-true}"
VIDEO_TIME_BASE="${VIDEO_TIME_BASE:-}"
VIDEO_CODEC="${VIDEO_CODEC:-libopenh264}"
VIDEO_PIX_FMT="${VIDEO_PIX_FMT:-yuv420p}"
VIDEO_GOP_SIZE="${VIDEO_GOP_SIZE:-2}"
VIDEO_CRF="${VIDEO_CRF:-30}"

CAMERA_FPS="${CAMERA_FPS:-${FPS}}"
CAMERA_WIDTH="${CAMERA_WIDTH:-640}"
CAMERA_HEIGHT="${CAMERA_HEIGHT:-480}"

HEAD_CAMERA_SERIAL="${HEAD_CAMERA_SERIAL:-254622073267}"
LEFT_WRIST_CAMERA_SERIAL="${LEFT_WRIST_CAMERA_SERIAL:-244222071617}"
RIGHT_WRIST_CAMERA_SERIAL="${RIGHT_WRIST_CAMERA_SERIAL:-317622070857}"
AUX_CAMERA_KEY="${AUX_CAMERA_KEY:-front_view}"
AUX_CAMERA_SERIAL="${AUX_CAMERA_SERIAL:-254622079402}"

HEAD_CAMERA_ROTATION="${HEAD_CAMERA_ROTATION:-none}"
LEFT_WRIST_CAMERA_ROTATION="${LEFT_WRIST_CAMERA_ROTATION:-none}"
RIGHT_WRIST_CAMERA_ROTATION="${RIGHT_WRIST_CAMERA_ROTATION:-none}"
AUX_CAMERA_ROTATION="${AUX_CAMERA_ROTATION:-none}"

cd "${REPO_ROOT}"

PYTHON_BIN="${PYTHON_BIN:-python}"
PYTHON_PREFIX="$("${PYTHON_BIN}" - <<'PY'
import sys
print(sys.prefix)
PY
)"
CONDA_LIBJPEG="${PYTHON_PREFIX}/lib/libjpeg.so.8"
PYTHON_LD_PRELOAD="${LD_PRELOAD:-}"
if [ -f "${CONDA_LIBJPEG}" ]; then
    PYTHON_LD_PRELOAD="${CONDA_LIBJPEG}${PYTHON_LD_PRELOAD:+:${PYTHON_LD_PRELOAD}}"
fi

resolve_reference_dataset_fps() {
    local reference_root="$1"
    "${PYTHON_BIN}" - "$reference_root" <<'PY'
import json
import sys
from pathlib import Path

info_path = Path(sys.argv[1]) / "meta" / "info.json"
if not info_path.exists():
    raise SystemExit(0)
info = json.loads(info_path.read_text(encoding="utf-8"))
fps = info.get("fps")
if fps is not None:
    print(fps)
PY
}

resolve_reference_video_time_base() {
    local reference_root="$1"
    "${PYTHON_BIN}" - "$reference_root" <<'PY'
import json
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1])
info_path = root / "meta" / "info.json"
if not info_path.exists():
    raise SystemExit(0)

try:
    info = json.loads(info_path.read_text(encoding="utf-8"))
except Exception:
    raise SystemExit(0)

video_keys = [
    key
    for key, feature in info.get("features", {}).items()
    if isinstance(feature, dict) and feature.get("dtype") == "video"
]
if not video_keys:
    raise SystemExit(0)

episode_index = 0
episode_chunk = episode_index // max(int(info.get("chunks_size", 1000)), 1)
template = info.get("video_path")
if not template:
    raise SystemExit(0)

video_path = root / template.format(
    episode_chunk=episode_chunk,
    video_key=video_keys[0],
    episode_index=episode_index,
)
if video_path.exists():
    probe = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=time_base",
            "-of",
            "json",
            str(video_path),
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    if probe.returncode == 0:
        streams = json.loads(probe.stdout).get("streams", [])
        if streams and streams[0].get("time_base"):
            print(streams[0]["time_base"])
            raise SystemExit(0)

feature_info = info["features"].get(video_keys[0], {}).get("info") or {}
if feature_info.get("video.time_base"):
    print(feature_info["video.time_base"])
PY
}

validate_existing_video_time_base() {
    local dataset_root="$1"
    local expected_time_base="$2"
    "${PYTHON_BIN}" - "$dataset_root" "$expected_time_base" <<'PY'
import json
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1])
expected = sys.argv[2]
info_path = root / "meta" / "info.json"
if not info_path.exists():
    raise SystemExit(0)

info = json.loads(info_path.read_text(encoding="utf-8"))
video_keys = [
    key
    for key, feature in info.get("features", {}).items()
    if isinstance(feature, dict) and feature.get("dtype") == "video"
]
mismatches = []

for key in video_keys:
    feature_info = info["features"].get(key, {}).get("info") or {}
    metadata_time_base = feature_info.get("video.time_base")
    if metadata_time_base and metadata_time_base != expected:
        mismatches.append(f"info.json {key} video.time_base={metadata_time_base}, expected {expected}")

episodes_path = root / "meta" / "episodes.jsonl"
if episodes_path.exists():
    episodes = [json.loads(line) for line in episodes_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if episodes:
        episode_index = int(episodes[0]["episode_index"])
        episode_chunk = episode_index // max(int(info.get("chunks_size", 1000)), 1)
        template = info.get("video_path")
        if template:
            for key in video_keys:
                video_path = root / template.format(
                    episode_chunk=episode_chunk,
                    video_key=key,
                    episode_index=episode_index,
                )
                if not video_path.exists():
                    continue
                probe = subprocess.run(
                    [
                        "ffprobe",
                        "-v",
                        "error",
                        "-select_streams",
                        "v:0",
                        "-show_entries",
                        "stream=time_base",
                        "-of",
                        "json",
                        str(video_path),
                    ],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                )
                if probe.returncode == 0:
                    streams = json.loads(probe.stdout).get("streams", [])
                    actual = streams[0].get("time_base") if streams else None
                    if actual and actual != expected:
                        mismatches.append(f"{video_path} time_base={actual}, expected {expected}")

if mismatches:
    print("Error: existing dataset video time_base does not match the reference dataset.", file=sys.stderr)
    for mismatch in mismatches:
        print(f"  - {mismatch}", file=sys.stderr)
    print("Start a fresh DATASET_NAME/DATASET_ROOT or migrate the existing videos/metadata first.", file=sys.stderr)
    raise SystemExit(1)
PY
}

validate_reference_collection_settings() {
    local reference_root="$1"
    local fps="$2"
    local single_task="$3"
    local camera_json="$4"
    local expected_time_base="$5"
    "${PYTHON_BIN}" - "$reference_root" "$fps" "$single_task" "$camera_json" "$expected_time_base" <<'PY'
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
fps = int(sys.argv[2])
single_task = sys.argv[3]
camera_cfg = json.loads(sys.argv[4])
expected_time_base = sys.argv[5]

info_path = root / "meta" / "info.json"
tasks_path = root / "meta" / "tasks.jsonl"
if not info_path.exists() or not tasks_path.exists():
    raise SystemExit(f"Reference dataset is missing metadata under {root}")

info = json.loads(info_path.read_text(encoding="utf-8"))
tasks = [
    json.loads(line)
    for line in tasks_path.read_text(encoding="utf-8").splitlines()
    if line.strip()
]
tasks = [row["task"] for row in sorted(tasks, key=lambda row: int(row["task_index"]))]

errors = []
if info.get("robot_type") != "piper":
    errors.append(f"reference robot_type={info.get('robot_type')!r}, expected 'piper'")
if int(info.get("fps", -1)) != fps:
    errors.append(f"reference fps={info.get('fps')}, script FPS={fps}")
if info.get("timestamp_mode") != "real_time":
    errors.append(f"reference timestamp_mode={info.get('timestamp_mode')!r}, expected 'real_time'")
if tasks != [single_task]:
    errors.append(f"reference task={tasks!r}, script SINGLE_TASK={single_task!r}")

features = info.get("features", {})
video_items = [(key, feature) for key, feature in features.items() if feature.get("dtype") == "video"]
reference_camera_keys = [key.removeprefix("observation.images.") for key, _ in video_items]
script_camera_keys = list(camera_cfg)
if script_camera_keys != reference_camera_keys:
    errors.append(f"camera key/order mismatch: script={script_camera_keys}, reference={reference_camera_keys}")

for feature_key, feature in video_items:
    camera_key = feature_key.removeprefix("observation.images.")
    if camera_key not in camera_cfg:
        continue
    shape = list(feature.get("shape", []))
    cfg = camera_cfg[camera_key]
    expected_shape = [int(cfg["height"]), int(cfg["width"]), 3]
    if shape != expected_shape:
        errors.append(f"{feature_key} shape={shape}, script expects {expected_shape}")
    if int(cfg.get("fps", -1)) != fps:
        errors.append(f"{camera_key} camera fps={cfg.get('fps')}, script FPS={fps}")
    metadata_time_base = (feature.get("info") or {}).get("video.time_base")
    if metadata_time_base and metadata_time_base != expected_time_base:
        errors.append(f"{feature_key} reference video.time_base={metadata_time_base}, expected {expected_time_base}")

if errors:
    print("Error: collection settings are not aligned with the reference dataset.", file=sys.stderr)
    for error in errors:
        print(f"  - {error}", file=sys.stderr)
    raise SystemExit(1)
PY
}

validate_collected_dataset_metadata_alignment() {
    local dataset_root="$1"
    local reference_root="$2"
    "${PYTHON_BIN}" - "$dataset_root" "$reference_root" <<'PY'
import json
import sys
from pathlib import Path

dataset_root = Path(sys.argv[1])
reference_root = Path(sys.argv[2])

def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))

def load_tasks(root: Path) -> list[str]:
    path = root / "meta" / "tasks.jsonl"
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    return [row["task"] for row in sorted(rows, key=lambda row: int(row["task_index"]))]

def normalize_feature(feature: dict) -> dict:
    normalized = dict(feature)
    if "shape" in normalized:
        normalized["shape"] = list(normalized["shape"])
    if normalized.get("dtype") == "video":
        info = normalized.get("info") or {}
        normalized["info"] = {
            key: info.get(key)
            for key in [
                "video.nominal_fps",
                "video.time_base",
                "video.height",
                "video.width",
                "video.channels",
                "video.codec",
                "video.pix_fmt",
                "video.is_depth_map",
                "has_audio",
            ]
        }
    return normalized

dataset_info = load_json(dataset_root / "meta" / "info.json")
reference_info = load_json(reference_root / "meta" / "info.json")

errors = []
if list(dataset_info) != list(reference_info):
    errors.append(
        f"info.json top-level key order mismatch: dataset={list(dataset_info)}, reference={list(reference_info)}"
    )
for key in ["codebase_version", "robot_type", "fps", "data_path", "video_path", "timestamp_mode"]:
    if dataset_info.get(key) != reference_info.get(key):
        errors.append(f"info.json {key}: dataset={dataset_info.get(key)!r}, reference={reference_info.get(key)!r}")

if load_tasks(dataset_root) != load_tasks(reference_root):
    errors.append(f"tasks.jsonl mismatch: dataset={load_tasks(dataset_root)!r}, reference={load_tasks(reference_root)!r}")

dataset_features = dataset_info.get("features", {})
reference_features = reference_info.get("features", {})
if list(dataset_features) != list(reference_features):
    errors.append(f"feature order mismatch: dataset={list(dataset_features)}, reference={list(reference_features)}")
else:
    for key in reference_features:
        current = normalize_feature(dataset_features[key])
        expected = normalize_feature(reference_features[key])
        if current != expected:
            errors.append(f"feature {key} mismatch: dataset={current}, reference={expected}")

if errors:
    print("Error: collected dataset metadata is not aligned with the reference dataset.", file=sys.stderr)
    for error in errors:
        print(f"  - {error}", file=sys.stderr)
    raise SystemExit(1)
PY
}

normalize_collected_dataset_info_json_alignment() {
    local dataset_root="$1"
    local reference_root="$2"
    "${PYTHON_BIN}" - "$dataset_root" "$reference_root" <<'PY'
import json
import sys
from pathlib import Path

dataset_root = Path(sys.argv[1])
reference_root = Path(sys.argv[2])
dataset_info_path = dataset_root / "meta" / "info.json"
reference_info_path = reference_root / "meta" / "info.json"

if not dataset_info_path.exists() or not reference_info_path.exists():
    raise SystemExit(0)

dataset_info = json.loads(dataset_info_path.read_text(encoding="utf-8"))
reference_info = json.loads(reference_info_path.read_text(encoding="utf-8"))


def ordered_like_reference(dataset_value, reference_value):
    if isinstance(dataset_value, dict) and isinstance(reference_value, dict):
        ordered = {}
        for key in reference_value:
            if key in dataset_value:
                ordered[key] = ordered_like_reference(dataset_value[key], reference_value[key])
            else:
                ordered[key] = reference_value[key]
        for key, value in dataset_value.items():
            if key not in ordered:
                ordered[key] = value
        return ordered
    return dataset_value


def normalize_video_info(dataset_video_info: dict, reference_video_info: dict) -> dict:
    dynamic_keys = {
        "video.fps",
        "video.avg_fps",
        "video.duration_s",
        "video.nb_frames",
    }
    static_reference_keys = {
        "video.nominal_fps",
        "video.time_base",
        "video.height",
        "video.width",
        "video.channels",
        "video.codec",
        "video.pix_fmt",
        "video.is_depth_map",
        "has_audio",
    }

    normalized = {}
    for key in reference_video_info:
        if key in dynamic_keys and key in dataset_video_info:
            normalized[key] = dataset_video_info[key]
        elif key in static_reference_keys and key in reference_video_info:
            normalized[key] = reference_video_info[key]
        elif key in dataset_video_info:
            normalized[key] = dataset_video_info[key]
        else:
            normalized[key] = reference_video_info[key]

    for key, value in dataset_video_info.items():
        if key not in normalized:
            normalized[key] = value
    return normalized


def normalize_feature(feature_key: str, dataset_feature: dict, reference_feature: dict) -> dict:
    normalized = {}
    for key in reference_feature:
        if key == "info" and reference_feature.get("dtype") == "video":
            normalized[key] = normalize_video_info(
                dataset_feature.get("info") or {},
                reference_feature.get("info") or {},
            )
        elif key in dataset_feature:
            normalized[key] = ordered_like_reference(dataset_feature[key], reference_feature[key])
        else:
            normalized[key] = reference_feature[key]

    for key, value in dataset_feature.items():
        if key not in normalized:
            normalized[key] = value
    return normalized


def normalize_features(dataset_features: dict, reference_features: dict) -> dict:
    normalized = {}
    for key in reference_features:
        if key in dataset_features:
            normalized[key] = normalize_feature(key, dataset_features[key], reference_features[key])
        else:
            normalized[key] = reference_features[key]
    for key, value in dataset_features.items():
        if key not in normalized:
            normalized[key] = value
    return normalized


normalized_info = {}
for key in reference_info:
    if key == "features":
        normalized_info[key] = normalize_features(
            dataset_info.get("features") or {},
            reference_info.get("features") or {},
        )
    elif key in {
        "codebase_version",
        "robot_type",
        "fps",
        "data_path",
        "video_path",
        "timestamp_mode",
    }:
        normalized_info[key] = reference_info[key]
    elif key in dataset_info:
        normalized_info[key] = ordered_like_reference(dataset_info[key], reference_info[key])
    else:
        normalized_info[key] = reference_info[key]

for key, value in dataset_info.items():
    if key not in normalized_info:
        normalized_info[key] = value

dataset_info_path.write_text(
    json.dumps(normalized_info, indent=4, ensure_ascii=False) + "\n",
    encoding="utf-8",
)
PY
}

USE_REFERENCE_DATASET="false"
if [ -n "${REFERENCE_DATASET_ROOT}" ]; then
    if [ -f "${REFERENCE_DATASET_ROOT}/meta/info.json" ] && [ -f "${REFERENCE_DATASET_ROOT}/meta/tasks.jsonl" ]; then
        USE_REFERENCE_DATASET="true"
    else
        echo "Warning: REFERENCE_DATASET_ROOT is set but is not a complete LeRobot dataset: ${REFERENCE_DATASET_ROOT}"
        echo "Skipping reference alignment for this new dataset."
    fi
fi

if [ "${USE_REFERENCE_DATASET}" = "true" ]; then
    REFERENCE_FPS="$(resolve_reference_dataset_fps "${REFERENCE_DATASET_ROOT}")"
    if [ -z "${REFERENCE_FPS}" ]; then
        echo "Error: could not resolve fps from reference dataset: ${REFERENCE_DATASET_ROOT}"
        exit 1
    fi
    if [ "${FPS}" != "${REFERENCE_FPS}" ]; then
        echo "Error: FPS=${FPS} does not match reference dataset fps=${REFERENCE_FPS}."
        echo "Set FPS=${REFERENCE_FPS} to collect data aligned with ${REFERENCE_DATASET_ROOT}."
        exit 1
    fi
fi
if [ "${CAMERA_FPS:-${FPS}}" != "${FPS}" ]; then
    echo "Error: CAMERA_FPS=${CAMERA_FPS} must match FPS=${FPS}."
    exit 1
fi

if [ -z "${VIDEO_TIME_BASE}" ]; then
    if [ "${USE_REFERENCE_DATASET}" = "true" ]; then
        VIDEO_TIME_BASE="$(resolve_reference_video_time_base "${REFERENCE_DATASET_ROOT}")"
    fi
    if [ -z "${VIDEO_TIME_BASE}" ]; then
        VIDEO_TIME_BASE="1/1000000"
    fi
fi
if [[ ! "${VIDEO_TIME_BASE}" =~ ^1/[1-9][0-9]*$ ]]; then
    echo "Error: VIDEO_TIME_BASE must look like 1/1000000."
    echo "Current value: ${VIDEO_TIME_BASE}"
    exit 1
fi
VIDEO_TIME_BASE_DEN="${VIDEO_TIME_BASE#1/}"

get_episode_count() {
    local dataset_root="$1"
    "${PYTHON_BIN}" - "$dataset_root" <<'PY'
from pathlib import Path
import sys

root = Path(sys.argv[1])
episodes_path = root / "meta" / "episodes.jsonl"
if not episodes_path.exists():
    print(0)
    raise SystemExit

count = 0
with episodes_path.open("r", encoding="utf-8") as f:
    for line in f:
        if line.strip():
            count += 1
print(count)
PY
}

if [[ ! "${AUX_CAMERA_KEY}" =~ ^[A-Za-z0-9_]+$ ]]; then
    echo "Error: AUX_CAMERA_KEY must use only letters, numbers, or underscores."
    echo "Current value: ${AUX_CAMERA_KEY}"
    exit 1
fi

validate_rotation() {
    local rotation_name="$1"
    local rotation_value="$2"
    case "${rotation_value}" in
        none|-90|90|180)
            ;;
        *)
            echo "Error: ${rotation_name} must be one of: none, -90, 90, 180."
            echo "Current value: ${rotation_value}"
            exit 1
            ;;
    esac
}

validate_serial() {
    local serial_name="$1"
    local serial_value="$2"
    if [[ ! "${serial_value}" =~ ^[0-9]+$ ]]; then
        echo "Error: ${serial_name} must be a numeric RealSense serial number."
        echo "Current value: ${serial_value}"
        exit 1
    fi
}

validate_serial "HEAD_CAMERA_SERIAL" "${HEAD_CAMERA_SERIAL}"
validate_serial "LEFT_WRIST_CAMERA_SERIAL" "${LEFT_WRIST_CAMERA_SERIAL}"
validate_serial "RIGHT_WRIST_CAMERA_SERIAL" "${RIGHT_WRIST_CAMERA_SERIAL}"
validate_serial "AUX_CAMERA_SERIAL" "${AUX_CAMERA_SERIAL}"

validate_rotation "HEAD_CAMERA_ROTATION" "${HEAD_CAMERA_ROTATION}"
validate_rotation "LEFT_WRIST_CAMERA_ROTATION" "${LEFT_WRIST_CAMERA_ROTATION}"
validate_rotation "RIGHT_WRIST_CAMERA_ROTATION" "${RIGHT_WRIST_CAMERA_ROTATION}"
validate_rotation "AUX_CAMERA_ROTATION" "${AUX_CAMERA_ROTATION}"

declare -A SEEN_SERIALS=()
DUPLICATE_SERIALS=()
for serial in \
    "${HEAD_CAMERA_SERIAL}" \
    "${LEFT_WRIST_CAMERA_SERIAL}" \
    "${RIGHT_WRIST_CAMERA_SERIAL}" \
    "${AUX_CAMERA_SERIAL}"; do
    if [ -n "${SEEN_SERIALS[$serial]:-}" ]; then
        DUPLICATE_SERIALS+=("${serial}")
    else
        SEEN_SERIALS[$serial]=1
    fi
done

if [ "${#DUPLICATE_SERIALS[@]}" -gt 0 ]; then
    echo "Error: duplicate camera serial numbers are not allowed."
    printf 'Duplicated serial(s): %s\n' "${DUPLICATE_SERIALS[@]}"
    exit 1
fi

is_zero_episode_partial_dataset() {
    local dataset_root="$1"
    "${PYTHON_BIN}" - "$dataset_root" <<'PY'
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
info_path = root / "meta" / "info.json"
if not info_path.exists():
    raise SystemExit(1)
try:
    info = json.loads(info_path.read_text(encoding="utf-8"))
except Exception:
    raise SystemExit(1)
if any(int(info.get(key, -1)) != 0 for key in ["total_episodes", "total_frames", "total_videos"]):
    raise SystemExit(1)
for folder_name in ["data", "videos"]:
    folder = root / folder_name
    if folder.exists() and any(folder.rglob("*")):
        raise SystemExit(1)
raise SystemExit(0)
PY
}

ensure_empty_dataset_metadata_files() {
    local dataset_root="$1"
    mkdir -p "${dataset_root}/meta"
    touch \
        "${dataset_root}/meta/tasks.jsonl" \
        "${dataset_root}/meta/episodes.jsonl" \
        "${dataset_root}/meta/episodes_stats.jsonl"
}

if [ "${RESUME}" = "true" ]; then
    REQUIRED_DATASET_FILES=(
        "meta/info.json"
        "meta/tasks.jsonl"
        "meta/episodes.jsonl"
        "meta/episodes_stats.jsonl"
    )
    MISSING_DATASET_FILES=()
    if [ -e "${DATASET_ROOT}" ]; then
        for relative_path in "${REQUIRED_DATASET_FILES[@]}"; do
            if [ ! -f "${DATASET_ROOT}/${relative_path}" ]; then
                MISSING_DATASET_FILES+=("${relative_path}")
            fi
        done
    fi
    if [ "${#MISSING_DATASET_FILES[@]}" -gt 0 ]; then
        if is_zero_episode_partial_dataset "${DATASET_ROOT}"; then
            echo "Found a zero-episode partial dataset directory. Creating empty metadata jsonl files and resuming safely."
            ensure_empty_dataset_metadata_files "${DATASET_ROOT}"
        else
            echo "Error: RESUME=true but ${DATASET_ROOT} is not a valid existing LeRobot dataset."
            echo "Missing file(s):"
            printf '  - %s\n' "${MISSING_DATASET_FILES[@]}"
            echo "This usually means a previous failed startup left a partial dataset directory."
            echo "Move it aside, choose a new DATASET_NAME, or set RESUME=false after removing the partial directory."
            exit 1
        fi
    fi
    validate_existing_video_time_base "${DATASET_ROOT}" "${VIDEO_TIME_BASE}"
else
    if [ -e "${DATASET_ROOT}" ]; then
        if is_zero_episode_partial_dataset "${DATASET_ROOT}"; then
            echo "Found a zero-episode partial dataset directory. Reusing it without deleting data."
            ensure_empty_dataset_metadata_files "${DATASET_ROOT}"
            RESUME="true"
            validate_existing_video_time_base "${DATASET_ROOT}" "${VIDEO_TIME_BASE}"
        else
            echo "Error: target dataset directory already exists: ${DATASET_ROOT}"
            echo "Choose a new DATASET_NAME, set RESUME=true, or remove the existing directory."
            exit 1
        fi
    fi
fi

INITIAL_EPISODE_COUNT="$(get_episode_count "${DATASET_ROOT}")"

ROBOT_CAMERAS_JSON="$(
    HEAD_CAMERA_SERIAL="${HEAD_CAMERA_SERIAL}" \
    LEFT_WRIST_CAMERA_SERIAL="${LEFT_WRIST_CAMERA_SERIAL}" \
    RIGHT_WRIST_CAMERA_SERIAL="${RIGHT_WRIST_CAMERA_SERIAL}" \
    AUX_CAMERA_SERIAL="${AUX_CAMERA_SERIAL}" \
    AUX_CAMERA_KEY="${AUX_CAMERA_KEY}" \
    CAMERA_FPS="${CAMERA_FPS}" \
    CAMERA_WIDTH="${CAMERA_WIDTH}" \
    CAMERA_HEIGHT="${CAMERA_HEIGHT}" \
    HEAD_CAMERA_ROTATION="${HEAD_CAMERA_ROTATION}" \
    LEFT_WRIST_CAMERA_ROTATION="${LEFT_WRIST_CAMERA_ROTATION}" \
    RIGHT_WRIST_CAMERA_ROTATION="${RIGHT_WRIST_CAMERA_ROTATION}" \
    AUX_CAMERA_ROTATION="${AUX_CAMERA_ROTATION}" \
    "${PYTHON_BIN}" - <<'PY'
import json
import os


def parse_int(name: str) -> int:
    return int(os.environ[name])


def parse_rotation(name: str):
    value = os.environ[name].strip().lower()
    if value == "none":
        return None
    return int(value)


def make_camera(serial_env: str, rotation_env: str) -> dict:
    return {
        "type": "intelrealsense",
        "serial_number": parse_int(serial_env),
        "fps": parse_int("CAMERA_FPS"),
        "width": parse_int("CAMERA_WIDTH"),
        "height": parse_int("CAMERA_HEIGHT"),
        "force_hardware_reset": False,
        "rotation": parse_rotation(rotation_env),
    }


cameras = {
    "head": make_camera("HEAD_CAMERA_SERIAL", "HEAD_CAMERA_ROTATION"),
    "left_wrist": make_camera("LEFT_WRIST_CAMERA_SERIAL", "LEFT_WRIST_CAMERA_ROTATION"),
    "right_wrist": make_camera("RIGHT_WRIST_CAMERA_SERIAL", "RIGHT_WRIST_CAMERA_ROTATION"),
    os.environ["AUX_CAMERA_KEY"]: make_camera("AUX_CAMERA_SERIAL", "AUX_CAMERA_ROTATION"),
}

print(json.dumps(cameras, separators=(",", ":")))
PY
)"

if [ "${USE_REFERENCE_DATASET}" = "true" ]; then
    validate_reference_collection_settings \
        "${REFERENCE_DATASET_ROOT}" \
        "${FPS}" \
        "${SINGLE_TASK}" \
        "${ROBOT_CAMERAS_JSON}" \
        "${VIDEO_TIME_BASE}"
fi

echo "================ Camera Preflight ================"
echo "head=${HEAD_CAMERA_SERIAL} rotation=${HEAD_CAMERA_ROTATION}"
echo "left_wrist=${LEFT_WRIST_CAMERA_SERIAL} rotation=${LEFT_WRIST_CAMERA_ROTATION}"
echo "right_wrist=${RIGHT_WRIST_CAMERA_SERIAL} rotation=${RIGHT_WRIST_CAMERA_ROTATION}"
echo "${AUX_CAMERA_KEY}=${AUX_CAMERA_SERIAL} rotation=${AUX_CAMERA_ROTATION}"

PYTHONPATH="${REPO_ROOT}" EXPECTED_CAMERA_JSON="${ROBOT_CAMERAS_JSON}" "${PYTHON_BIN}" - <<'PY'
import json
import os
import sys

from lerobot.common.robot_devices.cameras.intelrealsense import find_cameras

expected = json.loads(os.environ["EXPECTED_CAMERA_JSON"])
detected_infos = find_cameras()
detected = {int(item["serial_number"]): item["name"] for item in detected_infos}

print("Detected RealSense cameras:")
for serial_number in sorted(detected):
    print(f"  serial={serial_number}  name={detected[serial_number]}")

missing = []
for key, camera_cfg in expected.items():
    serial_number = int(camera_cfg["serial_number"])
    if serial_number not in detected:
        missing.append((key, serial_number))

if missing:
    print("Error: missing configured RealSense camera(s) for this 4-camera GUI run:")
    for key, serial_number in missing:
        print(f"  {key}: serial={serial_number}")
    print("Reconnect the missing camera(s) or update the serial numbers before recording.")
    sys.exit(1)

print("All configured 4-camera serial numbers are currently detected.")
PY

echo "================ CAN Activation ================"
echo "left_can=${LEFT_CAN_NAME} usb=${LEFT_CAN_USB_ADDRESS} bitrate=${CAN_BITRATE}"
echo "right_can=${RIGHT_CAN_NAME} usb=${RIGHT_CAN_USB_ADDRESS} bitrate=${CAN_BITRATE}"
bash "${SCRIPT_DIR}/can_activate.sh" "${LEFT_CAN_NAME}" "${CAN_BITRATE}" "${LEFT_CAN_USB_ADDRESS}"
bash "${SCRIPT_DIR}/can_activate.sh" "${RIGHT_CAN_NAME}" "${CAN_BITRATE}" "${RIGHT_CAN_USB_ADDRESS}"

echo "================ GUI Collection (4 Cameras) ================"
echo "dataset_name=${DATASET_NAME}"
echo "dataset_root=${DATASET_ROOT}"
echo "single_task=${SINGLE_TASK}"
echo "fps=${FPS}"
echo "num_episodes=${NUM_EPISODES}"
echo "episode_time_s=${EPISODE_TIME_S}"
echo "can_settle_time_s=${CAN_SETTLE_TIME_S}"
echo "resume=${RESUME}"
echo "camera_keys=head,left_wrist,right_wrist,${AUX_CAMERA_KEY}"
echo "reference_dataset_root=${REFERENCE_DATASET_ROOT}"
echo "use_reference_dataset=${USE_REFERENCE_DATASET}"
echo "video_time_base=${VIDEO_TIME_BASE}"
echo "video_codec=${VIDEO_CODEC}"
echo "video_pix_fmt=${VIDEO_PIX_FMT}"

echo "Waiting ${CAN_SETTLE_TIME_S}s for CAN feedback to stabilize..."
sleep "${CAN_SETTLE_TIME_S}"

missing_can_interfaces=()
for iface in ${EXPECTED_CAN_INTERFACES}; do
    if [ ! -d "/sys/class/net/${iface}" ]; then
        missing_can_interfaces+=("${iface}")
    fi
done

if [ "${#missing_can_interfaces[@]}" -gt 0 ]; then
    echo "Error: missing required CAN interface(s): ${missing_can_interfaces[*]}"
    echo "Detected network interfaces:"
    ls /sys/class/net | sed 's/^/  - /'
    echo "The dual-arm Piper setup requires all of: ${EXPECTED_CAN_INTERFACES}"
    echo "Please check USB-CAN power, cabling, and whether both adapters are enumerated."
    exit 1
fi

PY_ARGS=(
  --dataset-name "${DATASET_NAME}"
  --dataset-root "${DATASET_ROOT}"
  --single-task "${SINGLE_TASK}"
  --fps "${FPS}"
  --num-episodes "${NUM_EPISODES}"
  --episode-time-s "${EPISODE_TIME_S}"
  --robot-cameras-json "${ROBOT_CAMERAS_JSON}"
  --left-can-name "${LEFT_CAN_NAME}"
  --right-can-name "${RIGHT_CAN_NAME}"
)

if [ "${RESUME}" = "true" ]; then
    PY_ARGS+=(--resume)
fi

echo "python_bin=${PYTHON_BIN}"
if [ -f "${CONDA_LIBJPEG}" ]; then
    echo "opencv_libjpeg_preload=${CONDA_LIBJPEG}"
fi
PYTHONPATH="${REPO_ROOT}${PYTHONPATH:+:${PYTHONPATH}}" \
LD_PRELOAD="${PYTHON_LD_PRELOAD}" \
LEROBOT_VIDEO_TIME_BASE_DEN="${VIDEO_TIME_BASE_DEN}" \
LEROBOT_VIDEO_CODEC="${VIDEO_CODEC}" \
LEROBOT_VIDEO_PIX_FMT="${VIDEO_PIX_FMT}" \
LEROBOT_VIDEO_GOP_SIZE="${VIDEO_GOP_SIZE}" \
LEROBOT_VIDEO_CRF="${VIDEO_CRF}" \
"${PYTHON_BIN}" - "${SCRIPT_DIR}/collect_data_gui_4cam_recovered.py" "${PY_ARGS[@]}" <<'PY'
from __future__ import annotations

import importlib.util
import os
import json
import subprocess
import sys
from fractions import Fraction
from pathlib import Path


def _patch_lerobot_realtime_video_encoder() -> None:
    import av
    import numpy as np
    import pyarrow.parquet as pq
    from PIL import Image

    from lerobot.common.datasets import lerobot_dataset as lerobot_dataset_module

    time_base_den = int(os.environ["LEROBOT_VIDEO_TIME_BASE_DEN"])
    codec = os.environ.get("LEROBOT_VIDEO_CODEC", "libopenh264")
    pix_fmt = os.environ.get("LEROBOT_VIDEO_PIX_FMT", "yuv420p")
    gop_size = int(os.environ.get("LEROBOT_VIDEO_GOP_SIZE", "2"))
    crf = os.environ.get("LEROBOT_VIDEO_CRF", "30")
    time_base = Fraction(1, time_base_den)

    def _scalar_column(table, column_name: str) -> np.ndarray:
        return np.asarray(table[column_name].to_pylist(), dtype=np.float64)

    def _duration_ticks(timestamps: np.ndarray, transition_dt: np.ndarray, fps: int) -> list[int]:
        if len(transition_dt) == len(timestamps) and np.all(transition_dt > 0.0):
            durations = transition_dt
        elif len(timestamps) > 1:
            last_dt = timestamps[-1] - timestamps[-2]
            if last_dt <= 0.0:
                last_dt = 1.0 / max(float(fps), 1.0)
            durations = np.concatenate([np.diff(timestamps), np.asarray([last_dt])])
        else:
            durations = np.asarray([1.0 / max(float(fps), 1.0)])

        return [max(1, int(round(float(duration_s) * time_base_den))) for duration_s in durations]

    def _encode_png_sequence_with_realtime_pts(
        image_paths: list[Path],
        video_path: Path,
        fps: int,
        timestamps: np.ndarray,
        durations: list[int],
    ) -> None:
        if len(image_paths) != len(timestamps):
            raise RuntimeError(
                f"{video_path}: image count {len(image_paths)} does not match timestamp count {len(timestamps)}"
            )
        missing = [path for path in image_paths if not path.exists()]
        if missing:
            raise FileNotFoundError(f"{video_path}: missing image frame(s), first missing: {missing[0]}")

        video_path.parent.mkdir(parents=True, exist_ok=True)
        tmp_video_path = video_path.with_suffix(video_path.suffix + ".tmp")
        if tmp_video_path.exists():
            tmp_video_path.unlink()

        container = av.open(str(tmp_video_path), "w", format="mp4")
        try:
            stream = container.add_stream(codec, rate=fps)
            with Image.open(image_paths[0]) as first_image:
                width, height = first_image.size
            stream.width = width
            stream.height = height
            stream.pix_fmt = pix_fmt
            stream.time_base = time_base
            stream.codec_context.time_base = time_base
            stream.codec_context.gop_size = gop_size
            stream.options = {"g": str(gop_size), "crf": str(crf)}

            duration_by_pts = {}
            for image_path, timestamp_s, duration in zip(image_paths, timestamps, durations):
                pts = int(round(float(timestamp_s) * time_base_den))
                duration_by_pts[pts] = duration
                with Image.open(image_path) as image:
                    frame = av.VideoFrame.from_image(image.convert("RGB"))
                frame.pts = pts
                frame.time_base = time_base
                frame.duration = duration
                for packet in stream.encode(frame):
                    if packet.pts in duration_by_pts:
                        packet.duration = duration_by_pts[packet.pts]
                    container.mux(packet)

            for packet in stream.encode():
                if packet.pts in duration_by_pts:
                    packet.duration = duration_by_pts[packet.pts]
                container.mux(packet)
        except Exception:
            container.close()
            if tmp_video_path.exists():
                tmp_video_path.unlink()
            raise
        else:
            container.close()
            tmp_video_path.replace(video_path)

        probe = subprocess.run(
            [
                "ffprobe",
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-show_entries",
                "stream=time_base,nb_frames",
                "-of",
                "json",
                str(video_path),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True,
        )
        streams = json.loads(probe.stdout).get("streams", [])
        stream_info = streams[0] if streams else {}
        actual_time_base = stream_info.get("time_base")
        if actual_time_base != f"1/{time_base_den}":
            raise RuntimeError(
                f"{video_path}: encoded video time_base is {actual_time_base}, expected 1/{time_base_den}"
            )
        nb_frames = int(stream_info["nb_frames"]) if stream_info.get("nb_frames") else None
        if nb_frames != len(image_paths):
            raise RuntimeError(f"{video_path}: encoded {nb_frames} frames, expected {len(image_paths)}")

    def encode_episode_videos_with_realtime_pts(self, episode_index: int) -> dict:
        parquet_path = self.root / self.meta.get_data_file_path(ep_index=episode_index)
        table = pq.read_table(parquet_path, columns=["timestamp", "real_transition_delta_s"])
        timestamps = _scalar_column(table, "timestamp")
        transition_dt = _scalar_column(table, "real_transition_delta_s")
        if len(timestamps) == 0:
            raise RuntimeError(f"{parquet_path}: cannot encode an empty episode")
        if not np.all(np.diff(timestamps) > 0.0):
            raise RuntimeError(f"{parquet_path}: timestamps must be strictly increasing")
        durations = _duration_ticks(timestamps, transition_dt, self.fps)

        video_paths = {}
        for key in self.meta.video_keys:
            video_path = self.root / self.meta.get_video_file_path(episode_index, key)
            video_paths[key] = str(video_path)
            if video_path.is_file():
                continue
            img_dir = self._get_image_file_path(
                episode_index=episode_index,
                image_key=key,
                frame_index=0,
            ).parent
            image_paths = [img_dir / f"frame_{frame_index:06d}.png" for frame_index in range(len(timestamps))]
            _encode_png_sequence_with_realtime_pts(
                image_paths=image_paths,
                video_path=video_path,
                fps=self.fps,
                timestamps=timestamps,
                durations=durations,
            )

        return video_paths

    lerobot_dataset_module.LeRobotDataset.encode_episode_videos = encode_episode_videos_with_realtime_pts


def _patch_split_arm_state_trace(module) -> None:
    def _short_trace_label(name: str, prefix: str) -> str:
        prefix_text = f"{prefix}_"
        return name[len(prefix_text):] if name.startswith(prefix_text) else name

    def _draw_trace_panel(
        draw,
        state,
        dims,
        names,
        colors,
        title: str,
        prefix: str,
        rect: tuple[int, int, int, int],
    ) -> None:
        left, top, right, bottom = rect
        panel_w = max(right - left, 1)
        panel_h = max(bottom - top, 1)
        title_h = 24
        legend_h = 42
        margin_l, margin_r = 44, 10
        margin_t, margin_b = title_h + 10, legend_h + 12
        plot_l = left + margin_l
        plot_t = top + margin_t
        plot_r = right - margin_r
        plot_b = bottom - margin_b
        plot_w = max(plot_r - plot_l, 1)
        plot_h = max(plot_b - plot_t, 1)

        draw.rectangle([left, top, right, bottom], outline=(205, 212, 220), fill=(247, 248, 250))
        draw.text((left + 10, top + 6), title, fill=(36, 56, 78))
        draw.rectangle([plot_l, plot_t, plot_r, plot_b], outline=(205, 212, 220))
        for frac in [0.25, 0.5, 0.75]:
            y = plot_t + int(plot_h * frac)
            draw.line([plot_l, y, plot_r, y], fill=(226, 230, 235))

        if state.size and state.shape[0] > 0:
            x = module.np.linspace(plot_l, plot_l + plot_w, state.shape[0])
            for dim in dims:
                if dim >= state.shape[1]:
                    continue
                values = state[:, dim]
                v_min = float(module.np.min(values))
                v_max = float(module.np.max(values))
                scale = max(v_max - v_min, 1e-6)
                y = plot_t + plot_h - ((values - v_min) / scale * plot_h)
                points = list(zip(x.astype(int), y.astype(int)))
                if len(points) > 1:
                    draw.line(points, fill=colors[dim % len(colors)], width=2)

        draw.text((plot_l, plot_b + 4), "0", fill=(95, 108, 122))
        frame_label = f"{max(int(state.shape[0]) - 1, 0)} frames"
        draw.text((max(plot_l, plot_r - 70), plot_b + 4), frame_label, fill=(95, 108, 122))

        legend_top = bottom - legend_h + 6
        columns = 4
        col_w = max(panel_w // columns, 1)
        for idx, dim in enumerate(dims):
            if dim >= len(names):
                label = f"dim {dim}"
            else:
                label = _short_trace_label(str(names[dim]), prefix)
            row = idx // columns
            col = idx % columns
            lx = left + 12 + col * col_w
            ly = legend_top + row * 16
            draw.line([lx, ly + 6, lx + 18, ly + 6], fill=colors[dim % len(colors)], width=2)
            draw.text((lx + 22, ly), label, fill=(56, 68, 80))

    def _render_state_trace(self, episode_index: int, report: dict | None = None) -> None:
        info = module._load_json(self.args.dataset_root / "meta" / "info.json")
        parquet_path = module._episode_parquet_path(self.args.dataset_root, info, episode_index)
        if not parquet_path.exists():
            return

        table = module.pq.read_table(parquet_path, columns=["observation.state"])
        state = module._stack_column(table, "observation.state", dtype=module.np.float64)
        feature = info.get("features", {}).get("observation.state", {})
        names = list(feature.get("names") or [f"dim_{idx}" for idx in range(state.shape[1] if state.ndim == 2 else 14)])

        width = max(self.trace_panel.winfo_width() - 36, 1200)
        height = 220
        img = module.Image.new("RGB", (width, height), (247, 248, 250))
        draw = module.ImageDraw.Draw(img)

        colors = [
            (31, 98, 141), (207, 87, 64), (65, 136, 92), (133, 92, 164),
            (211, 142, 48), (80, 85, 94), (0, 137, 123),
            (78, 121, 167), (242, 142, 43), (89, 161, 79), (176, 122, 161),
            (225, 87, 89), (156, 117, 95), (118, 183, 178),
        ]

        header_h = 22
        gap = 18
        panel_top = header_h + 4
        panel_bottom = height - 4
        panel_w = (width - gap) // 2
        left_rect = (0, panel_top, panel_w, panel_bottom)
        right_rect = (panel_w + gap, panel_top, width - 1, panel_bottom)

        title = f"Episode {episode_index} state trace: left/right split, {state.shape[0]} frames"
        draw.text((8, 4), title, fill=(36, 56, 78))
        if report and (report.get("errors") or report.get("warnings")):
            flag_text = f"{report.get('status')} flags: {len(report.get('errors', []))} errors, {len(report.get('warnings', []))} warnings"
            draw.text((420, 4), flag_text, fill=(145, 72, 36))

        _draw_trace_panel(
            draw,
            state,
            range(0, min(7, state.shape[1] if state.ndim == 2 else 0)),
            names,
            colors,
            "Left Arm / Gripper Trace",
            "left",
            left_rect,
        )
        _draw_trace_panel(
            draw,
            state,
            range(7, min(14, state.shape[1] if state.ndim == 2 else 0)),
            names,
            colors,
            "Right Arm / Gripper Trace",
            "right",
            right_rect,
        )

        photo = module.ImageTk.PhotoImage(img)
        self.trace_panel.configure(image=photo)
        self.trace_panel.image = photo
        self.trace_image = photo

    module.PiperCollectionGUI._render_state_trace = _render_state_trace


script_path = Path(sys.argv[1]).resolve()
script_dir = str(script_path.parent)
repo_root = str(script_path.parents[1])
if script_dir not in sys.path:
    sys.path.insert(0, script_dir)
if repo_root not in sys.path:
    sys.path.insert(0, repo_root)

_patch_lerobot_realtime_video_encoder()
spec = importlib.util.spec_from_file_location("collect_data_gui_4cam_recovered_split_trace", script_path)
module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(module)
_patch_split_arm_state_trace(module)

sys.argv = [str(script_path)] + sys.argv[2:]
module.main()
PY

if [ "${USE_REFERENCE_DATASET}" = "true" ]; then
    echo "Normalizing dataset info.json alignment..."
    normalize_collected_dataset_info_json_alignment "${DATASET_ROOT}" "${REFERENCE_DATASET_ROOT}"
else
    echo "Skipping dataset info.json reference normalization."
fi

if [ "${VALIDATE_AFTER_RECORD}" = "true" ]; then
    FINAL_EPISODE_COUNT="$(get_episode_count "${DATASET_ROOT}")"
    echo "================ Post-Run Validation ================"
    echo "initial_episode_count=${INITIAL_EPISODE_COUNT}"
    echo "final_episode_count=${FINAL_EPISODE_COUNT}"

    if [ "${FINAL_EPISODE_COUNT}" -le "${INITIAL_EPISODE_COUNT}" ]; then
        echo "No new episodes were recorded in this run. Skipping validation."
        exit 0
    fi

    if [ "${USE_REFERENCE_DATASET}" = "true" ]; then
        echo "Validating dataset metadata alignment..."
        validate_collected_dataset_metadata_alignment "${DATASET_ROOT}" "${REFERENCE_DATASET_ROOT}"
    else
        echo "Skipping reference metadata alignment validation."
    fi

    for ((episode_index=INITIAL_EPISODE_COUNT; episode_index<FINAL_EPISODE_COUNT; episode_index++)); do
        echo "Validating episode ${episode_index}..."
        PYTHONPATH="${REPO_ROOT}" LD_PRELOAD="${PYTHON_LD_PRELOAD}" "${PYTHON_BIN}" "${SCRIPT_DIR}/validate_realtime_episode.py" \
            "${DATASET_ROOT}" \
            --episode-index "${episode_index}"
    done
fi
