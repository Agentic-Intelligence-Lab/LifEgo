#!/usr/bin/env python3

import argparse
import datetime as dt
import json
import shutil
import subprocess
import sys
import time
import tkinter as tk
from pathlib import Path
from tkinter import font as tkfont
from tkinter import messagebox
from tkinter import ttk

import numpy as np
from PIL import Image, ImageDraw, ImageTk
import pyarrow.parquet as pq

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from delete_last_episode import (
    delete_last_episode,
)
from lerobot.common.datasets.lerobot_dataset import LeRobotDataset, LeRobotDatasetMetadata
from lerobot.common.datasets.utils import get_features_from_robot
from lerobot.common.robot_devices.cameras.configs import IntelRealSenseCameraConfig
from lerobot.common.robot_devices.motors.configs import PiperMotorsBusConfig
from lerobot.common.robot_devices.robots.configs import PiperRobotConfig
from lerobot.common.robot_devices.robots.piper import PiperRobot


CAMERA_LABELS = {
    "head": "Head View",
    "left_wrist": "Left Wrist View",
    "right_wrist": "Right Wrist View",
    "front_view": "Front View",
}

REVIEW_LOG_PATH = Path("meta/review_actions.jsonl")
BAD_MANIFEST_NAME = "manifest.jsonl"
STATE_STATIC_THRESHOLD = 1e-4
STATE_LOW_MOTION_THRESHOLD = 1e-3
STATE_JUMP_THRESHOLD = 0.35
EE_STATIC_THRESHOLD = 1e-5
EE_JUMP_THRESHOLD = 0.25
VIDEO_DUPLICATE_DIFF_THRESHOLD = 1.0
VIDEO_STATIC_SECONDS = 2.0
VIDEO_MOTION_SAMPLE_FPS = 5.0
VIDEO_BLACK_LUMA_THRESHOLD = 8.0
VIDEO_BLACK_SECONDS = 1.0
REAL_TIME_TIMESTAMP_MODE = "real_time"
MIN_MANUAL_STOP_FRAMES = 2
RECORDING_PREVIEW_FPS = 10.0
REVIEW_REPLAY_FPS = 30.0


def _load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


def _load_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def _append_jsonl(path: Path, row: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False))
        f.write("\n")


def _episode_chunk(info: dict, episode_index: int) -> int:
    return episode_index // max(int(info.get("chunks_size", 1000)), 1)


def _episode_parquet_path(dataset_root: Path, info: dict, episode_index: int) -> Path:
    return dataset_root / info["data_path"].format(
        episode_chunk=_episode_chunk(info, episode_index),
        episode_index=episode_index,
    )


def _video_feature_keys(info: dict) -> list[str]:
    return [key for key, feature in info["features"].items() if feature["dtype"] == "video"]


def _episode_video_paths(dataset_root: Path, info: dict, episode_index: int) -> dict[str, Path]:
    template = info.get("video_path")
    if not template:
        return {}
    chunk = _episode_chunk(info, episode_index)
    return {
        key: dataset_root / template.format(
            episode_chunk=chunk,
            video_key=key,
            episode_index=episode_index,
        )
        for key in _video_feature_keys(info)
    }


def _episode_artifact_paths(dataset_root: Path, info: dict, episode_index: int) -> dict[str, str | dict[str, str]]:
    return {
        "parquet": str(_episode_parquet_path(dataset_root, info, episode_index)),
        "videos": {key: str(path) for key, path in _episode_video_paths(dataset_root, info, episode_index).items()},
        "episodes_jsonl": str(dataset_root / "meta" / "episodes.jsonl"),
        "episodes_stats_jsonl": str(dataset_root / "meta" / "episodes_stats.jsonl"),
        "info_json": str(dataset_root / "meta" / "info.json"),
    }


def _stack_column(table, column_name: str, dtype=np.float64) -> np.ndarray:
    return np.stack([np.asarray(x, dtype=dtype) for x in table[column_name].to_pylist()], axis=0)


def _scalar_column(table, column_name: str, dtype=np.float64) -> np.ndarray:
    return np.asarray(table[column_name].to_pylist(), dtype=dtype)


def _parse_fraction(value: str | None) -> float | None:
    if not value or value == "0/0":
        return None
    try:
        num, denom = map(int, value.split("/"))
    except ValueError:
        return None
    return None if denom == 0 else num / denom


def _ffprobe_stream(video_path: Path) -> dict:
    probe = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=nb_frames,avg_frame_rate,r_frame_rate,duration,width,height,codec_name,pix_fmt",
            "-of",
            "json",
            str(video_path),
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=True,
    )
    streams = json.loads(probe.stdout).get("streams", [])
    if not streams:
        raise RuntimeError("no video stream")
    return streams[0]


def _video_motion_summary(video_path: Path, fps: float) -> dict:
    width, height = 80, 60
    sample_fps = min(max(float(fps), 1.0), VIDEO_MOTION_SAMPLE_FPS)
    try:
        decode = subprocess.run(
            [
                "ffmpeg",
                "-v",
                "error",
                "-i",
                str(video_path),
                "-vf",
                f"fps={sample_fps},scale={width}:{height},format=gray",
                "-f",
                "rawvideo",
                "-",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
        )
    except Exception as exc:
        return {"checked": False, "warning": f"ffmpeg motion decode failed: {exc}"}

    frame_size = width * height
    if not decode.stdout or len(decode.stdout) < frame_size:
        return {"checked": False, "warning": "ffmpeg returned no decodable frames"}

    raw = np.frombuffer(decode.stdout, dtype=np.uint8)
    frame_count = raw.size // frame_size
    raw = raw[: frame_count * frame_size]
    frames = raw.reshape(frame_count, frame_size).astype(np.float32)
    frame_luma = frames.mean(axis=1)
    dark_flags = frame_luma <= VIDEO_BLACK_LUMA_THRESHOLD
    longest_dark_run = 0
    current_dark_run = 0
    for is_dark in dark_flags:
        if is_dark:
            current_dark_run += 1
            longest_dark_run = max(longest_dark_run, current_dark_run)
        else:
            current_dark_run = 0
    if frame_count < 2:
        return {
            "checked": True,
            "mean_absdiff": 0.0,
            "duplicate_ratio": 1.0,
            "longest_static_run": 0,
            "mean_luma": float(frame_luma.mean()),
            "dark_frame_ratio": float(np.mean(dark_flags)),
            "longest_dark_seconds": float(longest_dark_run / max(sample_fps, 1e-6)),
        }

    diffs_np = np.mean(np.abs(np.diff(frames, axis=0)), axis=1)
    duplicate_flags = diffs_np <= VIDEO_DUPLICATE_DIFF_THRESHOLD
    longest_duplicate_run = 0
    current_run = 0
    for duplicate in duplicate_flags:
        if duplicate:
            current_run += 1
            longest_duplicate_run = max(longest_duplicate_run, current_run)
        else:
            current_run = 0

    duplicate_ratio = float(np.mean(diffs_np <= VIDEO_DUPLICATE_DIFF_THRESHOLD))
    return {
        "checked": True,
        "mean_absdiff": float(diffs_np.mean()),
        "median_absdiff": float(np.median(diffs_np)),
        "duplicate_ratio": duplicate_ratio,
        "longest_static_run": int(longest_duplicate_run),
        "longest_static_seconds": float(longest_duplicate_run / max(sample_fps, 1e-6)),
        "mean_luma": float(frame_luma.mean()),
        "dark_frame_ratio": float(np.mean(dark_flags)),
        "longest_dark_run": int(longest_dark_run),
        "longest_dark_seconds": float(longest_dark_run / max(sample_fps, 1e-6)),
        "sample_fps": float(sample_fps),
    }


def _wrapped_frame_diffs(values: np.ndarray, column_name: str) -> np.ndarray:
    diffs = np.diff(values, axis=0)
    if column_name.endswith("ee_pose") and values.shape[1] == 12:
        angle_dims = [3, 4, 5, 9, 10, 11]
        diffs[:, angle_dims] = (diffs[:, angle_dims] + np.pi) % (2.0 * np.pi) - np.pi
    return diffs


def _check_numeric_feature(
    report: dict,
    table,
    column_name: str,
    expected_dim: int,
    *,
    static_threshold: float,
    low_motion_threshold: float,
    jump_threshold: float,
) -> np.ndarray | None:
    if column_name not in table.column_names:
        report["errors"].append(f"Missing parquet column: {column_name}")
        return None
    values = _stack_column(table, column_name)
    report["columns"][column_name] = {
        "shape": list(values.shape),
        "finite": bool(np.isfinite(values).all()),
        "ptp": np.ptp(values, axis=0).round(6).tolist() if values.size else [],
    }
    if values.ndim != 2 or values.shape[1] != expected_dim:
        report["errors"].append(f"{column_name} dimension is {list(values.shape)}, expected (*, {expected_dim})")
    if not np.isfinite(values).all():
        report["errors"].append(f"{column_name} contains NaN or Inf")
    if values.size:
        ptp = np.ptp(values, axis=0)
        low_dims = np.where(ptp < low_motion_threshold)[0].tolist()
        if float(np.max(ptp)) < static_threshold:
            report["warnings"].append(f"{column_name} is almost static across all dimensions")
        elif low_dims:
            report["warnings"].append(f"{column_name} low-motion dimensions: {low_dims}")
    if len(values) > 1:
        max_jump = float(np.max(np.abs(_wrapped_frame_diffs(values, column_name))))
        report["columns"][column_name]["max_abs_frame_jump"] = max_jump
        if max_jump > jump_threshold:
            report["warnings"].append(f"{column_name} has a large frame-to-frame jump: {max_jump:.4f}")
    return values


def validate_episode_for_review(dataset_root: Path, episode_index: int, target_fps: float) -> dict:
    info = _load_json(dataset_root / "meta" / "info.json")
    episodes = _load_jsonl(dataset_root / "meta" / "episodes.jsonl")
    episode_rows = {int(row["episode_index"]): row for row in episodes}
    report = {
        "episode_index": int(episode_index),
        "status": "OK",
        "errors": [],
        "warnings": [],
        "columns": {},
        "videos": {},
        "artifacts": _episode_artifact_paths(dataset_root, info, episode_index),
    }

    if episode_index not in episode_rows:
        report["errors"].append(f"Episode {episode_index} is missing from meta/episodes.jsonl")
        report["status"] = "ERROR"
        return report

    parquet_path = _episode_parquet_path(dataset_root, info, episode_index)
    if not parquet_path.exists():
        report["errors"].append(f"Missing parquet file: {parquet_path}")
        report["status"] = "ERROR"
        return report

    table = pq.read_table(parquet_path)
    row_count = int(table.num_rows)
    expected_parquet_columns = {
        key for key, feature in info["features"].items() if feature["dtype"] not in {"video", "image"}
    }
    actual_columns = set(table.column_names)
    missing_columns = sorted(expected_parquet_columns - actual_columns)
    extra_columns = sorted(actual_columns - expected_parquet_columns)
    if missing_columns:
        report["errors"].append(f"Missing parquet columns: {missing_columns}")
    if extra_columns:
        report["warnings"].append(f"Unexpected parquet columns: {extra_columns}")

    expected_length = int(episode_rows[episode_index].get("length", -1))
    report["row_count"] = row_count
    report["episode_length"] = expected_length
    if row_count != expected_length:
        report["errors"].append(f"Parquet rows ({row_count}) do not match episode metadata length ({expected_length})")
    if episode_rows[episode_index].get("real_duration_s") is not None:
        expected_from_duration = int(round(float(episode_rows[episode_index]["real_duration_s"]) * target_fps))
        report["expected_frames_from_duration"] = expected_from_duration
        if abs(row_count - expected_from_duration) > 2:
            report["warnings"].append(
                f"Frame count {row_count} differs from duration*fps estimate {expected_from_duration}"
            )

    state = _check_numeric_feature(
        report,
        table,
        "observation.state",
        14,
        static_threshold=STATE_STATIC_THRESHOLD,
        low_motion_threshold=STATE_LOW_MOTION_THRESHOLD,
        jump_threshold=STATE_JUMP_THRESHOLD,
    )
    action = _check_numeric_feature(
        report,
        table,
        "action",
        14,
        static_threshold=STATE_STATIC_THRESHOLD,
        low_motion_threshold=STATE_LOW_MOTION_THRESHOLD,
        jump_threshold=STATE_JUMP_THRESHOLD,
    )
    ee_pose = _check_numeric_feature(
        report,
        table,
        "observation.ee_pose",
        12,
        static_threshold=EE_STATIC_THRESHOLD,
        low_motion_threshold=EE_STATIC_THRESHOLD,
        jump_threshold=EE_JUMP_THRESHOLD,
    )
    action_ee = _check_numeric_feature(
        report,
        table,
        "action.ee_pose",
        12,
        static_threshold=EE_STATIC_THRESHOLD,
        low_motion_threshold=EE_STATIC_THRESHOLD,
        jump_threshold=EE_JUMP_THRESHOLD,
    )
    if state is not None and action is not None and len(state) > 1 and len(action) > 1:
        next_mae = float(np.abs(action[:-1] - state[1:]).mean())
        report["next_state_action_mae"] = next_mae
        if next_mae > 1e-6:
            report["warnings"].append(f"action does not match next observation.state exactly; MAE={next_mae:.6g}")
    if ee_pose is not None and action_ee is not None and len(ee_pose) > 1 and len(action_ee) > 1:
        next_ee_mae = float(np.abs(action_ee[:-1] - ee_pose[1:]).mean())
        report["next_ee_action_mae"] = next_ee_mae
        if next_ee_mae > 1e-6:
            report["warnings"].append(f"action.ee_pose does not match next observation.ee_pose exactly; MAE={next_ee_mae:.6g}")

    for scalar_col in [
        "timestamp",
        "real_observation_timestamp_s",
        "real_action_timestamp_s",
        "real_observation_wall_time_ns",
        "real_action_wall_time_ns",
        "real_transition_delta_s",
        "real_transition_fps",
        "frame_index",
        "episode_index",
        "index",
        "task_index",
    ]:
        if scalar_col not in table.column_names:
            report["errors"].append(f"Missing parquet column: {scalar_col}")

    if "timestamp" in table.column_names:
        timestamps = _scalar_column(table, "timestamp")
        report["timestamp"] = {
            "first": float(timestamps[0]) if len(timestamps) else None,
            "last": float(timestamps[-1]) if len(timestamps) else None,
        }
        if len(timestamps) > 1:
            deltas = np.diff(timestamps)
            median_dt = float(np.median(deltas))
            actual_fps = 1.0 / median_dt if median_dt > 0.0 else 0.0
            report["timestamp"].update(
                {
                    "monotonic": bool(np.all(deltas > 0.0)),
                    "median_dt_s": median_dt,
                    "actual_fps_from_median_dt": actual_fps,
                    "min_dt_s": float(deltas.min()),
                    "max_dt_s": float(deltas.max()),
                }
            )
            if not np.all(deltas > 0.0):
                report["errors"].append("timestamp is not strictly increasing")
            if abs(actual_fps - target_fps) / max(target_fps, 1e-6) > 0.10:
                report["warnings"].append(f"timestamp FPS {actual_fps:.3f} differs from target {target_fps:.3f}")
            if median_dt > 0 and (float(deltas.max()) > median_dt * 3.0 or float(deltas.min()) < median_dt * 0.2):
                report["warnings"].append("timestamp interval outlier detected")

    if row_count > 0:
        if "frame_index" in table.column_names:
            frame_index = _scalar_column(table, "frame_index", dtype=np.int64)
            if not np.array_equal(frame_index, np.arange(row_count, dtype=np.int64)):
                report["errors"].append("frame_index is not contiguous from 0 to row_count-1")
        if "episode_index" in table.column_names:
            episode_index_values = _scalar_column(table, "episode_index", dtype=np.int64)
            if not np.all(episode_index_values == int(episode_index)):
                report["errors"].append("episode_index column is not constant for this episode")
        if "index" in table.column_names:
            index_values = _scalar_column(table, "index", dtype=np.int64)
            expected_global_start = sum(
                int(row.get("length", 0))
                for idx, row in episode_rows.items()
                if idx < int(episode_index)
            )
            expected_index = np.arange(expected_global_start, expected_global_start + row_count, dtype=np.int64)
            if not np.array_equal(index_values, expected_index):
                report["errors"].append(
                    f"index column is not contiguous from expected global start {expected_global_start}"
                )
        if "task_index" in table.column_names:
            task_index = _scalar_column(table, "task_index", dtype=np.int64)
            tasks_rows = _load_jsonl(dataset_root / "meta" / "tasks.jsonl")
            valid_task_indices = {int(row["task_index"]) for row in tasks_rows if "task_index" in row}
            if len(valid_task_indices) == 0:
                report["errors"].append("meta/tasks.jsonl is missing or empty")
            elif not set(task_index.tolist()).issubset(valid_task_indices):
                report["errors"].append(
                    f"task_index contains values outside meta/tasks.jsonl: {sorted(set(task_index.tolist()) - valid_task_indices)}"
                )
        if "real_observation_wall_time_ns" in table.column_names and "real_action_wall_time_ns" in table.column_names:
            obs_wall = _scalar_column(table, "real_observation_wall_time_ns", dtype=np.int64)
            action_wall = _scalar_column(table, "real_action_wall_time_ns", dtype=np.int64)
            if len(obs_wall) > 1 and not np.all(np.diff(obs_wall) > 0):
                report["errors"].append("real_observation_wall_time_ns is not strictly increasing")
            if not np.all(action_wall >= obs_wall):
                report["errors"].append("real_action_wall_time_ns is earlier than observation wall time")
        if "real_transition_delta_s" in table.column_names:
            transition_dt = _scalar_column(table, "real_transition_delta_s", dtype=np.float64)
            if not np.isfinite(transition_dt).all() or not np.all(transition_dt > 0.0):
                report["errors"].append("real_transition_delta_s contains non-finite or non-positive values")
            if "real_transition_fps" in table.column_names and np.all(transition_dt > 0.0):
                transition_fps = _scalar_column(table, "real_transition_fps", dtype=np.float64)
                inverse_fps = 1.0 / transition_dt
                if not np.allclose(transition_fps, inverse_fps, rtol=1e-3, atol=1e-3):
                    report["warnings"].append("real_transition_fps does not match 1 / real_transition_delta_s")

    video_frame_counts = []
    for key, video_path in _episode_video_paths(dataset_root, info, episode_index).items():
        entry = {"path": str(video_path), "exists": video_path.exists()}
        if not video_path.exists():
            report["errors"].append(f"Missing video for {key}: {video_path}")
            report["videos"][key] = entry
            continue
        try:
            stream = _ffprobe_stream(video_path)
            nb_frames = int(stream["nb_frames"]) if stream.get("nb_frames") else None
            avg_fps = _parse_fraction(stream.get("avg_frame_rate"))
            entry.update(
                {
                    "nb_frames": nb_frames,
                    "avg_fps": avg_fps,
                    "nominal_fps": _parse_fraction(stream.get("r_frame_rate")),
                    "duration_s": float(stream["duration"]) if stream.get("duration") else None,
                    "width": int(stream.get("width", 0)),
                    "height": int(stream.get("height", 0)),
                    "codec": stream.get("codec_name"),
                    "pix_fmt": stream.get("pix_fmt"),
                }
            )
            expected_shape = info["features"].get(key, {}).get("shape")
            if expected_shape and len(expected_shape) >= 2:
                expected_h, expected_w = int(expected_shape[0]), int(expected_shape[1])
                if entry["height"] != expected_h or entry["width"] != expected_w:
                    report["errors"].append(
                        f"{key} video resolution is {entry['width']}x{entry['height']}, expected {expected_w}x{expected_h}"
                    )
            if entry.get("codec") != "h264":
                report["warnings"].append(f"{key} codec is {entry.get('codec')}, expected h264")
            if entry.get("pix_fmt") != "yuv420p":
                report["warnings"].append(f"{key} pix_fmt is {entry.get('pix_fmt')}, expected yuv420p")
            if nb_frames is not None:
                video_frame_counts.append(nb_frames)
                if nb_frames != row_count:
                    report["errors"].append(f"{key} video frames ({nb_frames}) != parquet rows ({row_count})")
            if avg_fps and abs(avg_fps - target_fps) / max(target_fps, 1e-6) > 0.10:
                report["warnings"].append(f"{key} avg fps {avg_fps:.3f} differs from target {target_fps:.3f}")
            motion = _video_motion_summary(video_path, avg_fps or target_fps)
            entry["motion"] = motion
            if motion.get("checked"):
                if motion.get("longest_static_seconds", 0.0) >= VIDEO_STATIC_SECONDS:
                    report["warnings"].append(
                        f"{key} has a long near-duplicate frame run: {motion['longest_static_seconds']:.2f}s"
                    )
                if motion.get("duplicate_ratio", 0.0) > 0.60:
                    report["warnings"].append(f"{key} has many near-duplicate frames: {motion['duplicate_ratio']:.1%}")
                if motion.get("longest_dark_seconds", 0.0) >= VIDEO_BLACK_SECONDS:
                    report["warnings"].append(
                        f"{key} has a long very-dark/black frame run: {motion['longest_dark_seconds']:.2f}s"
                    )
                if motion.get("dark_frame_ratio", 0.0) > 0.10:
                    report["warnings"].append(
                        f"{key} has many very-dark/black frames: {motion['dark_frame_ratio']:.1%}"
                    )
            elif motion.get("warning"):
                report["warnings"].append(f"{key} motion check skipped: {motion['warning']}")
        except Exception as exc:
            report["errors"].append(f"Cannot inspect video {key}: {exc}")
        report["videos"][key] = entry

    if video_frame_counts and len(set(video_frame_counts)) > 1:
        report["errors"].append(f"Four camera frame counts differ: {video_frame_counts}")

    stats_rows = _load_jsonl(dataset_root / "meta" / "episodes_stats.jsonl")
    if len(episodes) != int(info.get("total_episodes", -1)):
        report["errors"].append("meta/info.json total_episodes does not match episodes.jsonl")
    if stats_rows and len(stats_rows) != len(episodes):
        report["errors"].append("episodes_stats.jsonl row count does not match episodes.jsonl")

    report["status"] = "ERROR" if report["errors"] else ("WARNING" if report["warnings"] else "OK")
    return report


def _camera_display_label(key: str) -> str:
    label = CAMERA_LABELS.get(key)
    if label is not None:
        return label

    words = [word for word in key.replace("-", "_").split("_") if word]
    pretty = " ".join(word.capitalize() for word in words) or key
    if pretty.lower().endswith(" view"):
        return pretty
    return f"{pretty} View"


def _parse_rotation_value(rotation):
    if rotation in (None, "none"):
        return None
    return int(rotation)


def _piper_follower_arms(left_can_name: str, right_can_name: str):
    default_config = PiperRobotConfig()
    left_default = default_config.follower_arms["left"]
    right_default = default_config.follower_arms["right"]
    return {
        "left": PiperMotorsBusConfig(can_name=left_can_name, motors=dict(left_default.motors)),
        "right": PiperMotorsBusConfig(can_name=right_can_name, motors=dict(right_default.motors)),
    }


def _load_robot_config(camera_json: str | None, left_can_name: str, right_can_name: str) -> PiperRobotConfig:
    follower_arms = _piper_follower_arms(left_can_name, right_can_name)
    if not camera_json:
        return PiperRobotConfig(follower_arms=follower_arms)

    raw_config = json.loads(camera_json)
    cameras = {}
    for key, camera_cfg in raw_config.items():
        camera_type = camera_cfg.get("type", "intelrealsense")
        if camera_type != "intelrealsense":
            raise ValueError(f"Unsupported camera type for GUI collection: {camera_type}")

        cameras[key] = IntelRealSenseCameraConfig(
            serial_number=int(camera_cfg["serial_number"]),
            fps=int(camera_cfg["fps"]) if camera_cfg.get("fps") is not None else None,
            width=int(camera_cfg["width"]) if camera_cfg.get("width") is not None else None,
            height=int(camera_cfg["height"]) if camera_cfg.get("height") is not None else None,
            force_hardware_reset=bool(camera_cfg.get("force_hardware_reset", False)),
            rotation=_parse_rotation_value(camera_cfg.get("rotation")),
        )

    return PiperRobotConfig(follower_arms=follower_arms, cameras=cameras)


class PiperCollectionGUI:
    def __init__(self, args):
        self.args = args
        self.robot_config = _load_robot_config(args.robot_cameras_json, args.left_can_name, args.right_can_name)
        self.camera_keys = list(self.robot_config.cameras)
        self.root = tk.Tk()
        self.root.title("Piper Data Collection")
        self.root.geometry("1840x1280")
        self.root.minsize(1620, 1080)
        self.root.configure(bg="#f3efe7")
        self.root.bind_all("<KeyPress-space>", self._on_space)
        self.root.bind_all("<KeyPress-BackSpace>", self._on_delete_last_episode)
        self.root.bind_all("<KeyPress-Escape>", self._on_escape)
        self.root.bind("<Configure>", self._on_resize)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

        self.robot = None
        self.dataset = None

        self.state = "booting"
        self.recorded_episodes = 0
        self.current_frame_count = 0
        self.episode_start_t = None
        self.pending_record_sample = None
        self.next_record_tick_deadline_t = None
        self.episode_first_real_timestamp_s = None
        self.episode_last_real_timestamp_s = None
        self.episode_first_wall_time_ns = None
        self.episode_last_wall_time_ns = None
        self.last_preview_t = 0.0
        self.last_recording_preview_t = 0.0
        self.space_requested = False
        self.stop_requested = False
        self.auto_close_scheduled = False
        self.resize_refresh_pending = False
        self.latest_images = {}
        self.tk_images = {}
        self.manual_stop_requested = False
        self.dataset_repair_note = ""
        self.last_review_report = None
        self.review_episode_index = None
        self.review_video_offsets = {key: 0 for key in self.camera_keys}
        self.review_replay_active = False
        self.review_video_caps = {}
        self.review_replay_frame_index = 0
        self.review_replay_total_frames = 0
        self.trace_image = None
        self.display_font = self._pick_font(
            ["Aptos Display", "SF Pro Display", "Segoe UI Variable", "Noto Sans", "DejaVu Sans", "Liberation Sans"],
            "TkDefaultFont",
        )
        self.body_font = self._pick_font(
            ["Aptos", "Segoe UI", "Noto Sans", "DejaVu Sans", "Liberation Sans"],
            "TkDefaultFont",
        )

        self._build_ui()
        self._initialize_backend()
        self._schedule_tick()
        self.root.after(100, self._claim_keyboard_focus)

    def _pick_font(self, preferred: list[str], fallback: str) -> str:
        available = set(tkfont.families(self.root))
        for family in preferred:
            if family in available:
                return family
        return fallback

    def _claim_keyboard_focus(self) -> None:
        try:
            self.root.focus_force()
        except tk.TclError:
            self.root.focus_set()

    def _camera_grid_columns(self) -> int:
        count = max(len(self.camera_keys), 1)
        if count <= 3:
            return count
        if count <= 4:
            return 2
        return 3

    def _camera_grid_rows(self) -> int:
        return max(1, (len(self.camera_keys) + self._camera_grid_columns() - 1) // self._camera_grid_columns())

    def _camera_row_min_height(self) -> int:
        return 360 if self._camera_grid_rows() == 1 else 260

    def _fallback_preview_thumbnail_size(self) -> tuple[int, int]:
        cols = self._camera_grid_columns()
        rows = self._camera_grid_rows()
        if cols == 1:
            return (1180, 700)
        if cols == 2:
            return (820, 460) if rows == 1 else (760, 320)
        return (560, 360)

    def _preview_thumbnail_size(self, key: str) -> tuple[int, int]:
        holder = self.camera_image_holders.get(key)
        if holder is None:
            return self._fallback_preview_thumbnail_size()

        width = max(holder.winfo_width(), 1)
        height = max(holder.winfo_height(), 1)
        if width <= 8 or height <= 8:
            return self._fallback_preview_thumbnail_size()
        return (width, height)

    def _set_panel_image(self, key: str, render: Image.Image) -> None:
        panel = self.camera_panels[key]
        target_w, target_h = self._preview_thumbnail_size(key)
        render = render.convert("RGB")
        render.thumbnail((target_w, target_h), Image.Resampling.LANCZOS)
        canvas = Image.new("RGB", (target_w, target_h), (223, 229, 234))
        paste_x = max((target_w - render.width) // 2, 0)
        paste_y = max((target_h - render.height) // 2, 0)
        canvas.paste(render, (paste_x, paste_y))
        photo = ImageTk.PhotoImage(canvas)
        panel.configure(image=photo)
        panel.image = photo
        self.tk_images[key] = photo

    def _make_placeholder(self, key: str, detail: str) -> tuple[np.ndarray, str, str]:
        frame = np.zeros((480, 640, 3), dtype=np.uint8)
        frame[:] = (230, 235, 240)
        frame[0:84, :, :] = (24, 52, 79)
        frame[84:, :, :] = (222, 228, 233)

        label = _camera_display_label(key)
        # Simple block lettering effect without adding new deps.
        frame[140:144, 56:584, :] = (188, 198, 208)
        frame[260:264, 56:584, :] = (188, 198, 208)
        return frame, label, detail

    def _render_placeholder_image(
        self,
        key: str,
        detail: str,
        subdetail: str | None = None,
    ) -> Image.Image:
        render_frame, label, detail = self._make_placeholder(key, detail)
        render = Image.fromarray(render_frame)
        draw = ImageDraw.Draw(render)
        draw.text((28, 22), label, fill=(255, 248, 214))
        draw.text((28, 120), detail, fill=(44, 61, 80))
        if subdetail:
            draw.text((28, 168), subdetail, fill=(96, 108, 122))
        return render

    def _missing_camera_summary(self) -> str:
        if self.robot is None or not getattr(self.robot, "unavailable_cameras", None):
            return ""

        parts = []
        for key, info in self.robot.unavailable_cameras.items():
            serial_number = info.get("serial_number", "unknown")
            parts.append(f"{_camera_display_label(key)} ({serial_number})")
        return ", ".join(parts)

    def _append_missing_camera_note(self, footer: str) -> str:
        summary = self._missing_camera_summary()
        parts = [footer]
        if summary:
            parts.append(f"Missing for this run: {summary}.")
        if self.dataset_repair_note:
            parts.append(self.dataset_repair_note)
        return " ".join(parts)

    def _build_ui(self):
        outer = tk.Frame(self.root, bg="#f3efe7", padx=24, pady=22)
        outer.pack(fill="both", expand=True)

        title = tk.Label(
            outer,
            text="Piper Passive Data Collection",
            bg="#f3efe7",
            fg="#18344f",
            font=(self.display_font, 34, "bold"),
        )
        title.pack(anchor="w")

        subtitle = tk.Label(
            outer,
            text="Press Space to start or finish an episode. Press Backspace to delete the last saved episode. Press Esc to close the window.",
            bg="#f3efe7",
            fg="#5a6d81",
            font=(self.body_font, 18),
        )
        subtitle.pack(anchor="w", pady=(6, 18))

        camera_grid = tk.Frame(outer, bg="#f3efe7")
        camera_grid.pack(fill="both", expand=True)

        for column in range(self._camera_grid_columns()):
            camera_grid.grid_columnconfigure(column, weight=1, uniform="camera_column")
        for row in range(self._camera_grid_rows()):
            camera_grid.grid_rowconfigure(row, weight=1, uniform="camera_row", minsize=self._camera_row_min_height())

        self.camera_panels = {}
        self.camera_image_holders = {}
        for index, key in enumerate(self.camera_keys):
            panel = tk.Frame(
                camera_grid,
                bg="#fffdf9",
                highlightbackground="#d8d0c2",
                highlightthickness=1,
                padx=10,
                pady=10,
            )
            row = index // self._camera_grid_columns()
            column = index % self._camera_grid_columns()
            panel.grid(row=row, column=column, sticky="nsew", padx=8, pady=8)

            title = tk.Label(
                panel,
                text=_camera_display_label(key),
                bg="#fffdf9",
                fg="#18344f",
                font=(self.display_font, 22, "bold"),
                pady=10,
            )
            title.pack(fill="x")

            image_holder = tk.Frame(panel, bg="#dfe5ea")
            image_holder.pack(fill="both", expand=True, padx=4, pady=(2, 4))
            image_holder.pack_propagate(False)
            image_label = tk.Label(image_holder, bg="#dfe5ea", bd=0, highlightthickness=0)
            image_label.pack(fill="both", expand=True)
            self.camera_panels[key] = image_label
            self.camera_image_holders[key] = image_holder

        info_card = tk.Frame(outer, bg="#fffdf9", highlightbackground="#d8d0c2", highlightthickness=1)
        info_card.pack(fill="x", expand=False, pady=(18, 0))

        top_info = tk.Frame(info_card, bg="#fffdf9", padx=22, pady=20)
        top_info.pack(fill="x")

        self.status_var = tk.StringVar(value="Starting up the robot and camera pipelines...")
        self.episode_var = tk.StringVar(value="Episode 1 of 1")
        self.frames_var = tk.StringVar(value="Frames captured: 0 / 0")
        self.remaining_var = tk.StringVar(value="Episodes left: 0")
        self.timer_var = tk.StringVar(value="Time remaining: 0.0s")
        self.dataset_var = tk.StringVar(value=f"Dataset: {self.args.dataset_name}")

        status_label = tk.Label(
            top_info,
            textvariable=self.status_var,
            bg="#fffdf9",
            fg="#17324d",
            anchor="w",
            justify="left",
            font=(self.display_font, 24, "bold"),
        )
        status_label.pack(fill="x", pady=(0, 12))

        for text_var in [self.episode_var, self.frames_var, self.remaining_var, self.timer_var, self.dataset_var]:
            label = tk.Label(
                top_info,
                textvariable=text_var,
                bg="#fffdf9",
                fg="#24384e",
                anchor="w",
                justify="left",
                font=(self.body_font, 18),
            )
            label.pack(fill="x", pady=3)

        self.progress = ttk.Progressbar(info_card, mode="determinate", maximum=100)
        self.progress.pack(fill="x", padx=22, pady=(0, 18))

        actions_row = tk.Frame(info_card, bg="#fffdf9", padx=22, pady=0)
        actions_row.pack(fill="x", pady=(0, 14))

        self.delete_button = tk.Button(
            actions_row,
            text="Delete Last Episode",
            command=self._on_delete_last_episode,
            bg="#fff3ed",
            fg="#8a2f21",
            activebackground="#f7dfd4",
            activeforeground="#7a261b",
            relief="flat",
            borderwidth=0,
            padx=18,
            pady=10,
            font=(self.body_font, 15, "bold"),
            cursor="hand2",
        )
        self.delete_button.pack(side="left")

        self.review_buttons = {}
        for label, command in [
            ("Accept", self._on_accept_episode),
            ("Delete", self._on_delete_review_episode),
            ("Quarantine", self._on_quarantine_review_episode),
            ("Replay", self._on_replay_episode),
            ("Show Trace", self._on_show_trace),
        ]:
            button = tk.Button(
                actions_row,
                text=label,
                command=command,
                bg="#eef4f8",
                fg="#18344f",
                activebackground="#dce9f0",
                activeforeground="#18344f",
                relief="flat",
                borderwidth=0,
                padx=16,
                pady=10,
                font=(self.body_font, 15, "bold"),
                cursor="hand2",
                state="disabled",
            )
            button.pack(side="left", padx=(14, 0))
            self.review_buttons[label] = button

        self.footer_var = tk.StringVar(
            value="Waiting for initialization..."
        )
        footer = tk.Label(
            info_card,
            textvariable=self.footer_var,
            bg="#fffdf9",
            fg="#6a7b8f",
            anchor="w",
            justify="left",
            font=(self.body_font, 16),
            wraplength=1680,
            padx=22,
            pady=0,
        )
        footer.pack(fill="x", pady=(0, 18))

        trace_card = tk.Frame(outer, bg="#fffdf9", highlightbackground="#d8d0c2", highlightthickness=1)
        trace_card.pack(fill="x", expand=False, pady=(16, 0))
        trace_title = tk.Label(
            trace_card,
            text="Episode State Trace",
            bg="#fffdf9",
            fg="#18344f",
            anchor="w",
            font=(self.display_font, 20, "bold"),
            padx=18,
            pady=8,
        )
        trace_title.pack(fill="x")
        trace_holder = tk.Frame(trace_card, bg="#f7f8fa", height=240)
        trace_holder.pack(fill="x", padx=18, pady=(0, 14))
        trace_holder.pack_propagate(False)
        self.trace_panel = tk.Label(trace_holder, bg="#f7f8fa", bd=0, highlightthickness=0)
        self.trace_panel.pack(fill="both", expand=True)

        style = ttk.Style()
        style.theme_use(style.theme_use())
        style.configure(
            "Horizontal.TProgressbar",
            troughcolor="#e4ddd1",
            background="#2d8f68",
            bordercolor="#e4ddd1",
            lightcolor="#2d8f68",
            darkcolor="#2d8f68",
            thickness=32,
        )
        self._set_review_controls_enabled(False)

    def _initialize_backend(self):
        self.robot = PiperRobot(self.robot_config)
        self.robot.connect()

        self.dataset = self._load_dataset_for_recording()
        self.recorded_episodes = len(self.dataset.meta.episodes)

        if self.recorded_episodes >= self.args.num_episodes:
            self.state = "done"
            self._set_status(
                "Requested episode count is already available.",
                footer="Press Backspace to delete the last saved episode, or press Esc to close the window.",
            )
        else:
            self.state = "ready"
            self._set_status(
                "Warming up live preview...",
                footer="The window stays responsive while each camera delivers its first frame.",
            )
        self._refresh_counts()

    def _read_dataset_info(self) -> dict:
        info_path = self.args.dataset_root / "meta" / "info.json"
        with info_path.open("r", encoding="utf-8") as f:
            return json.load(f)

    def _camera_feature_keys_from_info(self, info: dict) -> set[str]:
        return {
            key
            for key, feature in info["features"].items()
            if feature["dtype"] in {"video", "image"}
        }

    def _available_camera_feature_keys(self) -> set[str]:
        return {f"observation.images.{name}" for name in self.robot.cameras}

    def _normalize_features_for_comparison(self, features: dict) -> dict:
        normalized = {}
        for key, feature in features.items():
            feature_copy = dict(feature)
            if "shape" in feature_copy:
                feature_copy["shape"] = tuple(feature_copy["shape"])
            if feature_copy.get("dtype") in {"video", "image"}:
                feature_copy["info"] = None
            normalized[key] = feature_copy
        return normalized

    def _validate_resume_camera_compatibility(self) -> None:
        if not self.args.resume or not self.args.dataset_root.exists():
            return

        info = self._read_dataset_info()
        dataset_camera_keys = self._camera_feature_keys_from_info(info)
        available_camera_keys = self._available_camera_feature_keys()
        if dataset_camera_keys != available_camera_keys:
            expected = sorted(dataset_camera_keys)
            current = sorted(available_camera_keys)
            raise RuntimeError(
                "RESUME=true requires the same camera set as the existing dataset. "
                f"Dataset expects {expected}, but this run has {current}. "
                "Start a new dataset or reconnect the missing cameras."
            )

        existing_meta = LeRobotDatasetMetadata(self.args.dataset_name, self.args.dataset_root)
        if existing_meta.info.get("timestamp_mode") != REAL_TIME_TIMESTAMP_MODE:
            raise RuntimeError(
                "RESUME=true requires an existing dataset recorded in real_time timestamp mode. "
                "Start a new dataset root for the updated recorder."
            )

        existing_features = self._normalize_features_for_comparison(existing_meta.features)
        current_features = self._normalize_features_for_comparison(self._recording_features())
        if existing_features != current_features:
            raise RuntimeError(
                "RESUME=true requires the same dataset schema as the existing dataset. "
                "The current recorder writes next-state actions, ee pose, and real-time columns. "
                "Start a new dataset root for this schema, or migrate the existing dataset before resuming."
            )

    def _scalar_feature(self, value, dtype) -> np.ndarray:
        return np.array([value], dtype=dtype)

    def _ee_pose_names(self) -> list[str]:
        names = []
        for arm_name in self.robot.follower_arms:
            names.extend(
                [
                    f"{arm_name}_x_m",
                    f"{arm_name}_y_m",
                    f"{arm_name}_z_m",
                    f"{arm_name}_rx_rad",
                    f"{arm_name}_ry_rad",
                    f"{arm_name}_rz_rad",
                ]
            )
        return names

    def _recording_features(self) -> dict:
        features = get_features_from_robot(self.robot, use_videos=True)
        ee_pose_names = self._ee_pose_names()
        features["observation.ee_pose"] = {
            "dtype": "float32",
            "shape": (len(ee_pose_names),),
            "names": ee_pose_names,
        }
        features["action.ee_pose"] = {
            "dtype": "float32",
            "shape": (len(ee_pose_names),),
            "names": ee_pose_names,
        }
        for key, dtype in [
            ("real_observation_timestamp_s", "float64"),
            ("real_action_timestamp_s", "float64"),
            ("real_observation_wall_time_ns", "int64"),
            ("real_action_wall_time_ns", "int64"),
            ("real_transition_delta_s", "float64"),
            ("real_transition_fps", "float64"),
        ]:
            features[key] = {"dtype": dtype, "shape": (1,), "names": None}
        return features

    def _pose_dict_to_tensor(self, pose: dict):
        import torch

        return torch.as_tensor(
            [pose[name] for name in ["x", "y", "z", "rx", "ry", "rz"]],
            dtype=torch.float32,
        )

    def _capture_passive_record_observation(self) -> dict:
        if hasattr(self.robot, "capture_passive_record_observation"):
            return self.robot.capture_passive_record_observation()

        import torch

        state_parts = []
        ee_pose_parts = []
        for arm_name, arm in self.robot.follower_arms.items():
            before_read_t = time.perf_counter()
            if hasattr(arm, "read_observation"):
                arm_observation = arm.read_observation()
                state_dict = arm_observation["state"]
                ee_pose = arm_observation["ee_pose"]
            else:
                state_dict = arm.read()
                if not hasattr(arm, "read_ee_pose"):
                    raise RuntimeError(
                        f"Follower arm {arm_name} does not provide read_ee_pose(); cannot record EEF pose."
                    )
                ee_pose = arm.read_ee_pose()
            state_parts.append(self.robot._state_dict_to_tensor(arm, state_dict))
            ee_pose_parts.append(self._pose_dict_to_tensor(ee_pose))
            self.robot.logs[f"read_follower_{arm_name}_observation_dt_s"] = time.perf_counter() - before_read_t

        observation = {
            "observation.state": torch.cat(state_parts),
            "observation.ee_pose": torch.cat(ee_pose_parts),
        }
        for name, image in self.robot._capture_images().items():
            observation[f"observation.images.{name}"] = image
        return observation

    def _reset_episode_recording_state(self) -> None:
        self.current_frame_count = 0
        self.episode_start_t = None
        self.pending_record_sample = None
        self.next_record_tick_deadline_t = None
        self.last_recording_preview_t = 0.0
        self.space_requested = False
        self.manual_stop_requested = False
        self.episode_first_real_timestamp_s = None
        self.episode_last_real_timestamp_s = None
        self.episode_first_wall_time_ns = None
        self.episode_last_wall_time_ns = None

    def _capture_record_sample(self) -> dict:
        observation = self._capture_passive_record_observation()
        sample_time_s = time.perf_counter()
        return {
            "observation": observation,
            "elapsed_s": sample_time_s - self.episode_start_t,
            "wall_time_ns": time.time_ns(),
        }

    def _build_aligned_frame(self, current_sample: dict, next_sample: dict) -> dict:
        transition_dt_s = next_sample["elapsed_s"] - current_sample["elapsed_s"]
        transition_fps = 0.0 if transition_dt_s <= 0.0 else 1.0 / transition_dt_s

        if self.episode_first_real_timestamp_s is None:
            self.episode_first_real_timestamp_s = current_sample["elapsed_s"]
            self.episode_first_wall_time_ns = current_sample["wall_time_ns"]
        self.episode_last_real_timestamp_s = next_sample["elapsed_s"]
        self.episode_last_wall_time_ns = next_sample["wall_time_ns"]

        observation_timestamp_s = current_sample["elapsed_s"] - self.episode_first_real_timestamp_s
        action_timestamp_s = next_sample["elapsed_s"] - self.episode_first_real_timestamp_s

        return {
            **current_sample["observation"],
            "timestamp": self._scalar_feature(observation_timestamp_s, np.float32),
            "action": next_sample["observation"]["observation.state"].clone(),
            "action.ee_pose": next_sample["observation"]["observation.ee_pose"].clone(),
            "real_observation_timestamp_s": self._scalar_feature(observation_timestamp_s, np.float64),
            "real_action_timestamp_s": self._scalar_feature(action_timestamp_s, np.float64),
            "real_observation_wall_time_ns": self._scalar_feature(current_sample["wall_time_ns"], np.int64),
            "real_action_wall_time_ns": self._scalar_feature(next_sample["wall_time_ns"], np.int64),
            "real_transition_delta_s": self._scalar_feature(transition_dt_s, np.float64),
            "real_transition_fps": self._scalar_feature(transition_fps, np.float64),
            "task": self.args.single_task,
        }

    def _record_sample(self) -> None:
        current_sample = self._capture_record_sample()
        if self.pending_record_sample is None:
            self.pending_record_sample = current_sample
            return

        frame = self._build_aligned_frame(self.pending_record_sample, current_sample)
        self.dataset.add_frame(frame)
        self.pending_record_sample = current_sample
        self.current_frame_count += 1

    def _current_episode_metadata(self) -> dict | None:
        if (
            self.current_frame_count <= 0
            or self.episode_first_real_timestamp_s is None
            or self.episode_last_real_timestamp_s is None
            or self.episode_first_wall_time_ns is None
            or self.episode_last_wall_time_ns is None
        ):
            return None

        real_duration_s = self.episode_last_real_timestamp_s - self.episode_first_real_timestamp_s
        actual_fps = 0.0 if real_duration_s <= 0.0 else self.current_frame_count / real_duration_s
        return {
            "real_duration_s": float(real_duration_s),
            "actual_fps": float(actual_fps),
            "first_observation_time_s": float(self.episode_first_real_timestamp_s),
            "last_action_time_s": float(self.episode_last_real_timestamp_s),
            "first_observation_wall_time_ns": int(self.episode_first_wall_time_ns),
            "last_action_wall_time_ns": int(self.episode_last_wall_time_ns),
        }

    def _format_episode_summary(self, episode_metadata: dict | None) -> str:
        if not episode_metadata:
            return ""
        return (
            f"Last saved episode real duration: {episode_metadata['real_duration_s']:.3f}s. "
            f"Actual recorded FPS: {episode_metadata['actual_fps']:.3f}."
        )

    def _build_recording_dataset_from_existing_root(self) -> LeRobotDataset:
        for relative_path in ["meta/tasks.jsonl", "meta/episodes.jsonl", "meta/episodes_stats.jsonl"]:
            path = self.args.dataset_root / relative_path
            path.parent.mkdir(parents=True, exist_ok=True)
            path.touch(exist_ok=True)

        dataset = LeRobotDataset.__new__(LeRobotDataset)
        dataset.meta = LeRobotDatasetMetadata(self.args.dataset_name, self.args.dataset_root)
        dataset.repo_id = dataset.meta.repo_id
        dataset.root = dataset.meta.root
        dataset.revision = None
        dataset.tolerance_s = 1e-4
        dataset.image_writer = None
        next_episode_index = len(dataset.meta.episodes)
        dataset.episode_buffer = dataset.create_episode_buffer(episode_index=next_episode_index)
        dataset.episodes = None
        dataset.hf_dataset = dataset.create_hf_dataset()
        dataset.image_transforms = None
        dataset.delta_timestamps = None
        dataset.delta_indices = None
        dataset.episode_data_index = None
        dataset.video_backend = "pyav"
        return dataset

    def _repair_existing_dataset_if_needed(self) -> None:
        if not self.args.dataset_root.exists():
            self.dataset_repair_note = ""
            return

        info = _load_json(self.args.dataset_root / "meta" / "info.json")
        episodes = _load_jsonl(self.args.dataset_root / "meta" / "episodes.jsonl")
        episode_stats = _load_jsonl(self.args.dataset_root / "meta" / "episodes_stats.jsonl")
        expected_indices = list(range(len(episodes)))
        episode_indices = [int(row["episode_index"]) for row in episodes]
        stats_indices = [int(row["episode_index"]) for row in episode_stats]
        aligned = (
            int(info.get("total_episodes", -1)) == len(episodes)
            and episode_indices == expected_indices
            and (not episode_stats or stats_indices == expected_indices)
            and (not episode_stats or len(episode_stats) == len(episodes))
        )
        if not aligned:
            raise RuntimeError(
                "Dataset metadata is not contiguous/aligned. The recovered recorder refuses to auto-delete "
                "or auto-trim episodes. Use manual review/quarantine repair before resuming collection."
            )
        self.dataset_repair_note = ""

    def _load_dataset_from_disk(self) -> LeRobotDataset:
        self._repair_existing_dataset_if_needed()
        dataset = self._build_recording_dataset_from_existing_root()

        dataset.start_image_writer(
            num_processes=0,
            num_threads=4 * len(self.robot.cameras),
        )
        next_episode_index = len(dataset.meta.episodes)
        dataset.episode_buffer = dataset.create_episode_buffer(episode_index=next_episode_index)
        next_artifacts = [_episode_parquet_path(dataset.root, dataset.meta.info, next_episode_index)]
        next_artifacts.extend(_episode_video_paths(dataset.root, dataset.meta.info, next_episode_index).values())
        existing_artifacts = [str(path) for path in next_artifacts if path.exists()]
        if existing_artifacts:
            raise RuntimeError(
                "Refusing to auto-clear files for the next episode index because that would delete data. "
                f"Inspect or quarantine these files manually first: {existing_artifacts}"
            )
        return dataset

    def _load_dataset_for_recording(self) -> LeRobotDataset:
        if self.args.resume and self.args.dataset_root.exists():
            self._validate_resume_camera_compatibility()
            return self._load_dataset_from_disk()

        dataset = LeRobotDataset.create(
            self.args.dataset_name,
            self.args.fps,
            root=self.args.dataset_root,
            robot_type=self.robot.robot_type,
            features=self._recording_features(),
            use_videos=True,
            image_writer_processes=0,
            image_writer_threads=4 * len(self.robot.cameras),
        )
        if dataset.meta.info.get("timestamp_mode") != REAL_TIME_TIMESTAMP_MODE:
            dataset.meta.info["timestamp_mode"] = REAL_TIME_TIMESTAMP_MODE
            _write_json(dataset.root / "meta" / "info.json", dataset.meta.info)
        return dataset

    def _reload_existing_dataset(self):
        if self.dataset is not None:
            try:
                self.dataset.stop_image_writer()
            except Exception:
                pass

        self.dataset = self._load_dataset_from_disk()
        self.recorded_episodes = len(self.dataset.meta.episodes)

    def _can_delete_last_episode(self) -> bool:
        return self.state in {"ready", "done"} and self.recorded_episodes > 0

    def _minimum_manual_stop_frames(self) -> int:
        return max(MIN_MANUAL_STOP_FRAMES, int(round(float(self.args.fps) * 0.1)))

    def _count_ready_cameras(self) -> int:
        return sum(1 for camera in self.robot.cameras.values() if camera.color_image is not None)

    def _all_cameras_ready(self) -> bool:
        return self._count_ready_cameras() == len(self.robot.cameras)

    def _set_status(self, status: str, footer: str | None = None):
        self.status_var.set(status)
        if footer is not None:
            self.footer_var.set(footer)

    def _set_review_controls_enabled(self, enabled: bool) -> None:
        for label, button in getattr(self, "review_buttons", {}).items():
            if enabled:
                button.configure(state="normal")
            elif label == "Show Trace" and self.state in {"ready", "done"} and self.recorded_episodes > 0:
                button.configure(state="normal")
            else:
                button.configure(state="disabled")

    def _review_summary_text(self, report: dict) -> str:
        lines = [
            f"Episode {report.get('episode_index')} review: {report.get('status')}",
            f"Rows: {report.get('row_count')}  Metadata length: {report.get('episode_length')}",
        ]
        timestamp = report.get("timestamp") or {}
        if timestamp:
            lines.append(
                "Timestamp: "
                f"fps={timestamp.get('actual_fps_from_median_dt', 0.0):.3f}, "
                f"dt median={timestamp.get('median_dt_s', 0.0):.5f}s"
            )
        for key, video in sorted((report.get("videos") or {}).items()):
            lines.append(
                f"{key}: frames={video.get('nb_frames')} fps={video.get('avg_fps')} "
                f"codec={video.get('codec')} static={video.get('motion', {}).get('longest_static_seconds')} "
                f"dark={video.get('motion', {}).get('longest_dark_seconds')}"
            )
        notices = (report.get("errors") or []) + (report.get("warnings") or [])
        if notices:
            lines.append("Warnings:")
            lines.extend(f"- {item}" for item in notices[:12])
            if len(notices) > 12:
                lines.append(f"- ... {len(notices) - 12} more")
        else:
            lines.append("No automatic risk flags.")
        return "\n".join(lines)

    def _write_review_log(self, action: str, episode_index: int, details: dict | None = None) -> None:
        row = {
            "time": dt.datetime.now(dt.timezone.utc).isoformat(),
            "action": action,
            "episode_index": int(episode_index),
            "dataset_root": str(self.args.dataset_root),
            "details": details or {},
        }
        _append_jsonl(self.args.dataset_root / REVIEW_LOG_PATH, row)

    def _quarantine_base_root(self) -> Path:
        return self.args.dataset_root.parent / f"{self.args.dataset_root.name}_quarantine"

    def _quarantine_episode_root(self, episode_index: int) -> Path:
        return self._quarantine_base_root() / "bad_episodes" / f"episode_{episode_index:06d}"

    def _quarantine_manifest_path(self) -> Path:
        return self._quarantine_base_root() / "bad_episodes" / BAD_MANIFEST_NAME

    def _ensure_review_episode_is_last(self) -> None:
        if self.review_episode_index is None:
            raise RuntimeError("No episode is in review.")
        info = _load_json(self.args.dataset_root / "meta" / "info.json")
        expected_last = int(info.get("total_episodes", 0)) - 1
        if int(self.review_episode_index) != expected_last:
            raise RuntimeError(
                "Refusing to modify a non-last episode from the recorder GUI. "
                f"Review episode={self.review_episode_index}, metadata last={expected_last}. "
                "Use quarantine from the immediate review step, or repair the dataset manually."
            )

    def _validate_last_episode_metadata_update(self, episode_index: int) -> None:
        info = _load_json(self.args.dataset_root / "meta" / "info.json")
        episodes = _load_jsonl(self.args.dataset_root / "meta" / "episodes.jsonl")
        episode_stats = _load_jsonl(self.args.dataset_root / "meta" / "episodes_stats.jsonl")
        expected_last = int(info.get("total_episodes", 0)) - 1
        if expected_last != int(episode_index):
            raise RuntimeError(f"Expected last episode {expected_last}, got {episode_index}.")
        if not episodes or int(episodes[-1]["episode_index"]) != int(episode_index):
            raise RuntimeError("episodes.jsonl is not aligned with the requested last episode.")
        if episode_stats and int(episode_stats[-1]["episode_index"]) != int(episode_index):
            raise RuntimeError("episodes_stats.jsonl is not aligned with the requested last episode.")
        expected_indices = list(range(len(episodes)))
        if [int(row["episode_index"]) for row in episodes] != expected_indices:
            raise RuntimeError("episodes.jsonl is not contiguous; refusing automatic metadata update.")
        if episode_stats and [int(row["episode_index"]) for row in episode_stats] != expected_indices:
            raise RuntimeError("episodes_stats.jsonl is not contiguous; refusing automatic metadata update.")

    def _format_artifact_confirmation(self, report: dict, action: str, destination: str | None = None) -> str:
        artifacts = report.get("artifacts") or {}
        videos = artifacts.get("videos") or {}
        lines = [
            f"{action} Episode {report.get('episode_index')}?",
            "",
            f"Parquet: {artifacts.get('parquet')}",
            "Videos:",
        ]
        lines.extend(f"- {key}: {path}" for key, path in videos.items())
        if destination:
            lines.extend(["", f"Destination: {destination}"])
        lines.extend(
            [
                "",
                "Metadata/index entries:",
                f"- {artifacts.get('info_json')}",
                f"- {artifacts.get('episodes_jsonl')}",
                f"- {artifacts.get('episodes_stats_jsonl')}",
                "",
                "This operation requires explicit confirmation and will be logged.",
            ]
        )
        return "\n".join(lines)

    def _enter_review_state(self, episode_index: int) -> None:
        self.state = "reviewing"
        self.review_episode_index = episode_index
        self._set_review_controls_enabled(True)
        self._set_status(
            f"Reviewing Episode {episode_index + 1}.",
            footer="Automatic checks are running. No data will be deleted automatically.",
        )
        self.root.update_idletasks()
        report = validate_episode_for_review(self.args.dataset_root, episode_index, float(self.args.fps))
        self.last_review_report = report
        self._render_state_trace(episode_index, report)
        status_text = "Accepted checks" if report["status"] == "OK" else f"{report['status']} flags"
        self._set_status(
            f"Review Episode {episode_index + 1}: {status_text}.",
            footer=self._review_summary_text(report),
        )
        self._load_review_video_frames(episode_index, frame_offset=0)
        self.root.after(300, lambda ep=episode_index: self._start_review_replay(ep, auto=True))

    def _leave_review_for_next_episode(self, message: str) -> None:
        self.last_review_report = None
        self.review_episode_index = None
        self._stop_review_replay()
        self._set_review_controls_enabled(False)
        if self.recorded_episodes >= self.args.num_episodes:
            self.state = "done"
            self._set_status(message, footer="All requested episodes are complete. Press Esc to close.")
        else:
            self.state = "ready"
            self._set_status(
                message,
                footer="Ready for the next episode. Press Space to record.",
            )

    def _render_state_trace(self, episode_index: int, report: dict | None = None) -> None:
        info = _load_json(self.args.dataset_root / "meta" / "info.json")
        parquet_path = _episode_parquet_path(self.args.dataset_root, info, episode_index)
        if not parquet_path.exists():
            return
        table = pq.read_table(parquet_path, columns=["observation.state"])
        state = _stack_column(table, "observation.state", dtype=np.float64)
        width = max(self.trace_panel.winfo_width() - 36, 1200)
        height = 220
        img = Image.new("RGB", (width, height), (247, 248, 250))
        draw = ImageDraw.Draw(img)
        margin_l, margin_r, margin_t, margin_b = 58, 16, 22, 34
        plot_w = width - margin_l - margin_r
        plot_h = height - margin_t - margin_b
        draw.rectangle([margin_l, margin_t, width - margin_r, height - margin_b], outline=(205, 212, 220))
        for frac in [0.25, 0.5, 0.75]:
            y = margin_t + int(plot_h * frac)
            draw.line([margin_l, y, width - margin_r, y], fill=(226, 230, 235))
        if state.size:
            x = np.linspace(margin_l, margin_l + plot_w, state.shape[0])
            colors = [
                (31, 98, 141), (207, 87, 64), (65, 136, 92), (133, 92, 164), (211, 142, 48), (80, 85, 94), (0, 137, 123),
                (78, 121, 167), (242, 142, 43), (89, 161, 79), (176, 122, 161), (225, 87, 89), (156, 117, 95), (118, 183, 178),
            ]
            for dim in range(min(14, state.shape[1])):
                values = state[:, dim]
                v_min = float(np.min(values))
                v_max = float(np.max(values))
                scale = max(v_max - v_min, 1e-6)
                y = margin_t + plot_h - ((values - v_min) / scale * plot_h)
                points = list(zip(x.astype(int), y.astype(int)))
                if len(points) > 1:
                    draw.line(points, fill=colors[dim % len(colors)], width=2)
            draw.text((margin_l, 4), f"Episode {episode_index} state trace: 14 dims, {state.shape[0]} frames", fill=(36, 56, 78))
            if report and (report.get("errors") or report.get("warnings")):
                draw.text((margin_l + 420, 4), f"{report.get('status')} flags: {len(report.get('errors', []))} errors, {len(report.get('warnings', []))} warnings", fill=(145, 72, 36))
        photo = ImageTk.PhotoImage(img)
        self.trace_panel.configure(image=photo)
        self.trace_panel.image = photo
        self.trace_image = photo

    def _refresh_counts(self):
        total = self.args.num_episodes
        current = total if self.recorded_episodes >= total else self.recorded_episodes + 1
        self.episode_var.set(f"Episode {current} of {total}")
        target_frames = max(1, round(self.args.episode_time_s * self.args.fps))
        self.frames_var.set(f"Frames captured: {self.current_frame_count} / {target_frames}")
        self.remaining_var.set(f"Episodes left: {max(total - self.recorded_episodes, 0)}")

        if self.state == "recording" and self.episode_start_t is not None:
            elapsed = time.perf_counter() - self.episode_start_t
            time_left = max(self.args.episode_time_s - elapsed, 0.0)
            self.timer_var.set(f"Time remaining: {time_left:0.1f}s")
            progress = min(elapsed / self.args.episode_time_s, 1.0) * 100.0
            self.progress["value"] = progress
        else:
            self.timer_var.set(f"Time remaining: {self.args.episode_time_s:0.1f}s")
            self.progress["value"] = 0

        if self.delete_button is not None:
            self.delete_button.configure(state="normal" if self._can_delete_last_episode() else "disabled")
        self._set_review_controls_enabled(self.state == "reviewing")

    def _schedule_tick(self):
        if self.state == "recording" and self.next_record_tick_deadline_t is not None:
            interval_s = max(self.next_record_tick_deadline_t - time.perf_counter(), 0.0)
            interval_ms = max(1, int(interval_s * 1000))
        else:
            interval_ms = max(1, int(1000 / self.args.fps))
        self.root.after(interval_ms, self._tick)

    def _refresh_preview_now(self) -> None:
        if self.robot is None or self.state not in {"ready", "recording", "done"}:
            return

        if self.state == "recording":
            observation = self.pending_record_sample["observation"] if self.pending_record_sample is not None else {}
            self._update_preview_from_observation(observation)
        else:
            self._update_preview_from_cameras()

    def _maybe_update_recording_preview(self) -> None:
        now = time.perf_counter()
        min_interval_s = 1.0 / max(RECORDING_PREVIEW_FPS, 1e-6)
        if self.last_recording_preview_t and now - self.last_recording_preview_t < min_interval_s:
            return

        observation = self.pending_record_sample["observation"] if self.pending_record_sample is not None else {}
        self._update_preview_from_observation(observation)
        self.last_recording_preview_t = now

    def _on_resize(self, _event=None):
        if self.resize_refresh_pending:
            return

        self.resize_refresh_pending = True

        def refresh():
            self.resize_refresh_pending = False
            self._refresh_preview_now()

        self.root.after(20, refresh)

    def _tick(self):
        if self.stop_requested:
            self._shutdown()
            return

        try:
            if self.state == "ready":
                self._update_preview_from_cameras()
                ready_count = self._count_ready_cameras()
                total_cameras = len(self.robot.cameras)
                if ready_count == total_cameras:
                    self._set_status(
                        f"Ready to record Episode {self.recorded_episodes + 1}.",
                        footer=self._append_missing_camera_note(
                            "All available camera feeds are live. Press Space to begin, or press Backspace to delete the last saved episode."
                        ),
                    )
                else:
                    self._set_status(
                        f"Camera preview is still warming up ({ready_count}/{total_cameras} ready).",
                        footer=self._append_missing_camera_note(
                            "Please wait until the available previews are live before you start recording."
                        ),
                    )
                if self.space_requested:
                    self.space_requested = False
                    if self._all_cameras_ready():
                        self._start_episode()
                    else:
                        self._set_status(
                            "The cameras are still warming up.",
                            footer="Press Space again after all available previews are live.",
                        )

            elif self.state == "recording":
                self._record_sample()
                self._maybe_update_recording_preview()

                elapsed = time.perf_counter() - self.episode_start_t
                stop_frame_threshold = self._minimum_manual_stop_frames()
                manual_stop_ready = self.space_requested and self.current_frame_count >= stop_frame_threshold
                time_limit_reached = elapsed >= self.args.episode_time_s
                if self.space_requested and not manual_stop_ready and not time_limit_reached:
                    self._set_status(
                        f"Finishing Episode {self.recorded_episodes + 1} after first frames are buffered...",
                        footer=(
                            f"Stop requested. The recorder will save automatically after at least "
                            f"{stop_frame_threshold} aligned frames are captured."
                        ),
                    )
                if manual_stop_ready or time_limit_reached:
                    self.space_requested = False
                    self.manual_stop_requested = False
                    self._finish_episode()

            elif self.state == "done":
                pass

        except Exception as exc:
            self.state = "error"
            self._set_status(
                f"Error: {exc}",
                footer="Please check the terminal output for the full traceback.",
            )
            raise

        if self.state == "recording" and self.next_record_tick_deadline_t is not None:
            next_deadline_t = self.next_record_tick_deadline_t + (1.0 / self.args.fps)
            self.next_record_tick_deadline_t = max(next_deadline_t, time.perf_counter())

        self._refresh_counts()
        self._schedule_tick()

    def _start_episode(self):
        if self.recorded_episodes >= self.args.num_episodes:
            self.state = "done"
            self._set_status("All requested episodes are complete.")
            return

        start_t = time.perf_counter()
        self.state = "recording"
        self.space_requested = False
        self.manual_stop_requested = False
        self.pending_record_sample = None
        self.next_record_tick_deadline_t = start_t
        self.last_recording_preview_t = 0.0
        self.current_frame_count = 0
        self.episode_start_t = start_t
        self.episode_first_real_timestamp_s = None
        self.episode_last_real_timestamp_s = None
        self.episode_first_wall_time_ns = None
        self.episode_last_wall_time_ns = None
        self._set_status(
            f"Recording Episode {self.recorded_episodes + 1}.",
            footer="Recording is live. Press Space if you want to finish this episode early.",
        )

    def _finish_episode(self):
        episode_metadata = self._current_episode_metadata()
        summary_note = self._format_episode_summary(episode_metadata)
        if self.current_frame_count > 0:
            self.state = "writing"
            self._set_status(
                f"Saving Episode {self.recorded_episodes + 1} with {self.current_frame_count} frames...",
                footer="Please wait while the videos and parquet files are written.",
            )
            self.root.update_idletasks()
            try:
                self.dataset.save_episode(episode_metadata=episode_metadata)
            except Exception as exc:
                if self._recover_from_failed_save(exc):
                    return
                raise
            self.recorded_episodes += 1
            saved_episode_index = self.recorded_episodes - 1
        else:
            self.dataset.clear_episode_buffer()
            saved_episode_index = None

        self._reset_episode_recording_state()

        if saved_episode_index is not None:
            self._enter_review_state(saved_episode_index)
            if summary_note:
                self.footer_var.set(self.footer_var.get() + "\n" + summary_note)
        else:
            self.state = "ready"
            self._set_status(
                f"Ready for Episode {self.recorded_episodes + 1}.",
                footer="No aligned frames were captured, so nothing was saved. Press Space once to start recording.",
            )

    def _recover_from_failed_save(self, exc: Exception) -> bool:
        if not self.args.dataset_root.exists():
            return False

        previous_recorded_episodes = self.recorded_episodes
        failed_episode_number = self.recorded_episodes + 1
        self._set_status(
            f"Recovering from save error for Episode {failed_episode_number}...",
            footer="Reloading the dataset to check whether the episode was already written.",
        )
        self.root.update_idletasks()

        try:
            self._reload_existing_dataset()
        except Exception:
            return False

        self._reset_episode_recording_state()
        self.space_requested = False

        if self.recorded_episodes > previous_recorded_episodes:
            saved_episode_index = self.recorded_episodes - 1
            self._enter_review_state(saved_episode_index)
            self.footer_var.set(
                self.footer_var.get()
                + f"\nA post-save check raised {type(exc).__name__}, but Episode {saved_episode_index + 1} "
                "was found on disk and is available for review."
            )
            return True

        if self.recorded_episodes >= self.args.num_episodes:
            self.state = "done"
            self._set_status(
                f"Recovered from save error ({type(exc).__name__}).",
                footer=self._append_missing_camera_note(
                    "The incomplete episode was discarded and the dataset was reloaded. "
                    "Press Backspace to delete again, or press Esc to close."
                ),
            )
        else:
            self.state = "ready"
            self._set_status(
                f"Recovered from save error ({type(exc).__name__}). Ready for Episode {self.recorded_episodes + 1}.",
                footer=self._append_missing_camera_note(
                    "The incomplete episode was discarded and the dataset was reloaded. "
                    "Press Space to continue recording."
                ),
            )
        return True

    def _read_video_frame(self, video_path: Path, frame_offset: int, fps: float) -> np.ndarray | None:
        try:
            seek_s = max(float(frame_offset) / max(float(fps), 1e-6), 0.0)
            decode = subprocess.run(
                [
                    "ffmpeg",
                    "-v",
                    "error",
                    "-ss",
                    f"{seek_s:.6f}",
                    "-i",
                    str(video_path),
                    "-vframes",
                    "1",
                    "-f",
                    "image2pipe",
                    "-vcodec",
                    "png",
                    "-",
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=True,
            )
            if not decode.stdout:
                return None
            import io

            image = Image.open(io.BytesIO(decode.stdout)).convert("RGB")
            return np.asarray(image)
        except Exception:
            return None

    def _load_review_video_frames(self, episode_index: int, frame_offset: int = 0) -> None:
        info = _load_json(self.args.dataset_root / "meta" / "info.json")
        paths = _episode_video_paths(self.args.dataset_root, info, episode_index)
        for video_key, path in paths.items():
            camera_key = video_key.replace("observation.images.", "")
            if camera_key not in self.camera_panels:
                continue
            frame = self._read_video_frame(path, frame_offset, float(self.args.fps))
            if frame is None:
                render = self._render_placeholder_image(camera_key, "VIDEO REVIEW FRAME UNAVAILABLE", subdetail=str(path))
            else:
                render = Image.fromarray(frame)
            self._set_panel_image(camera_key, render)

    def _stop_review_replay(self) -> None:
        self.review_replay_active = False
        for cap in getattr(self, "review_video_caps", {}).values():
            try:
                cap.release()
            except Exception:
                pass
        self.review_video_caps = {}
        self.review_replay_frame_index = 0
        self.review_replay_total_frames = 0

    def _open_review_video_captures(self, episode_index: int) -> bool:
        try:
            import cv2
        except Exception as exc:
            self.status_var.set(f"Replay unavailable: cannot import cv2 ({type(exc).__name__}).")
            return False

        info = _load_json(self.args.dataset_root / "meta" / "info.json")
        paths = _episode_video_paths(self.args.dataset_root, info, episode_index)
        caps = {}
        for video_key, path in paths.items():
            camera_key = video_key.replace("observation.images.", "")
            if camera_key not in self.camera_panels:
                continue
            cap = cv2.VideoCapture(str(path))
            if cap.isOpened():
                caps[camera_key] = cap
            else:
                try:
                    cap.release()
                except Exception:
                    pass
                render = self._render_placeholder_image(camera_key, "VIDEO REPLAY UNAVAILABLE", subdetail=str(path))
                self._set_panel_image(camera_key, render)

        if not caps:
            return False

        counts = []
        for video in (self.last_review_report or {}).get("videos", {}).values():
            nb_frames = video.get("nb_frames")
            if nb_frames is not None:
                counts.append(int(nb_frames))
        self.review_replay_total_frames = max(counts, default=0)
        self.review_video_caps = caps
        self.review_replay_frame_index = 0
        return True

    def _start_review_replay(self, episode_index: int | None = None, auto: bool = False) -> None:
        if self.state != "reviewing" or self.review_episode_index is None:
            return
        if episode_index is not None and int(episode_index) != int(self.review_episode_index):
            return

        self._stop_review_replay()
        if not self._open_review_video_captures(self.review_episode_index):
            self.status_var.set(f"Review Episode {self.review_episode_index + 1}: replay unavailable.")
            return

        self.review_replay_active = True
        prefix = "Auto replaying" if auto else "Replaying"
        self.status_var.set(f"{prefix} Episode {self.review_episode_index + 1} videos.")
        self._step_replay()

    def _step_replay(self) -> None:
        if not self.review_replay_active or self.state != "reviewing" or self.review_episode_index is None:
            self._stop_review_replay()
            return

        try:
            import cv2
        except Exception:
            self._stop_review_replay()
            return

        any_frame = False
        for camera_key, cap in list(self.review_video_caps.items()):
            ok, frame = cap.read()
            if ok and frame is not None:
                any_frame = True
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                self._set_panel_image(camera_key, Image.fromarray(rgb))
            else:
                render = self._render_placeholder_image(
                    camera_key,
                    "VIDEO ENDED",
                    subdetail=f"Frame {self.review_replay_frame_index}",
                )
                self._set_panel_image(camera_key, render)

        self.review_replay_frame_index += 1
        replay_complete = not any_frame
        if self.review_replay_total_frames:
            replay_complete = replay_complete or self.review_replay_frame_index >= self.review_replay_total_frames
        if replay_complete:
            episode_number = self.review_episode_index + 1
            self._stop_review_replay()
            self.status_var.set(f"Review Episode {episode_number}: playback finished. Choose Accept, Delete, or Quarantine.")
            return

        replay_fps = min(max(float(self.args.fps), 1.0), REVIEW_REPLAY_FPS)
        self.root.after(max(1, int(1000.0 / replay_fps)), self._step_replay)

    def _update_preview_from_cameras(self):
        for key, panel in self.camera_panels.items():
            camera = self.robot.cameras.get(key)
            if camera is None:
                missing_info = self.robot.unavailable_cameras.get(key, {})
                subdetail = None
                serial_number = missing_info.get("serial_number")
                if serial_number is not None:
                    subdetail = f"Configured serial {serial_number} is not detected."
                render = self._render_placeholder_image(
                    key,
                    "CAMERA NOT AVAILABLE",
                    subdetail=subdetail,
                )
                self._set_panel_image(key, render)
                continue

            frame = camera.color_image
            if frame is not None:
                self.latest_images[key] = frame

            render_frame = self.latest_images.get(key)
            if render_frame is None:
                render = self._render_placeholder_image(
                    key,
                    "WAITING FOR FIRST FRAME",
                    subdetail="Background reader is retrying." if camera.last_read_error is not None else None,
                )
            else:
                render = Image.fromarray(render_frame)

            self._set_panel_image(key, render)

    def _update_preview_from_observation(self, observation: dict):
        for key, panel in self.camera_panels.items():
            if key not in self.robot.cameras:
                missing_info = self.robot.unavailable_cameras.get(key, {})
                subdetail = None
                serial_number = missing_info.get("serial_number")
                if serial_number is not None:
                    subdetail = f"Configured serial {serial_number} is not detected."
                render = self._render_placeholder_image(
                    key,
                    "CAMERA NOT AVAILABLE",
                    subdetail=subdetail,
                )
                self._set_panel_image(key, render)
                continue

            obs_key = f"observation.images.{key}"
            if obs_key in observation:
                image = observation[obs_key]
                if hasattr(image, "cpu"):
                    image = image.cpu().numpy()
                self.latest_images[key] = image

            frame = self.latest_images.get(key)
            if frame is None:
                frame = np.zeros((480, 640, 3), dtype=np.uint8)

            render = Image.fromarray(frame)
            self._set_panel_image(key, render)

    def _on_space(self, _event=None):
        if self.state == "ready":
            if not self._all_cameras_ready():
                ready_count = self._count_ready_cameras()
                total_cameras = len(self.robot.cameras)
                self._set_status(
                    f"Camera preview is still warming up ({ready_count}/{total_cameras} ready).",
                    footer="Wait until all available previews are live, then press Space again.",
                )
                return "break"
            self._start_episode()
            return "break"

        if self.state == "recording":
            self.space_requested = True
            self.manual_stop_requested = True
            stop_frame_threshold = self._minimum_manual_stop_frames()
            if self.current_frame_count < stop_frame_threshold:
                self._set_status(
                    f"Finishing Episode {self.recorded_episodes + 1} after first frames are buffered...",
                    footer=(
                        f"Stop requested. The recorder will save automatically after at least "
                        f"{stop_frame_threshold} aligned frames are captured."
                    ),
                )
            else:
                self._set_status(
                    f"Finishing Episode {self.recorded_episodes + 1}...",
                    footer="The next recorder tick will flush parquet/video and enter review.",
                )
            return "break"

        if self.state == "reviewing":
            self._set_status(
                f"Review Episode {self.review_episode_index + 1}.",
                footer="Choose Accept, Delete, or Quarantine before recording the next episode.",
            )
            return "break"

        if self.state == "writing":
            self._set_status(
                "Saving the current episode...",
                footer="Wait for review before pressing Space again.",
            )
            return "break"

        return "break"

    def _on_delete_last_episode(self, _event=None):
        if not self._can_delete_last_episode():
            if self.state == "recording":
                self._set_status(
                    "Finish the current episode before deleting the previous one.",
                    footer="Backspace works only while the recorder is idle.",
                )
            else:
                self._set_status(
                    "No saved episode is available to delete yet.",
                    footer="Record at least one episode before using Backspace.",
                )
            return "break"

        episode_index = self.recorded_episodes - 1
        report = validate_episode_for_review(self.args.dataset_root, episode_index, float(self.args.fps))
        should_delete = messagebox.askyesno(
            "Confirm delete last episode",
            self._format_artifact_confirmation(report, "Delete"),
        )
        if not should_delete:
            return "break"
        if not messagebox.askyesno(
            "Second confirmation required",
            "This will remove the listed last episode files and metadata entries. Continue?",
        ):
            return "break"

        self._set_status(
            f"Deleting Episode {episode_index + 1}...",
            footer="Please wait while the dataset metadata and files are updated.",
        )
        self.root.update_idletasks()

        if self.dataset is not None:
            try:
                self.dataset.stop_image_writer()
            except Exception:
                pass

        result = delete_last_episode(self.args.dataset_root)
        self._write_review_log("delete", episode_index, {"artifacts": report.get("artifacts"), "result": result.__dict__})
        self.recorded_episodes = result.remaining_episodes
        self.current_frame_count = 0
        self.episode_start_t = None
        self.space_requested = False
        self._reload_existing_dataset()

        if self.recorded_episodes >= self.args.num_episodes:
            self.state = "done"
            self._set_status(
                f"Episode {episode_index + 1} deleted.",
                footer="Requested episode count is already available. Press Backspace to delete again, or press Esc to close the window.",
            )
        else:
            self.state = "ready"
            self._set_status(
                f"Episode {episode_index + 1} deleted.",
                footer=f"Ready to record Episode {self.recorded_episodes + 1}. Press Space to continue.",
            )
        return "break"

    def _on_accept_episode(self):
        if self.state != "reviewing" or self.review_episode_index is None:
            return
        self._write_review_log("accept", self.review_episode_index, {"report": self.last_review_report})
        self._leave_review_for_next_episode(f"Episode {self.review_episode_index + 1} accepted.")

    def _on_delete_review_episode(self):
        if self.state != "reviewing" or self.review_episode_index is None or self.last_review_report is None:
            return
        try:
            self._ensure_review_episode_is_last()
        except Exception as exc:
            messagebox.showerror("Delete refused", str(exc))
            return
        if not messagebox.askyesno(
            "Confirm delete episode",
            self._format_artifact_confirmation(self.last_review_report, "Delete"),
        ):
            return
        if not messagebox.askyesno(
            "Second confirmation required",
            "This will remove the listed episode files and metadata entries. Continue?",
        ):
            return
        episode_index = self.review_episode_index
        self._stop_review_replay()
        if self.dataset is not None:
            try:
                self.dataset.stop_image_writer()
            except Exception:
                pass
        result = delete_last_episode(self.args.dataset_root)
        self._write_review_log("delete", episode_index, {"artifacts": self.last_review_report.get("artifacts"), "result": result.__dict__})
        self.recorded_episodes = result.remaining_episodes
        self._reload_existing_dataset()
        self._leave_review_for_next_episode(f"Episode {episode_index + 1} deleted.")

    def _move_episode_to_quarantine(self, episode_index: int, report: dict) -> dict:
        self._ensure_review_episode_is_last()
        self._validate_last_episode_metadata_update(episode_index)
        info = _load_json(self.args.dataset_root / "meta" / "info.json")
        quarantine_root = self._quarantine_episode_root(episode_index)
        moved = []
        paths = [_episode_parquet_path(self.args.dataset_root, info, episode_index)]
        paths.extend(_episode_video_paths(self.args.dataset_root, info, episode_index).values())
        try:
            for src in paths:
                if not src.exists():
                    continue
                rel = src.relative_to(self.args.dataset_root)
                dst = quarantine_root / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(src), str(dst))
                moved.append({"from": str(src), "to": str(dst)})
            result = delete_last_episode(self.args.dataset_root)
        except Exception:
            for entry in reversed(moved):
                src = Path(entry["to"])
                dst = Path(entry["from"])
                if src.exists() and not dst.exists():
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(src), str(dst))
            raise
        manifest_row = {
            "time": dt.datetime.now(dt.timezone.utc).isoformat(),
            "episode_index": int(episode_index),
            "quarantine_root": str(quarantine_root),
            "moved": moved,
            "metadata_update": result.__dict__,
            "review_report": report,
        }
        _append_jsonl(self._quarantine_manifest_path(), manifest_row)
        self._write_review_log("quarantine", episode_index, manifest_row)
        return {"moved": moved, "result": result}

    def _on_quarantine_review_episode(self):
        if self.state != "reviewing" or self.review_episode_index is None or self.last_review_report is None:
            return
        try:
            self._ensure_review_episode_is_last()
        except Exception as exc:
            messagebox.showerror("Quarantine refused", str(exc))
            return
        if not messagebox.askyesno(
            "Confirm quarantine episode",
            self._format_artifact_confirmation(
                self.last_review_report,
                "Quarantine",
                destination=str(self._quarantine_episode_root(self.review_episode_index)),
            ),
        ):
            return
        if not messagebox.askyesno(
            "Second confirmation required",
            "This will move the listed files to quarantine/bad_episodes and remove the episode from the valid dataset index. Continue?",
        ):
            return
        episode_index = self.review_episode_index
        self._stop_review_replay()
        if self.dataset is not None:
            try:
                self.dataset.stop_image_writer()
            except Exception:
                pass
        outcome = self._move_episode_to_quarantine(episode_index, self.last_review_report)
        self.recorded_episodes = outcome["result"].remaining_episodes
        self._reload_existing_dataset()
        self._leave_review_for_next_episode(f"Episode {episode_index + 1} quarantined.")

    def _on_retake_episode(self):
        if self.state != "reviewing" or self.review_episode_index is None:
            return
        messagebox.showinfo(
            "Retake requested",
            "Retake marks this episode as bad for your decision, but it does not delete or move data. Choose Delete or Quarantine explicitly, or Accept to keep it.",
        )
        self._write_review_log("retake_requested", self.review_episode_index, {"report": self.last_review_report})

    def _on_replay_episode(self):
        if self.state != "reviewing" or self.review_episode_index is None:
            return
        self._start_review_replay(self.review_episode_index, auto=False)

    def _on_show_trace(self):
        if self.state == "reviewing" and self.review_episode_index is not None:
            episode_index = self.review_episode_index
            report = self.last_review_report
        elif self.state in {"ready", "done"} and self.recorded_episodes > 0:
            episode_index = self.recorded_episodes - 1
            report = validate_episode_for_review(self.args.dataset_root, episode_index, float(self.args.fps))
            self.last_review_report = report
            self._set_status(
                f"Showing saved Episode {episode_index + 1} trace.",
                footer=self._review_summary_text(report),
            )
            self._load_review_video_frames(episode_index, frame_offset=0)
        else:
            return
        self._render_state_trace(episode_index, report)

    def _on_escape(self, _event=None):
        if self.state == "writing":
            self._set_status(
                "Finish writing the current episode before exiting.",
                footer="The recorder is flushing parquet/video files and will return to review shortly.",
            )
            return "break"
        if self.state == "recording":
            if not messagebox.askyesno(
                "Exit while recording",
                "The current in-progress episode has not been saved or reviewed. Stop recording and discard only this unsaved buffer?",
            ):
                return "break"
            try:
                self.dataset.clear_episode_buffer()
            except Exception:
                pass
        self.stop_requested = True
        return "break"

    def _on_close(self):
        self._on_escape()

    def _shutdown(self):
        self._stop_review_replay()

        try:
            if self.state == "recording" and self.current_frame_count > 0:
                self.dataset.clear_episode_buffer()
        except Exception:
            pass

        try:
            if self.dataset is not None:
                self.dataset.stop_image_writer()
        except Exception:
            pass

        try:
            if self.robot is not None and self.robot.is_connected:
                self.robot.disconnect()
        except Exception:
            pass

        self.root.destroy()

    def run(self):
        self.root.mainloop()


def parse_args():
    parser = argparse.ArgumentParser(description="GUI data collection for Piper passive recording.")
    parser.add_argument("--dataset-name", required=True)
    parser.add_argument("--dataset-root", required=True, type=Path)
    parser.add_argument("--single-task", default="pick up the green plate and put it in the dish rack")
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--num-episodes", type=int, default=500)
    parser.add_argument("--episode-time-s", type=float, default=90.0)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--robot-cameras-json")
    parser.add_argument("--left-can-name", default="can0")
    parser.add_argument("--right-can-name", default="can1")
    parser.add_argument(
        "--validate-episode-only",
        type=int,
        default=None,
        help="Run the recovered review checks for an existing episode and exit without connecting robot/cameras.",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    if args.validate_episode_only is not None:
        report = validate_episode_for_review(args.dataset_root, args.validate_episode_only, float(args.fps))
        print(json.dumps(report, ensure_ascii=False, indent=2))
        raise SystemExit(2 if report["status"] == "ERROR" else 0)
    app = PiperCollectionGUI(args)
    app.run()


if __name__ == "__main__":
    main()
