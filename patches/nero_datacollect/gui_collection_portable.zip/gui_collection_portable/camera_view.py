#!/usr/bin/env python3

import math
import sys
import time
from pathlib import Path

import cv2
import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from lerobot.common.robot_devices.cameras.configs import IntelRealSenseCameraConfig
from lerobot.common.robot_devices.cameras.intelrealsense import IntelRealSenseCamera, find_cameras
from lerobot.common.robot_devices.robots.configs import PiperRobotConfig


WINDOW_NAME = "Piper Cameras"
CAMERA_LABELS = {
    "head": "HEAD",
    "left_wrist": "LEFT WRIST",
    "right_wrist": "RIGHT WRIST",
    "front_view": "FRONT VIEW",
}


def _camera_display_name(name: str) -> str:
    label = CAMERA_LABELS.get(name)
    if label is not None:
        return label

    words = [word for word in name.replace("-", "_").split("_") if word]
    return " ".join(word.upper() for word in words) or name.upper()


def _preview_camera_config(serial_number: int, reference_cfg) -> IntelRealSenseCameraConfig:
    kwargs = {
        "serial_number": serial_number,
        "fps": 15,
        "width": 640,
        "height": 480,
        "force_hardware_reset": False,
        "rotation": None,
    }
    if reference_cfg is not None:
        for field_name in ("fps", "width", "height", "force_hardware_reset", "rotation"):
            kwargs[field_name] = getattr(reference_cfg, field_name)
    return IntelRealSenseCameraConfig(**kwargs)


def _make_camera_instances():
    cfg = PiperRobotConfig()
    expected_by_serial = {
        int(camera_cfg.serial_number): (name, camera_cfg) for name, camera_cfg in cfg.cameras.items()
    }
    detected = sorted(find_cameras(), key=lambda item: int(item["serial_number"]))
    detected_serials = {int(item["serial_number"]) for item in detected}
    reference_cfg = next(iter(cfg.cameras.values()), None)

    print("=" * 80)
    print("Detected RealSense cameras:")
    extra_count = 0
    for item in detected:
        serial_number = int(item["serial_number"])
        mapped_name = expected_by_serial.get(serial_number, (None, None))[0]
        if mapped_name is None:
            extra_count += 1
            print(f"  serial={serial_number}  name={item['name']}  mapped_as=extra_camera_{extra_count}")
        else:
            print(f"  serial={serial_number}  name={item['name']}  mapped_as={mapped_name}")
    missing_configured = [
        (name, serial_number)
        for serial_number, (name, _) in expected_by_serial.items()
        if serial_number not in detected_serials
    ]
    if missing_configured:
        print("Configured but not detected:")
        for name, serial_number in missing_configured:
            print(f"  serial={serial_number}  expected_as={name}")
    print("=" * 80)

    cameras = []
    extra_count = 0
    for item in detected:
        serial_number = int(item["serial_number"])
        if serial_number in expected_by_serial:
            name, camera_cfg = expected_by_serial[serial_number]
            display_name = _camera_display_name(name)
        else:
            extra_count += 1
            camera_cfg = _preview_camera_config(serial_number, reference_cfg)
            display_name = f"EXTRA CAMERA {extra_count}"
        camera = IntelRealSenseCamera(camera_cfg)
        camera.connect()
        camera.start_async_worker()
        cameras.append((display_name, camera))
        print(
            f"Connected {display_name} "
            f"(serial={camera.serial_number}, fps={camera.fps}, "
            f"width={camera.width}, height={camera.height})"
        )
    return cameras


def _label_frame(frame_rgb: np.ndarray, label: str) -> np.ndarray:
    frame_bgr = cv2.cvtColor(frame_rgb, cv2.COLOR_RGB2BGR)
    cv2.rectangle(frame_bgr, (12, 12), (430, 64), (20, 27, 37), thickness=-1)
    cv2.putText(
        frame_bgr,
        label,
        (24, 48),
        cv2.FONT_HERSHEY_SIMPLEX,
        1.0,
        (255, 242, 179),
        2,
        cv2.LINE_AA,
    )
    return frame_bgr


def _placeholder_frame(width: int, height: int, label: str, detail: str) -> np.ndarray:
    frame = np.zeros((height, width, 3), dtype=np.uint8)
    frame[:] = (34, 40, 49)
    cv2.putText(
        frame,
        label,
        (24, 48),
        cv2.FONT_HERSHEY_SIMPLEX,
        1.0,
        (255, 242, 179),
        2,
        cv2.LINE_AA,
    )
    cv2.putText(
        frame,
        detail,
        (24, 92),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.9,
        (234, 238, 242),
        2,
        cv2.LINE_AA,
    )
    return frame


def _stack_frames(frames: list[np.ndarray]) -> np.ndarray:
    if not frames:
        raise ValueError("No frames to display.")

    target_h = max(frame.shape[0] for frame in frames)
    target_w = max(frame.shape[1] for frame in frames)

    padded = []
    for frame in frames:
        canvas = np.zeros((target_h, target_w, 3), dtype=np.uint8)
        h, w = frame.shape[:2]
        canvas[:h, :w] = frame
        padded.append(canvas)

    cols = 2
    rows = math.ceil(len(padded) / cols)
    blank = np.zeros((target_h, target_w, 3), dtype=np.uint8)

    grid_rows = []
    idx = 0
    for _ in range(rows):
        row_items = []
        for _ in range(cols):
            row_items.append(padded[idx] if idx < len(padded) else blank)
            idx += 1
        grid_rows.append(np.hstack(row_items))

    return np.vstack(grid_rows)


def main():
    cameras = _make_camera_instances()

    print("=" * 80)
    print("Live camera view is ready. Press 'q' or ESC to quit.")
    print("=" * 80)

    cv2.namedWindow(WINDOW_NAME, cv2.WINDOW_NORMAL)

    try:
        while True:
            frames = []
            for display_name, camera in cameras:
                frame = camera.color_image
                if frame is None:
                    detail = "WAITING FOR FRAMES"
                    if camera.last_read_error is not None:
                        detail = "WAITING / RETRYING"
                    frames.append(
                        _placeholder_frame(
                            width=camera.width or 640,
                            height=camera.height or 480,
                            label=f"{display_name} | {camera.serial_number}",
                            detail=detail,
                        )
                    )
                else:
                    frames.append(_label_frame(frame, f"{display_name} | {camera.serial_number}"))

            mosaic = _stack_frames(frames)
            cv2.imshow(WINDOW_NAME, mosaic)

            key = cv2.waitKey(1) & 0xFF
            if key in (27, ord("q")):
                break

            time.sleep(0.005)
    finally:
        for _, camera in cameras:
            try:
                camera.disconnect()
            except Exception:
                pass
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
