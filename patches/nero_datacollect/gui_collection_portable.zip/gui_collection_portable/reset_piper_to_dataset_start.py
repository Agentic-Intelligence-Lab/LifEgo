#!/usr/bin/env python3
"""Reset a Piper arm to the start pose observed in the collected dataset.

press_button has no single fixed start pose: across 500 episodes the active
arm's first-frame joints vary with std up to ~0.12 rad (and episode 0 is an
outlier). So the default target is the **median** of every episode's first-frame
state over the chosen dims (a robust central pose that is guaranteed to have
been assumed by the real arm during collection, hence collision-safe).
Episode-0 / mean / a specific episode are selectable via --method.

By default this only PRINTS the plan (dry-run). Pass --execute to actually
enable the arm and move it, with linear joint-space interpolation (same pattern
as move_piper_to_pose.py).

Run with the lerobot conda env python (has pandas/pyarrow/pyrealsense2); the
lerobot package is picked up from this repo root via sys.path.

    /home/ps/miniconda3/envs/lerobot/bin/python3 reset_piper_to_dataset_start.py
"""
from __future__ import annotations

import argparse
import glob
import os
import sys
import time
from pathlib import Path

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from lerobot.common.robot_devices.motors.configs import PiperMotorsBusConfig  # noqa: E402
from lerobot.common.robot_devices.motors.piper import PiperMotorsBus  # noqa: E402

DEFAULT_DATASET = "/home/ps/Documents/huhuanzhang/press_button_20260414"
# press_button/4000 metadata: post_delta_clamp freezes dims 7-13 -> active arm
# is dims 0-6 (joint_1..joint_6, gripper). Held arm = dims 7-13.
DEFAULT_STATE_SLICE = "0:7"


def make_arm(can_name: str) -> PiperMotorsBus:
    cfg = PiperMotorsBusConfig(
        can_name=can_name,
        motors={
            "joint_1": [1, "agilex_piper"],
            "joint_2": [2, "agilex_piper"],
            "joint_3": [3, "agilex_piper"],
            "joint_4": [4, "agilex_piper"],
            "joint_5": [5, "agilex_piper"],
            "joint_6": [6, "agilex_piper"],
            "gripper": (7, "agilex_piper"),
        },
    )
    return PiperMotorsBus(cfg)


def pose_from_state(state: dict[str, float]) -> np.ndarray:
    return np.asarray([state[f"joint_{idx}"] for idx in range(1, 7)] + [state["gripper"]], dtype=np.float32)


def format_pose(label: str, pose: np.ndarray) -> str:
    preview = ", ".join(f"{value:+.4f}" for value in pose[:6])
    return f"{label}[:6]=[{preview}] grip={pose[6]:+.4f}"


def parse_state_slice(value: str) -> tuple[int, int]:
    parts = value.split(":")
    if len(parts) != 2:
        raise argparse.ArgumentTypeError(f"--state-slice expects 'start:end', got {value!r}.")
    try:
        start, end = int(parts[0]), int(parts[1])
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"--state-slice bounds must be ints: {exc}") from exc
    if end - start != 7:
        raise argparse.ArgumentTypeError(f"--state-slice must span exactly 7 dims (one arm), got {end - start}.")
    return start, end


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Reset a Piper arm to the dataset's start pose (median by default).",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--dataset", default=DEFAULT_DATASET, help="LeRobot dataset root.")
    parser.add_argument("--can-name", default="can1", help="CAN interface of the arm to reset.")
    parser.add_argument(
        "--state-slice",
        type=parse_state_slice,
        default=DEFAULT_STATE_SLICE,
        help="Which 7 dims of the 14D state belong to this arm. '0:7'=active, '7:14'=held.",
    )
    parser.add_argument("--method", choices=("median", "mean", "episode-0", "episode"), default="median")
    parser.add_argument("--episode", type=int, default=0, help="Episode index for --method episode.")
    parser.add_argument("--frame", type=int, default=0, help="Frame within each episode to sample.")
    parser.add_argument("--steps", type=int, default=100)
    parser.add_argument("--step-seconds", type=float, default=0.05)
    parser.add_argument("--settle-seconds", type=float, default=0.5)
    parser.add_argument("--execute", action="store_true", help="Actually move the arm (default: dry-run preview).")
    parser.add_argument("--disable-on-exit", action="store_true", help="Park + disable the arm after moving.")
    args = parser.parse_args()
    if args.steps < 1:
        parser.error("--steps must be at least 1.")
    if args.method == "episode" and not (0 <= args.episode):
        parser.error("--episode must be >= 0 for --method episode.")
    return args


def load_first_frame_states(dataset_dir: str, frame: int) -> np.ndarray:
    import pandas as pd

    files = sorted(glob.glob(os.path.join(dataset_dir, "data", "chunk-*", "episode_*.parquet")))
    if not files:
        raise FileNotFoundError(f"No episode parquet files under {dataset_dir}/data/chunk-*/.")
    states = []
    for path in files:
        df = pd.read_parquet(path, columns=["observation.state"])
        if frame >= len(df):
            raise IndexError(f"--frame {frame} out of range for {os.path.basename(path)} ({len(df)} frames).")
        arr = np.asarray(df["observation.state"].iloc[frame], dtype=np.float64)
        if arr.shape[0] != 14:
            raise ValueError(f"Expected 14D observation.state in {path}, got shape {arr.shape}.")
        states.append(arr)
    return np.asarray(states)


def resolve_target(arm_states: np.ndarray, method: str, episode: int) -> np.ndarray:
    if method == "median":
        return np.median(arm_states, axis=0)
    if method == "mean":
        return arm_states.mean(axis=0)
    if method == "episode-0":
        return arm_states[0]
    if method == "episode":
        return arm_states[episode]
    raise ValueError(f"Unknown method {method!r}.")


def main() -> None:
    args = parse_args()

    states14 = load_first_frame_states(args.dataset, args.frame)
    start_dim, end_dim = args.state_slice
    arm_states = states14[:, start_dim:end_dim]
    n_episodes = arm_states.shape[0]

    target = resolve_target(arm_states, args.method, args.episode).astype(np.float32)
    ep0 = arm_states[0]
    median = np.median(arm_states, axis=0)
    mean = arm_states.mean(axis=0)
    std = arm_states.std(axis=0)

    print(f"dataset      : {args.dataset}")
    print(f"episodes     : {n_episodes}  (frame {args.frame})")
    print(f"can_name     : {args.can_name}  state_slice={start_dim}:{end_dim}")
    print(f"method       : {args.method}")
    print()
    print("Candidates (joint1..joint6, gripper):")
    print(f"  median   : {np.array2string(median, precision=4, separator=', ')}")
    print(f"  mean     : {np.array2string(mean, precision=4, separator=', ')}")
    print(f"  episode-0: {np.array2string(ep0, precision=4, separator=', ')}")
    print(f"  std      : {np.array2string(std, precision=4, separator=', ')}")
    print()
    print(f"  -> TARGET ({args.method}): {np.array2string(target, precision=4, separator=', ')}")

    if not args.execute:
        print()
        print("DRY-RUN: not connecting or moving the arm.")
        print("Inspect the target above, then re-run with --execute to move.")
        return

    arm = make_arm(args.can_name)
    print()
    print(f"Enabling arm on {args.can_name} ...")
    if not arm.connect(enable=True):
        raise RuntimeError(f"Failed to enable arm on {args.can_name}.")

    state = arm.wait_for_feedback(timeout_s=3.0)
    current = pose_from_state(state)
    print(format_pose(f"{args.can_name}.start", current))
    print(format_pose(f"{args.can_name}.target", target))

    max_abs_delta = float(np.max(np.abs(target - current)))
    print(f"max |target - current| = {max_abs_delta:.4f} rad")
    #if max_abs_delta > 1.0:
    #    print("WARNING: target is far from current pose (>1 rad). Aborting for safety.")
    #    print("Re-check the target, move the arm closer manually, or raise --steps.")
    #    return

    print(f"Moving over {args.steps} steps ({args.step_seconds}s/step) ...")
    for alpha in np.linspace(0.0, 1.0, args.steps, dtype=np.float32):
        command = (1.0 - float(alpha)) * current + float(alpha) * target
        arm.write(command.tolist())
        time.sleep(args.step_seconds)
    if args.settle_seconds > 0:
        time.sleep(args.settle_seconds)

    final_state = arm.wait_for_feedback(timeout_s=3.0)
    final_pose = pose_from_state(final_state)
    print(format_pose(f"{args.can_name}.final", final_pose))
    print(f"tracking error vs target = {float(np.max(np.abs(final_pose - target))):.4f} rad")

    if args.disable_on_exit:
        print("Parking and disabling arm ...")
        arm.safe_disconnect()
        time.sleep(0.5)
        arm.connect(enable=False)


if __name__ == "__main__":
    main()
