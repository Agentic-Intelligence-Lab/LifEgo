#!/bin/bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

DATASET_NAME="${DATASET_NAME:-stack_bowls_40}"
DATASET_ROOT="${DATASET_ROOT:-${REPO_ROOT}/data/${DATASET_NAME}}"
SINGLE_TASK="${SINGLE_TASK:-hang_the_purple_cup_on_the_mug_rack}"
FPS="${FPS:-15}"
NUM_EPISODES="${NUM_EPISODES:-100}"
EPISODE_TIME_S="${EPISODE_TIME_S:-90}"
CAN_SETTLE_TIME_S="${CAN_SETTLE_TIME_S:-5}"
RESUME="${RESUME:-true}"

cd "${REPO_ROOT}"

if [ "${RESUME}" = "true" ]; then
    if [ -e "${DATASET_ROOT}" ] && [ ! -f "${DATASET_ROOT}/meta/info.json" ]; then
        echo "Error: RESUME=true but ${DATASET_ROOT} is not a valid existing LeRobot dataset."
        echo "Expected file not found: ${DATASET_ROOT}/meta/info.json"
        echo "Either remove this folder, choose a new DATASET_NAME, or set RESUME=false."
        exit 1
    fi
else
    if [ -e "${DATASET_ROOT}" ]; then
        echo "Error: target dataset directory already exists: ${DATASET_ROOT}"
        echo "Choose a new DATASET_NAME, set RESUME=true, or remove the existing directory."
        exit 1
    fi
fi

echo "================ CAN Activation ================"
bash "${SCRIPT_DIR}/can_activate.sh"

echo "================ GUI Collection ================"
echo "dataset_name=${DATASET_NAME}"
echo "dataset_root=${DATASET_ROOT}"
echo "single_task=${SINGLE_TASK}"
echo "fps=${FPS}"
echo "num_episodes=${NUM_EPISODES}"
echo "episode_time_s=${EPISODE_TIME_S}"
echo "can_settle_time_s=${CAN_SETTLE_TIME_S}"
echo "resume=${RESUME}"

echo "Waiting ${CAN_SETTLE_TIME_S}s for CAN feedback to stabilize..."
sleep "${CAN_SETTLE_TIME_S}"

PY_ARGS=(
  --dataset-name "${DATASET_NAME}"
  --dataset-root "${DATASET_ROOT}"
  --single-task "${SINGLE_TASK}"
  --fps "${FPS}"
  --num-episodes "${NUM_EPISODES}"
  --episode-time-s "${EPISODE_TIME_S}"
)

if [ "${RESUME}" = "true" ]; then
    PY_ARGS+=(--resume)
fi

python "${SCRIPT_DIR}/collect_data_gui.py" "${PY_ARGS[@]}"
