# Piper GUI 数据采集脚本 —— 移植参考包

本包来自 `lerobot-piper-2/piper_scripts/`，用于**参考 GUI 界面与功能设计**，移植到其他机械臂。
脚本之间是平铺关系（没有子目录），保持原名，解压后放到你目标项目的同类脚本目录即可直接运行。

---

## 1. 文件清单与作用

### GUI 主程序（界面/功能的核心参考）
| 文件 | 作用 |
|---|---|
| `collect_data_gui_4cam_recovered.py` | **4 摄像头 GUI 主程序（99K，功能最全）**。tkinter 实现，含实时预览、episode 状态机、轨迹追踪、回放审查、接受/隔离/重拍。**移植首选参考。** |
| `collect_data_gui.py` | 3 摄像头 GUI 主程序（40K，更精简易读）。想快速读懂采集循环逻辑从这版入手。 |

### 启动脚本（shell launcher，配置 + 预检 + 调起 GUI）
| 文件 | 作用 |
|---|---|
| `collect_data_gui_4cam_new.sh` | **最新（主力）启动器**。构造 4 路相机 JSON、激活 CAN、相机预检、内联 Python patch LeRobot 视频编码器（time_base/codec）。 |
| `collect_data_gui_4cam_recovered.sh` | 4 路 GUI 的配套启动器（参数较简）。 |
| `collect_data_gui.sh` | 3 路 GUI 启动器。 |
| `collect_data.sh` | **命令行版（无 GUI，最简）**。直接调 `lerobot.scripts.control_robot --control.type=record`，最适合理解框架对接。 |
| `collect_data_4cam.sh` | 4 路命令行版。 |

### 辅助工具
| 文件 | 作用 |
|---|---|
| `can_activate.sh` | **CAN 总线激活**（`ip link set canX type can bitrate`）。Piper 专属，非 CAN 臂需替换。 |
| `delete_last_episode.py` | 删除数据集最后一个 episode（含元数据修复）。GUI 主程序依赖它。 |
| `check_realsense_4cam_views.py` | 4 路 RealSense 相机预检（枚举序列号、预览）。 |
| `camera_view.py` / `camera.sh` | 单/多相机画面查看。 |
| `replay_place_plate_episode.py` | 回放已采集 episode（读 parquet + 视频）。 |
| `reset_piper_to_dataset_start.py` | 读数据集首帧、把臂插值回放到起始位（Piper 专属 SDK，参考其"回到起点"思路）。 |

---

## 2. 调用关系

```
collect_data_gui_4cam_new.sh ──┐
collect_data_gui_4cam_recovered.sh ─┬─► collect_data_gui_4cam_recovered.py ──► delete_last_episode.py
collect_data_gui.sh ────────────────► collect_data_gui.py ──────────────────► delete_last_episode.py
                                       │
collect_data.sh / collect_data_4cam.sh └► (直接调 lerobot.scripts.control_robot，无 GUI)

所有 *_gui_*.sh 启动前会先调用：can_activate.sh
```

> `collect_data_gui_4cam_recovered.py` 与 `collect_data_gui.py` 的本地依赖**只有** `delete_last_episode.py`，
> 其它都是标准库 + `lerobot.*`。把这两个文件 + `delete_last_episode.py` 一起带走即可独立运行 GUI。

---

## 3. GUI 功能特性（可参考复用的设计点）

4cam GUI（`collect_data_gui_4cam_recovered.py`）已实现的成熟功能，移植时可直接借用：

- **实时多路预览**：4 路 RealSense 同屏显示，启动时占位图等相机预热。
- **episode 状态机**：`booting → idle → recording → review`，状态条 + 帧计数 + 已录集数。
- **快捷键**：
  - `Space` —— 开始 / 结束一个 episode
  - `Backspace` —— 删除最后一个 episode（带元数据修复）
  - `Esc` —— 关闭
- **Episode State Trace**：实时关节轨迹曲线追踪（`_on_show_trace` / `Episode State Trace` 面板）。
- **Review Replay**：录完后回放审查，可**接受 / 隔离(quarantine) / 重拍(retake) / 删除**该 episode。
- **时间戳对齐**：real_time timestamp 模式，保证帧与控制量对齐。
- **断点续录**：`--resume` 向已有 LeRobot dataset 追加 episode。
- **参考数据集对齐**：与 reference dataset 的 fps / task / 相机 key / 视频 time_base 做一致性校验。

---

## 4. 运行依赖

- conda 环境 `lerobot`（含 `lerobot.*` 包、`pyrealsense2`、`pyarrow`、`av`、`PIL`、`tkinter`）
- 系统：`ethtool`、`can-utils`（CAN 激活用）、`ffmpeg`（视频编码用）
- 硬件：RealSense 相机、USB-CAN 适配器（Piper 双臂 = can0 + can1）

> GUI 用 tkinter，无需额外 GUI 框架；Linux 上需有显示环境（X/Wayland）。

---

## 5. 移植到其他机械臂 —— 关键改造点

采集流程 90% 是 **LeRobot 框架自带**的（`lerobot.scripts.control_robot --control.type=record`），
GUI 只是在外面包了一层界面与预检。**真正的"机器人专属代码"在 LeRobot 的 robot/motor 后端，不在本包里。**

### 改造分两层

#### A. LeRobot 后端（不在本包，需在目标项目里改）
| 要改的地方 | Piper 仿照对象（在原 lerobot-piper-2 仓库） |
|---|---|
| 电机总线类 `connect/read/write/safe_disconnect/wait_for_feedback/get_status_hz` | `lerobot/common/robot_devices/motors/piper.py` |
| 电机总线 config | `lerobot/common/robot_devices/motors/configs.py` 的 `PiperMotorsBusConfig` |
| 机器人 config（follower_arms + cameras） | `lerobot/common/robot_devices/robots/configs.py` 的 `PiperRobotConfig` |

> 若新臂用 Dynamixel / Feetech 总线 → 零代码，加个 config 即可（仿 Koch/SO-100）。

#### B. 本包内的脚本改造（按机器人替换 Piper 专属部分）
| 位置 | Piper 专属内容 | 改造方向 |
|---|---|---|
| `can_activate.sh` | CAN 总线激活（can0/can1） | 新臂若非 CAN，换成对应的连接/上电脚本（串口、以太网、SDK 初始化等） |
| 启动脚本里的相机序列号 | `HEAD_CAMERA_SERIAL` 等 4 个 RealSense 序列号 | 改成你的相机序列号，或换成非 RealSense 相机配置 |
| `_gui_4cam_new.sh` 内联的视频编码 patch | Piper 数据集视频 time_base/codec 校准 | 若不用视频编码或参数不同，可整段删掉 |
| GUI 里的关节维度假设 | 7 维（6 关节 + gripper），双臂 14 维 | 轨迹追踪面板按你的 DOF 调整 |
| `passive_recording` 模式 | 假设硬件主从联动，action=state | 若是软件 leader/follower，改用 `_leader_follower_step` 逻辑 |

### 可直接复用、与机器人无关的部分
- tkinter GUI 布局、配色、字体选择逻辑
- episode 状态机 + 快捷键
- 多路相机预览 + 占位图预热
- 删除最后一集 + 元数据修复（`delete_last_episode.py`）
- Review 回放 + 接受/隔离/重拍
- 断点续录 + 参考数据集对齐校验

---

## 6. 建议的移植顺序

1. **读懂采集循环**：先看 `collect_data.sh`（无 GUI，30 行调框架）→ 再看 `collect_data_gui.py`（精简 GUI）。
2. **跑通 LeRobot 后端**：在目标项目里把新臂的 motor bus / robot config 做好，命令行 `control_robot --control.type=record` 能录。
3. **套 GUI**：把 `collect_data_gui_4cam_recovered.py` + `delete_last_episode.py` 拷过去，替换相机配置、去掉 Piper 专属预检（CAN 激活、序列号），对接你的 robot。
4. **按需裁剪**：不需要视频编码 patch / review 审查的，先删掉再跑通，再逐步加回。
