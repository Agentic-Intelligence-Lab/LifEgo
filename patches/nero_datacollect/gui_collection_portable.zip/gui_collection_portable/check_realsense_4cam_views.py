#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from lerobot.common.robot_devices.cameras.configs import IntelRealSenseCameraConfig
from lerobot.common.robot_devices.cameras.intelrealsense import IntelRealSenseCamera, find_cameras


DEFAULT_CAMERAS = {
    "head": int(os.environ.get("HEAD_CAMERA_SERIAL", "254622073267")),
    "left_wrist": int(os.environ.get("LEFT_WRIST_CAMERA_SERIAL", "244222071617")),
    "right_wrist": int(os.environ.get("RIGHT_WRIST_CAMERA_SERIAL", "317622070857")),
    "front_view": int(os.environ.get("FRONT_VIEW_CAMERA_SERIAL", "254622079402")),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Check the four RealSense views used by Piper OpenPI inference.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--out-dir", type=Path, default=Path("debug_outputs/press_button_4cam_views"))
    parser.add_argument("--fps", type=int, default=15)
    parser.add_argument("--width", type=int, default=640)
    parser.add_argument("--height", type=int, default=480)
    parser.add_argument("--warmup-seconds", type=float, default=1.5)
    parser.add_argument("--snapshot-only", action="store_true", help="Save images and exit without opening a live window.")
    parser.add_argument("--list-only", action="store_true", help="Only print detected RealSense serials from librealsense.")
    return parser.parse_args()


def detected_realsense_serials() -> list[str]:
    return sorted(str(item["serial_number"]) for item in find_cameras(raise_when_empty=False))


def print_serial_report() -> None:
    detected = detected_realsense_serials()
    print("=" * 80)
    print("Detected RealSense serials:")
    for serial in detected:
        print(f"  {serial}")
    if not detected:
        print("  <none>")
    print("Configured role mapping:")
    for role, serial in DEFAULT_CAMERAS.items():
        status = "present" if str(serial) in detected else "MISSING"
        print(f"  {role:12s} serial={serial}  {status}")
    print("=" * 80)


def make_camera(role: str, serial: int, args: argparse.Namespace) -> IntelRealSenseCamera:
    cfg = IntelRealSenseCameraConfig(
        serial_number=serial,
        fps=args.fps,
        width=args.width,
        height=args.height,
        force_hardware_reset=False,
        rotation=None,
    )
    camera = IntelRealSenseCamera(cfg)
    print(f"Connecting {role} serial={serial} ...", flush=True)
    camera.connect()
    camera.start_async_worker()
    print(f"Connected {role} serial={serial} fps={camera.fps} size={camera.width}x{camera.height}", flush=True)
    return camera


def label_frame(frame_rgb: np.ndarray, title: str) -> np.ndarray:
    frame_bgr = cv2.cvtColor(frame_rgb, cv2.COLOR_RGB2BGR)
    cv2.rectangle(frame_bgr, (10, 10), (620, 58), (20, 24, 31), thickness=-1)
    cv2.putText(
        frame_bgr,
        title,
        (22, 44),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.85,
        (255, 245, 180),
        2,
        cv2.LINE_AA,
    )
    return frame_bgr


def placeholder(width: int, height: int, title: str, detail: str) -> np.ndarray:
    frame = np.zeros((height, width, 3), dtype=np.uint8)
    frame[:] = (35, 39, 46)
    cv2.putText(frame, title, (22, 44), cv2.FONT_HERSHEY_SIMPLEX, 0.85, (255, 245, 180), 2, cv2.LINE_AA)
    cv2.putText(frame, detail, (22, 88), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (235, 238, 242), 2, cv2.LINE_AA)
    return frame


def stack_2x2(frames: list[np.ndarray]) -> np.ndarray:
    if len(frames) != 4:
        raise ValueError(f"Expected exactly 4 frames, got {len(frames)}")
    h = max(frame.shape[0] for frame in frames)
    w = max(frame.shape[1] for frame in frames)
    padded = []
    for frame in frames:
        canvas = np.zeros((h, w, 3), dtype=np.uint8)
        fh, fw = frame.shape[:2]
        canvas[:fh, :fw] = frame
        padded.append(canvas)
    return np.vstack([np.hstack(padded[:2]), np.hstack(padded[2:])])


def current_frame(role: str, serial: int, camera: IntelRealSenseCamera) -> np.ndarray:
    title = f"{role} | {serial}"
    if camera.color_image is None:
        detail = "waiting for frames"
        if camera.last_read_error is not None:
            detail = f"retrying: {type(camera.last_read_error).__name__}"
        return placeholder(camera.width or 640, camera.height or 480, title, detail)
    return label_frame(np.asarray(camera.color_image), title)


def save_snapshot(cameras: dict[str, IntelRealSenseCamera], out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    frames = []
    for role, camera in cameras.items():
        serial = DEFAULT_CAMERAS[role]
        frame = current_frame(role, serial, camera)
        frames.append(frame)
        path = out_dir / f"{role}_{serial}.png"
        Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)).save(path)
        print(f"saved {role:12s} -> {path}")

    montage = stack_2x2(frames)
    montage_path = out_dir / "montage_2x2.png"
    Image.fromarray(cv2.cvtColor(montage, cv2.COLOR_BGR2RGB)).save(montage_path)
    print(f"saved montage    -> {montage_path}")


def main() -> None:
    args = parse_args()
    print_serial_report()
    if args.list_only:
        return

    missing = [role for role, serial in DEFAULT_CAMERAS.items() if str(serial) not in detected_realsense_serials()]
    if missing:
        missing_desc = ", ".join(f"{role}:{DEFAULT_CAMERAS[role]}" for role in missing)
        raise SystemExit(f"Missing configured camera serial(s): {missing_desc}")

    cameras: dict[str, IntelRealSenseCamera] = {}
    try:
        for role, serial in DEFAULT_CAMERAS.items():
            cameras[role] = make_camera(role, serial, args)

        print(f"warming up for {args.warmup_seconds:.1f}s ...", flush=True)
        time.sleep(args.warmup_seconds)
        save_snapshot(cameras, args.out_dir)

        if args.snapshot_only:
            return

        print("=" * 80)
        print("Live 4-camera view is open. Press q or ESC to exit.")
        print("=" * 80)
        cv2.namedWindow("Piper 4Cam View Check", cv2.WINDOW_NORMAL)
        while True:
            frames = [
                current_frame(role, DEFAULT_CAMERAS[role], cameras[role])
                for role in ("head", "left_wrist", "right_wrist", "front_view")
            ]
            cv2.imshow("Piper 4Cam View Check", stack_2x2(frames))
            key = cv2.waitKey(1) & 0xFF
            if key in (27, ord("q")):
                break
            time.sleep(0.005)
    finally:
        for camera in cameras.values():
            try:
                camera.disconnect()
            except Exception:
                pass
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
