#!/bin/bash

set -euo pipefail

# Passive data collection script for the current Piper setup.
#
# Current data collection logic:
# 1. The hardware handles the master/slave linkage between arms.
# 2. The software does NOT command the leader arms.
# 3. LeRobot only reads follower joint states from can0 and can1.
# 4. LeRobot records the 3 RealSense camera streams configured in PiperRobotConfig.
# 5. In passive recording mode, the dataset "action" field is set to the follower
#    state at the same timestep, so the pipeline can save a valid frame format.
#
# Important:
# - Run this script after `conda activate lerobot`.
# - If one arm prints `Returning response: False`, that arm did not enable correctly.
#   In that case, check CAN wiring / power before trusting the recorded dataset.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

# ----------------------------
# User-configurable parameters
# ----------------------------

# Dataset identifier used by LeRobot metadata.
# Keep this as a simple name such as "test" or "stack_bowls_run_01".
DATASET_NAME="${DATASET_NAME:-stack_bowls3}"

# Dataset directory on local disk.
# This is the actual folder where data will be written.
DATASET_ROOT="${DATASET_ROOT:-${REPO_ROOT}/data/${DATASET_NAME}}"

# Free-text task label stored in the dataset.
SINGLE_TASK="${SINGLE_TASK:-stack_bowls}"

# Recording frame rate.
FPS="${FPS:-15}"

# Whether to display camera windows during recording.
# Recording still saves video/images when this is false.
DISPLAY_CAMERAS="${DISPLAY_CAMERAS:-false}"

# Number of episodes to record.
NUM_EPISODES="${NUM_EPISODES:-2}"

# Seconds to wait before each episode starts recording.
# This is useful to give yourself time to prepare the robot motion.
WARMUP_TIME_S="${WARMUP_TIME_S:-0}"

# Seconds of actual data recording per episode.
EPISODE_TIME_S="${EPISODE_TIME_S:-10}"

# Seconds reserved between episodes.
# In the current passive mode this is only a pause/read loop;
# it does not command the robot to move back home.
RESET_TIME_S="${RESET_TIME_S:-10}"

# Whether to push the dataset to the Hugging Face Hub after recording.
PUSH_TO_HUB="${PUSH_TO_HUB:-false}"

# Whether to play speech notifications during recording.
PLAY_SOUNDS="${PLAY_SOUNDS:-false}"

# Whether to resume writing into an existing dataset directory.
# Set this to true when REPO_ID already exists and you want to continue recording.
RESUME="${RESUME:-false}"

# Whether to require SPACE to start each episode and allow SPACE to stop early.
MANUAL_EPISODE_CONTROL="${MANUAL_EPISODE_CONTROL:-true}"

# Seconds to wait after CAN activation before starting the Python process.
CAN_SETTLE_TIME_S="${CAN_SETTLE_TIME_S:-2}"

# Expected CAN interfaces for the current dual-arm passive recording setup.
EXPECTED_CAN_INTERFACES="${EXPECTED_CAN_INTERFACES:-can0 can1}"

cd "${REPO_ROOT}"

if [ "${RESUME}" = "true" ]; then
    if [ ! -f "${DATASET_ROOT}/meta/info.json" ]; then
        echo "Error: RESUME=true but ${DATASET_ROOT} is not a valid existing LeRobot dataset."
        echo "Expected file not found: ${DATASET_ROOT}/meta/info.json"
        echo "Either remove this folder, choose a new DATASET_NAME, or set RESUME=false."
        exit 1
    fi
else
    if [ -e "${DATASET_ROOT}" ]; then
        echo "Error: target dataset directory already exists: ${DATASET_ROOT}"
        echo "Either remove it, choose a new DATASET_NAME, or set RESUME=true for a valid existing dataset."
        exit 1
    fi
fi

echo "================ CAN Activation ================"
bash "${SCRIPT_DIR}/can_activate.sh"

echo "================ Data Collection ================"
echo "dataset_name=${DATASET_NAME}"
echo "dataset_root=${DATASET_ROOT}"
echo "single_task=${SINGLE_TASK}"
echo "fps=${FPS}"
echo "display_cameras=${DISPLAY_CAMERAS}"
echo "num_episodes=${NUM_EPISODES}"
echo "warmup_time_s=${WARMUP_TIME_S}"
echo "episode_time_s=${EPISODE_TIME_S}"
echo "reset_time_s=${RESET_TIME_S}"
echo "push_to_hub=${PUSH_TO_HUB}"
echo "play_sounds=${PLAY_SOUNDS}"
echo "resume=${RESUME}"
echo "manual_episode_control=${MANUAL_EPISODE_CONTROL}"
echo "can_settle_time_s=${CAN_SETTLE_TIME_S}"
echo "expected_can_interfaces=${EXPECTED_CAN_INTERFACES}"

echo "Waiting ${CAN_SETTLE_TIME_S}s for CAN feedback to stabilize..."
sleep "${CAN_SETTLE_TIME_S}"

missing_can_interfaces=()
for iface in ${EXPECTED_CAN_INTERFACES}; do
    if [ ! -d "/sys/class/net/${iface}" ]; then
        missing_can_interfaces+=("${iface}")
    fi
done

if [ "${#missing_can_interfaces[@]}" -gt 0 ]; then
    echo "Error: missing required CAN interface(s): ${missing_can_interfaces[*]}"
    echo "Detected network interfaces:"
    ls /sys/class/net | sed 's/^/  - /'
    echo "The dual-arm Piper setup requires all of: ${EXPECTED_CAN_INTERFACES}"
    echo "Please check USB-CAN power, cabling, and whether both adapters are enumerated."
    exit 1
fi

LEROBOT_MANUAL_EPISODE_CONTROL="${MANUAL_EPISODE_CONTROL}" python -m lerobot.scripts.control_robot \
  --robot.type=piper \
  --control.type=record \
  --control.fps="${FPS}" \
  --control.single_task="${SINGLE_TASK}" \
  --control.repo_id="${DATASET_NAME}" \
  --control.root="${DATASET_ROOT}" \
  --control.num_episodes="${NUM_EPISODES}" \
  --control.warmup_time_s="${WARMUP_TIME_S}" \
  --control.episode_time_s="${EPISODE_TIME_S}" \
  --control.reset_time_s="${RESET_TIME_S}" \
  --control.display_cameras="${DISPLAY_CAMERAS}" \
  --control.play_sounds="${PLAY_SOUNDS}" \
  --control.resume="${RESUME}" \
  --control.push_to_hub="${PUSH_TO_HUB}"
