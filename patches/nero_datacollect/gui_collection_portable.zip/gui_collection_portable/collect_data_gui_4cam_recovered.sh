#!/bin/bash

set -euo pipefail

# Recovered GUI-based passive data collection for a 4-camera Piper setup.
#
# This launcher mirrors collect_data_gui.sh but injects a 4-camera layout so the
# Tk GUI can show live previews with placeholders while each camera warms up.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

DATASET_NAME="${DATASET_NAME:-place_plate_20260519}"
DATASET_ROOT="${DATASET_ROOT:-/home/ps/Documents/lerobot-piper/data/${DATASET_NAME}}"
SINGLE_TASK="${SINGLE_TASK:-pick up the green plate and put it in the dish rack}"
FPS="${FPS:-30}"
NUM_EPISODES="${NUM_EPISODES:-500}"
EPISODE_TIME_S="${EPISODE_TIME_S:-90}"
CAN_SETTLE_TIME_S="${CAN_SETTLE_TIME_S:-5}"
RESUME="${RESUME:-false}"
EXPECTED_CAN_INTERFACES="${EXPECTED_CAN_INTERFACES:-can0 can1}"
CAN_BITRATE="${CAN_BITRATE:-1000000}"
LEFT_CAN_NAME="${LEFT_CAN_NAME:-can0}"
RIGHT_CAN_NAME="${RIGHT_CAN_NAME:-can1}"
LEFT_CAN_USB_ADDRESS="${LEFT_CAN_USB_ADDRESS:-7-2.2:1.0}"
RIGHT_CAN_USB_ADDRESS="${RIGHT_CAN_USB_ADDRESS:-7-2.4:1.0}"
VALIDATE_AFTER_RECORD="${VALIDATE_AFTER_RECORD:-true}"

CAMERA_FPS="${CAMERA_FPS:-${FPS}}"
CAMERA_WIDTH="${CAMERA_WIDTH:-640}"
CAMERA_HEIGHT="${CAMERA_HEIGHT:-480}"

HEAD_CAMERA_SERIAL="${HEAD_CAMERA_SERIAL:-254622073267}"
LEFT_WRIST_CAMERA_SERIAL="${LEFT_WRIST_CAMERA_SERIAL:-244222071617}"
RIGHT_WRIST_CAMERA_SERIAL="${RIGHT_WRIST_CAMERA_SERIAL:-317622070857}"
AUX_CAMERA_KEY="${AUX_CAMERA_KEY:-front_view}"
AUX_CAMERA_SERIAL="${AUX_CAMERA_SERIAL:-254622079402}"

HEAD_CAMERA_ROTATION="${HEAD_CAMERA_ROTATION:-none}"
LEFT_WRIST_CAMERA_ROTATION="${LEFT_WRIST_CAMERA_ROTATION:-none}"
RIGHT_WRIST_CAMERA_ROTATION="${RIGHT_WRIST_CAMERA_ROTATION:-none}"
AUX_CAMERA_ROTATION="${AUX_CAMERA_ROTATION:-none}"

cd "${REPO_ROOT}"

PYTHON_BIN="${PYTHON_BIN:-python}"
PYTHON_PREFIX="$("${PYTHON_BIN}" - <<'PY'
import sys
print(sys.prefix)
PY
)"
CONDA_LIBJPEG="${PYTHON_PREFIX}/lib/libjpeg.so.8"
PYTHON_LD_PRELOAD="${LD_PRELOAD:-}"
if [ -f "${CONDA_LIBJPEG}" ]; then
    PYTHON_LD_PRELOAD="${CONDA_LIBJPEG}${PYTHON_LD_PRELOAD:+:${PYTHON_LD_PRELOAD}}"
fi

get_episode_count() {
    local dataset_root="$1"
    "${PYTHON_BIN}" - "$dataset_root" <<'PY'
from pathlib import Path
import sys

root = Path(sys.argv[1])
episodes_path = root / "meta" / "episodes.jsonl"
if not episodes_path.exists():
    print(0)
    raise SystemExit

count = 0
with episodes_path.open("r", encoding="utf-8") as f:
    for line in f:
        if line.strip():
            count += 1
print(count)
PY
}

if [[ ! "${AUX_CAMERA_KEY}" =~ ^[A-Za-z0-9_]+$ ]]; then
    echo "Error: AUX_CAMERA_KEY must use only letters, numbers, or underscores."
    echo "Current value: ${AUX_CAMERA_KEY}"
    exit 1
fi

validate_rotation() {
    local rotation_name="$1"
    local rotation_value="$2"
    case "${rotation_value}" in
        none|-90|90|180)
            ;;
        *)
            echo "Error: ${rotation_name} must be one of: none, -90, 90, 180."
            echo "Current value: ${rotation_value}"
            exit 1
            ;;
    esac
}

validate_serial() {
    local serial_name="$1"
    local serial_value="$2"
    if [[ ! "${serial_value}" =~ ^[0-9]+$ ]]; then
        echo "Error: ${serial_name} must be a numeric RealSense serial number."
        echo "Current value: ${serial_value}"
        exit 1
    fi
}

validate_serial "HEAD_CAMERA_SERIAL" "${HEAD_CAMERA_SERIAL}"
validate_serial "LEFT_WRIST_CAMERA_SERIAL" "${LEFT_WRIST_CAMERA_SERIAL}"
validate_serial "RIGHT_WRIST_CAMERA_SERIAL" "${RIGHT_WRIST_CAMERA_SERIAL}"
validate_serial "AUX_CAMERA_SERIAL" "${AUX_CAMERA_SERIAL}"

validate_rotation "HEAD_CAMERA_ROTATION" "${HEAD_CAMERA_ROTATION}"
validate_rotation "LEFT_WRIST_CAMERA_ROTATION" "${LEFT_WRIST_CAMERA_ROTATION}"
validate_rotation "RIGHT_WRIST_CAMERA_ROTATION" "${RIGHT_WRIST_CAMERA_ROTATION}"
validate_rotation "AUX_CAMERA_ROTATION" "${AUX_CAMERA_ROTATION}"

declare -A SEEN_SERIALS=()
DUPLICATE_SERIALS=()
for serial in \
    "${HEAD_CAMERA_SERIAL}" \
    "${LEFT_WRIST_CAMERA_SERIAL}" \
    "${RIGHT_WRIST_CAMERA_SERIAL}" \
    "${AUX_CAMERA_SERIAL}"; do
    if [ -n "${SEEN_SERIALS[$serial]:-}" ]; then
        DUPLICATE_SERIALS+=("${serial}")
    else
        SEEN_SERIALS[$serial]=1
    fi
done

if [ "${#DUPLICATE_SERIALS[@]}" -gt 0 ]; then
    echo "Error: duplicate camera serial numbers are not allowed."
    printf 'Duplicated serial(s): %s\n' "${DUPLICATE_SERIALS[@]}"
    exit 1
fi

is_zero_episode_partial_dataset() {
    local dataset_root="$1"
    "${PYTHON_BIN}" - "$dataset_root" <<'PY'
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
info_path = root / "meta" / "info.json"
if not info_path.exists():
    raise SystemExit(1)
try:
    info = json.loads(info_path.read_text(encoding="utf-8"))
except Exception:
    raise SystemExit(1)
if any(int(info.get(key, -1)) != 0 for key in ["total_episodes", "total_frames", "total_videos"]):
    raise SystemExit(1)
for folder_name in ["data", "videos"]:
    folder = root / folder_name
    if folder.exists() and any(folder.rglob("*")):
        raise SystemExit(1)
raise SystemExit(0)
PY
}

ensure_empty_dataset_metadata_files() {
    local dataset_root="$1"
    mkdir -p "${dataset_root}/meta"
    touch \
        "${dataset_root}/meta/tasks.jsonl" \
        "${dataset_root}/meta/episodes.jsonl" \
        "${dataset_root}/meta/episodes_stats.jsonl"
}

if [ "${RESUME}" = "true" ]; then
    REQUIRED_DATASET_FILES=(
        "meta/info.json"
        "meta/tasks.jsonl"
        "meta/episodes.jsonl"
        "meta/episodes_stats.jsonl"
    )
    MISSING_DATASET_FILES=()
    if [ -e "${DATASET_ROOT}" ]; then
        for relative_path in "${REQUIRED_DATASET_FILES[@]}"; do
            if [ ! -f "${DATASET_ROOT}/${relative_path}" ]; then
                MISSING_DATASET_FILES+=("${relative_path}")
            fi
        done
    fi
    if [ "${#MISSING_DATASET_FILES[@]}" -gt 0 ]; then
        if is_zero_episode_partial_dataset "${DATASET_ROOT}"; then
            echo "Found a zero-episode partial dataset directory. Creating empty metadata jsonl files and resuming safely."
            ensure_empty_dataset_metadata_files "${DATASET_ROOT}"
        else
            echo "Error: RESUME=true but ${DATASET_ROOT} is not a valid existing LeRobot dataset."
            echo "Missing file(s):"
            printf '  - %s\n' "${MISSING_DATASET_FILES[@]}"
            echo "This usually means a previous failed startup left a partial dataset directory."
            echo "Move it aside, choose a new DATASET_NAME, or set RESUME=false after removing the partial directory."
            exit 1
        fi
    fi
else
    if [ -e "${DATASET_ROOT}" ]; then
        if is_zero_episode_partial_dataset "${DATASET_ROOT}"; then
            echo "Found a zero-episode partial dataset directory. Reusing it without deleting data."
            ensure_empty_dataset_metadata_files "${DATASET_ROOT}"
            RESUME="true"
        else
            echo "Error: target dataset directory already exists: ${DATASET_ROOT}"
            echo "Choose a new DATASET_NAME, set RESUME=true, or remove the existing directory."
            exit 1
        fi
    fi
fi

INITIAL_EPISODE_COUNT="$(get_episode_count "${DATASET_ROOT}")"

ROBOT_CAMERAS_JSON="$(
    HEAD_CAMERA_SERIAL="${HEAD_CAMERA_SERIAL}" \
    LEFT_WRIST_CAMERA_SERIAL="${LEFT_WRIST_CAMERA_SERIAL}" \
    RIGHT_WRIST_CAMERA_SERIAL="${RIGHT_WRIST_CAMERA_SERIAL}" \
    AUX_CAMERA_SERIAL="${AUX_CAMERA_SERIAL}" \
    AUX_CAMERA_KEY="${AUX_CAMERA_KEY}" \
    CAMERA_FPS="${CAMERA_FPS}" \
    CAMERA_WIDTH="${CAMERA_WIDTH}" \
    CAMERA_HEIGHT="${CAMERA_HEIGHT}" \
    HEAD_CAMERA_ROTATION="${HEAD_CAMERA_ROTATION}" \
    LEFT_WRIST_CAMERA_ROTATION="${LEFT_WRIST_CAMERA_ROTATION}" \
    RIGHT_WRIST_CAMERA_ROTATION="${RIGHT_WRIST_CAMERA_ROTATION}" \
    AUX_CAMERA_ROTATION="${AUX_CAMERA_ROTATION}" \
    "${PYTHON_BIN}" - <<'PY'
import json
import os


def parse_int(name: str) -> int:
    return int(os.environ[name])


def parse_rotation(name: str):
    value = os.environ[name].strip().lower()
    if value == "none":
        return None
    return int(value)


def make_camera(serial_env: str, rotation_env: str) -> dict:
    return {
        "type": "intelrealsense",
        "serial_number": parse_int(serial_env),
        "fps": parse_int("CAMERA_FPS"),
        "width": parse_int("CAMERA_WIDTH"),
        "height": parse_int("CAMERA_HEIGHT"),
        "force_hardware_reset": False,
        "rotation": parse_rotation(rotation_env),
    }


cameras = {
    "head": make_camera("HEAD_CAMERA_SERIAL", "HEAD_CAMERA_ROTATION"),
    "left_wrist": make_camera("LEFT_WRIST_CAMERA_SERIAL", "LEFT_WRIST_CAMERA_ROTATION"),
    "right_wrist": make_camera("RIGHT_WRIST_CAMERA_SERIAL", "RIGHT_WRIST_CAMERA_ROTATION"),
    os.environ["AUX_CAMERA_KEY"]: make_camera("AUX_CAMERA_SERIAL", "AUX_CAMERA_ROTATION"),
}

print(json.dumps(cameras, separators=(",", ":")))
PY
)"

echo "================ Camera Preflight ================"
echo "head=${HEAD_CAMERA_SERIAL} rotation=${HEAD_CAMERA_ROTATION}"
echo "left_wrist=${LEFT_WRIST_CAMERA_SERIAL} rotation=${LEFT_WRIST_CAMERA_ROTATION}"
echo "right_wrist=${RIGHT_WRIST_CAMERA_SERIAL} rotation=${RIGHT_WRIST_CAMERA_ROTATION}"
echo "${AUX_CAMERA_KEY}=${AUX_CAMERA_SERIAL} rotation=${AUX_CAMERA_ROTATION}"

PYTHONPATH="${REPO_ROOT}" EXPECTED_CAMERA_JSON="${ROBOT_CAMERAS_JSON}" "${PYTHON_BIN}" - <<'PY'
import json
import os
import sys

from lerobot.common.robot_devices.cameras.intelrealsense import find_cameras

expected = json.loads(os.environ["EXPECTED_CAMERA_JSON"])
detected_infos = find_cameras()
detected = {int(item["serial_number"]): item["name"] for item in detected_infos}

print("Detected RealSense cameras:")
for serial_number in sorted(detected):
    print(f"  serial={serial_number}  name={detected[serial_number]}")

missing = []
for key, camera_cfg in expected.items():
    serial_number = int(camera_cfg["serial_number"])
    if serial_number not in detected:
        missing.append((key, serial_number))

if missing:
    print("Error: missing configured RealSense camera(s) for this 4-camera GUI run:")
    for key, serial_number in missing:
        print(f"  {key}: serial={serial_number}")
    print("Reconnect the missing camera(s) or update the serial numbers before recording.")
    sys.exit(1)

print("All configured 4-camera serial numbers are currently detected.")
PY

echo "================ CAN Activation ================"
echo "left_can=${LEFT_CAN_NAME} usb=${LEFT_CAN_USB_ADDRESS} bitrate=${CAN_BITRATE}"
echo "right_can=${RIGHT_CAN_NAME} usb=${RIGHT_CAN_USB_ADDRESS} bitrate=${CAN_BITRATE}"
bash "${SCRIPT_DIR}/can_activate.sh" "${LEFT_CAN_NAME}" "${CAN_BITRATE}" "${LEFT_CAN_USB_ADDRESS}"
bash "${SCRIPT_DIR}/can_activate.sh" "${RIGHT_CAN_NAME}" "${CAN_BITRATE}" "${RIGHT_CAN_USB_ADDRESS}"

echo "================ GUI Collection (4 Cameras) ================"
echo "dataset_name=${DATASET_NAME}"
echo "dataset_root=${DATASET_ROOT}"
echo "single_task=${SINGLE_TASK}"
echo "fps=${FPS}"
echo "num_episodes=${NUM_EPISODES}"
echo "episode_time_s=${EPISODE_TIME_S}"
echo "can_settle_time_s=${CAN_SETTLE_TIME_S}"
echo "resume=${RESUME}"
echo "camera_keys=head,left_wrist,right_wrist,${AUX_CAMERA_KEY}"

echo "Waiting ${CAN_SETTLE_TIME_S}s for CAN feedback to stabilize..."
sleep "${CAN_SETTLE_TIME_S}"

missing_can_interfaces=()
for iface in ${EXPECTED_CAN_INTERFACES}; do
    if [ ! -d "/sys/class/net/${iface}" ]; then
        missing_can_interfaces+=("${iface}")
    fi
done

if [ "${#missing_can_interfaces[@]}" -gt 0 ]; then
    echo "Error: missing required CAN interface(s): ${missing_can_interfaces[*]}"
    echo "Detected network interfaces:"
    ls /sys/class/net | sed 's/^/  - /'
    echo "The dual-arm Piper setup requires all of: ${EXPECTED_CAN_INTERFACES}"
    echo "Please check USB-CAN power, cabling, and whether both adapters are enumerated."
    exit 1
fi

PY_ARGS=(
  --dataset-name "${DATASET_NAME}"
  --dataset-root "${DATASET_ROOT}"
  --single-task "${SINGLE_TASK}"
  --fps "${FPS}"
  --num-episodes "${NUM_EPISODES}"
  --episode-time-s "${EPISODE_TIME_S}"
  --robot-cameras-json "${ROBOT_CAMERAS_JSON}"
  --left-can-name "${LEFT_CAN_NAME}"
  --right-can-name "${RIGHT_CAN_NAME}"
)

if [ "${RESUME}" = "true" ]; then
    PY_ARGS+=(--resume)
fi

echo "python_bin=${PYTHON_BIN}"
if [ -f "${CONDA_LIBJPEG}" ]; then
    echo "opencv_libjpeg_preload=${CONDA_LIBJPEG}"
fi
LD_PRELOAD="${PYTHON_LD_PRELOAD}" "${PYTHON_BIN}" "${SCRIPT_DIR}/collect_data_gui_4cam_recovered.py" "${PY_ARGS[@]}"

if [ "${VALIDATE_AFTER_RECORD}" = "true" ]; then
    FINAL_EPISODE_COUNT="$(get_episode_count "${DATASET_ROOT}")"
    echo "================ Post-Run Validation ================"
    echo "initial_episode_count=${INITIAL_EPISODE_COUNT}"
    echo "final_episode_count=${FINAL_EPISODE_COUNT}"

    if [ "${FINAL_EPISODE_COUNT}" -le "${INITIAL_EPISODE_COUNT}" ]; then
        echo "No new episodes were recorded in this run. Skipping validation."
        exit 0
    fi

    for ((episode_index=INITIAL_EPISODE_COUNT; episode_index<FINAL_EPISODE_COUNT; episode_index++)); do
        echo "Validating episode ${episode_index}..."
        PYTHONPATH="${REPO_ROOT}" LD_PRELOAD="${PYTHON_LD_PRELOAD}" "${PYTHON_BIN}" "${SCRIPT_DIR}/validate_realtime_episode.py" \
            "${DATASET_ROOT}" \
            --episode-index "${episode_index}"
    done
fi
