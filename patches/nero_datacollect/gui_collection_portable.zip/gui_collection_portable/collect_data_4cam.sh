#!/bin/bash

set -euo pipefail

# Passive data collection script for a 4-camera Piper setup.
#
# Usage example:
#   conda activate lerobot
#   bash piper_scripts/collect_data_4cam.sh
#
# Notes:
# - This script does not change the global default PiperRobotConfig.
# - The 4-camera layout is injected only for this run through --robot.cameras JSON.
# - By default the 4th camera is the front view D435 at serial 254622079402.
# - You can still override the 4th camera using AUX_CAMERA_KEY / AUX_CAMERA_SERIAL.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

# ----------------------------
# User-configurable parameters
# ----------------------------

DATASET_NAME="${DATASET_NAME:-stack_bowls_4cam}"
DATASET_ROOT="${DATASET_ROOT:-${REPO_ROOT}/data/${DATASET_NAME}}"
SINGLE_TASK="${SINGLE_TASK:-stack_bowls}"
FPS="${FPS:-15}"
DISPLAY_CAMERAS="${DISPLAY_CAMERAS:-false}"
NUM_EPISODES="${NUM_EPISODES:-2}"
WARMUP_TIME_S="${WARMUP_TIME_S:-0}"
EPISODE_TIME_S="${EPISODE_TIME_S:-10}"
RESET_TIME_S="${RESET_TIME_S:-10}"
PUSH_TO_HUB="${PUSH_TO_HUB:-false}"
PLAY_SOUNDS="${PLAY_SOUNDS:-false}"
RESUME="${RESUME:-false}"
MANUAL_EPISODE_CONTROL="${MANUAL_EPISODE_CONTROL:-true}"
CAN_SETTLE_TIME_S="${CAN_SETTLE_TIME_S:-2}"
EXPECTED_CAN_INTERFACES="${EXPECTED_CAN_INTERFACES:-can0 can1}"

# Shared RealSense settings for this run.
CAMERA_FPS="${CAMERA_FPS:-${FPS}}"
CAMERA_WIDTH="${CAMERA_WIDTH:-640}"
CAMERA_HEIGHT="${CAMERA_HEIGHT:-480}"

# 4-camera mapping for this run.
HEAD_CAMERA_SERIAL="${HEAD_CAMERA_SERIAL:-254622073267}"
LEFT_WRIST_CAMERA_SERIAL="${LEFT_WRIST_CAMERA_SERIAL:-244222071617}"
RIGHT_WRIST_CAMERA_SERIAL="${RIGHT_WRIST_CAMERA_SERIAL:-317622070857}"
AUX_CAMERA_KEY="${AUX_CAMERA_KEY:-front_view}"
AUX_CAMERA_SERIAL="${AUX_CAMERA_SERIAL:-254622079402}"

HEAD_CAMERA_ROTATION="${HEAD_CAMERA_ROTATION:-none}"
LEFT_WRIST_CAMERA_ROTATION="${LEFT_WRIST_CAMERA_ROTATION:-none}"
RIGHT_WRIST_CAMERA_ROTATION="${RIGHT_WRIST_CAMERA_ROTATION:-none}"
AUX_CAMERA_ROTATION="${AUX_CAMERA_ROTATION:-none}"

cd "${REPO_ROOT}"

if [[ ! "${AUX_CAMERA_KEY}" =~ ^[A-Za-z0-9_]+$ ]]; then
    echo "Error: AUX_CAMERA_KEY must use only letters, numbers, or underscores."
    echo "Current value: ${AUX_CAMERA_KEY}"
    exit 1
fi

validate_rotation() {
    local rotation_name="$1"
    local rotation_value="$2"
    case "${rotation_value}" in
        none|-90|90|180)
            ;;
        *)
            echo "Error: ${rotation_name} must be one of: none, -90, 90, 180."
            echo "Current value: ${rotation_value}"
            exit 1
            ;;
    esac
}

validate_serial() {
    local serial_name="$1"
    local serial_value="$2"
    if [[ ! "${serial_value}" =~ ^[0-9]+$ ]]; then
        echo "Error: ${serial_name} must be a numeric RealSense serial number."
        echo "Current value: ${serial_value}"
        exit 1
    fi
}

validate_serial "HEAD_CAMERA_SERIAL" "${HEAD_CAMERA_SERIAL}"
validate_serial "LEFT_WRIST_CAMERA_SERIAL" "${LEFT_WRIST_CAMERA_SERIAL}"
validate_serial "RIGHT_WRIST_CAMERA_SERIAL" "${RIGHT_WRIST_CAMERA_SERIAL}"
validate_serial "AUX_CAMERA_SERIAL" "${AUX_CAMERA_SERIAL}"

validate_rotation "HEAD_CAMERA_ROTATION" "${HEAD_CAMERA_ROTATION}"
validate_rotation "LEFT_WRIST_CAMERA_ROTATION" "${LEFT_WRIST_CAMERA_ROTATION}"
validate_rotation "RIGHT_WRIST_CAMERA_ROTATION" "${RIGHT_WRIST_CAMERA_ROTATION}"
validate_rotation "AUX_CAMERA_ROTATION" "${AUX_CAMERA_ROTATION}"

declare -A SEEN_SERIALS=()
DUPLICATE_SERIALS=()
for serial in \
    "${HEAD_CAMERA_SERIAL}" \
    "${LEFT_WRIST_CAMERA_SERIAL}" \
    "${RIGHT_WRIST_CAMERA_SERIAL}" \
    "${AUX_CAMERA_SERIAL}"; do
    if [ -n "${SEEN_SERIALS[$serial]:-}" ]; then
        DUPLICATE_SERIALS+=("${serial}")
    else
        SEEN_SERIALS[$serial]=1
    fi
done

if [ "${#DUPLICATE_SERIALS[@]}" -gt 0 ]; then
    echo "Error: duplicate camera serial numbers are not allowed."
    printf 'Duplicated serial(s): %s\n' "${DUPLICATE_SERIALS[@]}"
    exit 1
fi

if [ "${RESUME}" = "true" ]; then
    if [ ! -f "${DATASET_ROOT}/meta/info.json" ]; then
        echo "Error: RESUME=true but ${DATASET_ROOT} is not a valid existing LeRobot dataset."
        echo "Expected file not found: ${DATASET_ROOT}/meta/info.json"
        echo "Either remove this folder, choose a new DATASET_NAME, or set RESUME=false."
        exit 1
    fi
else
    if [ -e "${DATASET_ROOT}" ]; then
        echo "Error: target dataset directory already exists: ${DATASET_ROOT}"
        echo "Either remove it, choose a new DATASET_NAME, or set RESUME=true for a valid existing dataset."
        exit 1
    fi
fi

ROBOT_CAMERAS_JSON="$(
    HEAD_CAMERA_SERIAL="${HEAD_CAMERA_SERIAL}" \
    LEFT_WRIST_CAMERA_SERIAL="${LEFT_WRIST_CAMERA_SERIAL}" \
    RIGHT_WRIST_CAMERA_SERIAL="${RIGHT_WRIST_CAMERA_SERIAL}" \
    AUX_CAMERA_SERIAL="${AUX_CAMERA_SERIAL}" \
    AUX_CAMERA_KEY="${AUX_CAMERA_KEY}" \
    CAMERA_FPS="${CAMERA_FPS}" \
    CAMERA_WIDTH="${CAMERA_WIDTH}" \
    CAMERA_HEIGHT="${CAMERA_HEIGHT}" \
    HEAD_CAMERA_ROTATION="${HEAD_CAMERA_ROTATION}" \
    LEFT_WRIST_CAMERA_ROTATION="${LEFT_WRIST_CAMERA_ROTATION}" \
    RIGHT_WRIST_CAMERA_ROTATION="${RIGHT_WRIST_CAMERA_ROTATION}" \
    AUX_CAMERA_ROTATION="${AUX_CAMERA_ROTATION}" \
    python - <<'PY'
import json
import os


def parse_int(name: str) -> int:
    return int(os.environ[name])


def parse_rotation(name: str) -> int | None:
    value = os.environ[name].strip().lower()
    if value == "none":
        return None
    return int(value)


def make_camera(serial_env: str, rotation_env: str) -> dict:
    return {
        "type": "intelrealsense",
        "serial_number": parse_int(serial_env),
        "fps": parse_int("CAMERA_FPS"),
        "width": parse_int("CAMERA_WIDTH"),
        "height": parse_int("CAMERA_HEIGHT"),
        "force_hardware_reset": False,
        "rotation": parse_rotation(rotation_env),
    }


cameras = {
    "head": make_camera("HEAD_CAMERA_SERIAL", "HEAD_CAMERA_ROTATION"),
    "left_wrist": make_camera("LEFT_WRIST_CAMERA_SERIAL", "LEFT_WRIST_CAMERA_ROTATION"),
    "right_wrist": make_camera("RIGHT_WRIST_CAMERA_SERIAL", "RIGHT_WRIST_CAMERA_ROTATION"),
    os.environ["AUX_CAMERA_KEY"]: make_camera("AUX_CAMERA_SERIAL", "AUX_CAMERA_ROTATION"),
}

print(json.dumps(cameras, separators=(",", ":")))
PY
)"

echo "================ Camera Preflight ================"
echo "head=${HEAD_CAMERA_SERIAL} rotation=${HEAD_CAMERA_ROTATION}"
echo "left_wrist=${LEFT_WRIST_CAMERA_SERIAL} rotation=${LEFT_WRIST_CAMERA_ROTATION}"
echo "right_wrist=${RIGHT_WRIST_CAMERA_SERIAL} rotation=${RIGHT_WRIST_CAMERA_ROTATION}"
echo "${AUX_CAMERA_KEY}=${AUX_CAMERA_SERIAL} rotation=${AUX_CAMERA_ROTATION}"

PYTHONPATH="${REPO_ROOT}" EXPECTED_CAMERA_JSON="${ROBOT_CAMERAS_JSON}" python - <<'PY'
import json
import os
import sys

from lerobot.common.robot_devices.cameras.intelrealsense import find_cameras

expected = json.loads(os.environ["EXPECTED_CAMERA_JSON"])
detected_infos = find_cameras()
detected = {int(item["serial_number"]): item["name"] for item in detected_infos}

print("Detected RealSense cameras:")
for serial_number in sorted(detected):
    print(f"  serial={serial_number}  name={detected[serial_number]}")

missing = []
for key, camera_cfg in expected.items():
    serial_number = int(camera_cfg["serial_number"])
    if serial_number not in detected:
        missing.append((key, serial_number))

if missing:
    print("Error: missing configured RealSense camera(s) for this 4-camera run:")
    for key, serial_number in missing:
        print(f"  {key}: serial={serial_number}")
    print("Reconnect the missing camera(s) or update the serial numbers before recording.")
    sys.exit(1)

print("All configured 4-camera serial numbers are currently detected.")
PY

echo "================ CAN Activation ================"
bash "${SCRIPT_DIR}/can_activate.sh"

echo "================ Data Collection (4 Cameras) ================"
echo "dataset_name=${DATASET_NAME}"
echo "dataset_root=${DATASET_ROOT}"
echo "single_task=${SINGLE_TASK}"
echo "fps=${FPS}"
echo "display_cameras=${DISPLAY_CAMERAS}"
echo "num_episodes=${NUM_EPISODES}"
echo "warmup_time_s=${WARMUP_TIME_S}"
echo "episode_time_s=${EPISODE_TIME_S}"
echo "reset_time_s=${RESET_TIME_S}"
echo "push_to_hub=${PUSH_TO_HUB}"
echo "play_sounds=${PLAY_SOUNDS}"
echo "resume=${RESUME}"
echo "manual_episode_control=${MANUAL_EPISODE_CONTROL}"
echo "camera_fps=${CAMERA_FPS}"
echo "camera_resolution=${CAMERA_WIDTH}x${CAMERA_HEIGHT}"
echo "can_settle_time_s=${CAN_SETTLE_TIME_S}"
echo "expected_can_interfaces=${EXPECTED_CAN_INTERFACES}"
echo "camera_keys=head,left_wrist,right_wrist,${AUX_CAMERA_KEY}"

echo "Waiting ${CAN_SETTLE_TIME_S}s for CAN feedback to stabilize..."
sleep "${CAN_SETTLE_TIME_S}"

missing_can_interfaces=()
for iface in ${EXPECTED_CAN_INTERFACES}; do
    if [ ! -d "/sys/class/net/${iface}" ]; then
        missing_can_interfaces+=("${iface}")
    fi
done

if [ "${#missing_can_interfaces[@]}" -gt 0 ]; then
    echo "Error: missing required CAN interface(s): ${missing_can_interfaces[*]}"
    echo "Detected network interfaces:"
    ls /sys/class/net | sed 's/^/  - /'
    echo "The dual-arm Piper setup requires all of: ${EXPECTED_CAN_INTERFACES}"
    echo "Please check USB-CAN power, cabling, and whether both adapters are enumerated."
    exit 1
fi

LEROBOT_MANUAL_EPISODE_CONTROL="${MANUAL_EPISODE_CONTROL}" python -m lerobot.scripts.control_robot \
  --robot.type=piper \
  "--robot.cameras=${ROBOT_CAMERAS_JSON}" \
  --control.type=record \
  --control.fps="${FPS}" \
  --control.single_task="${SINGLE_TASK}" \
  --control.repo_id="${DATASET_NAME}" \
  --control.root="${DATASET_ROOT}" \
  --control.num_episodes="${NUM_EPISODES}" \
  --control.warmup_time_s="${WARMUP_TIME_S}" \
  --control.episode_time_s="${EPISODE_TIME_S}" \
  --control.reset_time_s="${RESET_TIME_S}" \
  --control.display_cameras="${DISPLAY_CAMERAS}" \
  --control.play_sounds="${PLAY_SOUNDS}" \
  --control.resume="${RESUME}" \
  --control.push_to_hub="${PUSH_TO_HUB}"
